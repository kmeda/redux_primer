# CCS Dashboard → Mobile: Analysis & Plan

Source material: live inspection of `https://att-ccs-dashboard.it.att.com:3000/` (DOM/network/WebSocket capture via a local Playwright harness), captured `/api/reports` payload (290 reports), and the `ccs_dashboard-rn` MVP scaffold built and running on iOS to date.

See `MVP_IMPLEMENTATION.md` for what's actually been built in the scaffold (stack, screen templates, file structure) — this document is the analysis and forward-looking plan.

Scope note: the current MVP scope is **Real-time Monitoring only** (9 reports), targeting the `ATT`/`ADVISOR_USER` roles. Everything else (historical/analytical reporting, agent administration/CRUD) is represented in the app's navigation as non-interactive placeholders for later phases.

---

## 0. Discovery Reality Check — Timeline & Scope Honesty

Worth stating plainly, for anyone using this document to set expectations: **this is a mature system (5+ years) with no accessible documentation**, and every fact in this analysis was obtained through live reverse-engineering (network/WebSocket capture while manually navigating the app), not from reading anything written down. That has real implications for how much confidence to place in any timeline for a full rewrite.

**Evidence of depth, from just one report category (Real-time Monitoring, 9 of 290 reports — roughly 3% of the catalog):**
- **Five distinct backend integration patterns** across those 9 reports: a ~2MB WebSocket-pushed recursive tree, a ~1.15MB REST-polled tree with a different schema, a generic flat `api/query` engine, a separate historical-snapshot chart endpoint, and a third charting pattern (`getVQChartDetails`) behind a modal three drill-levels deep that wasn't discoverable without a live user stumbling onto it (see §1/§3/§4).
- **Multiple corrected assumptions during this same investigation**: an initial hypothesis that SBS shared the main Monitoring WebSocket tree (client-filtered) was disproven by direct string-matching, not confirmed by inference; the "Current Day" report was initially conflated with the Home page's live tiles until a real capture showed they're separate endpoints; the `/api/reports` metadata's declared column list undersold the real column count by roughly 4x for the densest report.
- **Backend inconsistencies** consistent with years of different hands touching the system without a unifying contract: field naming varies between structurally-identical "sibling" reports (`NOTREADY` vs `NOT_READY`), and one endpoint (`/api/report/<KEY>`) returns raw SQL fragments to the browser.

**The honest conclusion**: extrapolating the discovery cost for 3% of the catalog to the full 290 reports, plus the admin/CRUD workflows, plus the analytical reporting suite, a rigorous plan for the *entire* application is realistically weeks-to-months of discovery work — not achievable in a few days, especially for someone with no prior exposure to either this codebase or contact-center operations as a business domain. Treating a fast turnaround as achievable risks one of two outcomes: a plan built on unvalidated assumptions that breaks once real engineering starts (this document itself needed three rounds of correction as new facts emerged), or a plan that looks complete but is only surface-deep and doesn't actually reduce delivery risk.

**Recommended reframing for leadership:**
1. Treat this document and the working prototype as a **Phase 0 discovery spike**, not "the plan" — its value is in being honest about what's confirmed vs. still open, not in looking finished.
2. Ask for **discovery time as its own explicit line item**, sized by extrapolating from what a few days surfaced for ~3% of the catalog.
3. Ask for **access to institutional knowledge** (the desktop app's engineering team, actual contact-center supervisors, backend owners) — reverse-engineering via network capture is a last resort for undocumented systems, not a substitute for people who already know the answers.
4. **Commit only to the Phase 1 scope** that's now genuinely de-risked (Real-time Monitoring — real data shapes captured, a working UI, known blockers documented) and explicitly defer full-app estimation until Phase 1 ships and its lessons are absorbed.
5. Treat this plan as a **living document**, versioned and revised as discovery continues — not a one-shot artifact frozen at a point in time, since a system this old won't yield a stable understanding on the first pass no matter who does the discovery.

---

## 1. Web Application Analysis: Key Components, Data Flows, User Interactions

**Frontend stack (confirmed via live inspection)**
- React SPA built with Vite (`/assets/index-*.js` ES modules)
- MUI v5 + Emotion CSS-in-JS for all UI (tables, cards, buttons, chips, drawers)
- Chart.js for bar/line/donut charts
- Client-side routing per report: `/voice/split/<REPORT_KEY>`, `/voice/tree/<REPORT_KEY>`, `/voice/advisor-new/<REPORT_KEY>`, `/rtm/chart/<REPORT_KEY>`, etc. — the route prefix encodes the report's rendering pattern (flat table vs. hierarchy vs. chart)

**Key components**
1. **AppBar** — hamburger drawer toggle, title, report count badge ("116 Reports"), "LIVE / Real-Time" badge
2. **Left nav drawer** — Home, Favorite Reports, Recent Reports, Voice Reports, Real-time Monitoring, Analytical Reports (categories expand to sub-lists)
3. **Home dashboard** — 4 KPI panels (Enterprise Voice/Chat Agent Status as donuts, Enterprise Call/Chat Stats as bar charts) + 2 trend line charts (Voice/Chat Agent Status over the day), fed by a live WebSocket
4. **Category landing pages** — simple link tables (report name + description), the entry point into each report
5. **Generic report engine/renderer** — a single reusable component driven by report metadata (`columns`, `columnNameList`, filters) — reused across all 290 reports. This is the most important architectural fact: **the desktop app is metadata-driven, not one bespoke screen per report**
6. **Report detail screens** — filter bar (date range, BU, org, vendor, site multi-selects) → KPI stat cards → chart(s) → dense expandable/drill-down data table (6 to 70 columns depending on report) → export button, with a manual/auto "Last Refreshed" toggle for near-real-time reports. For the "advisor tree" reports specifically, drilling down further reveals per-queue (VQDN) and per-skill side panels, and tapping a VQDN opens a per-queue trend chart modal (see §3) — a deeper interaction layer than initially captured.
7. **Admin/back-office module** — separate CRUD + approval-workflow screens for agent profile lifecycle (bulk CSV upload → validation → approval queue → Genesys sync)

**Data flows**
- **Auth**: browser → AT&T IBM ISAM/TAM OIDC (`oidc.idp.elogin.att.com`) Authorization Code flow → `/auth/redirect?code=...` → app backend exchanges code, sets a session cookie. No token is ever exposed to the SPA directly.
- **Report catalog**: `GET /api/reports` once per session → returns full 290-report catalog + user identity + roles; drives the entire left-nav tree and RBAC visibility client-side.
- **Report metadata**: `GET /api/report/<REPORT_KEY>` → columns, filters, and (concerningly) raw SQL fragments (see §5 security).
- **Report data**: `POST /api/query/<REPORT_KEY>` → generic `{ metaData: [{name}], rows: [...] }` shape, re-queried on filter change or manual/auto refresh.
- **Home dashboard live tiles**: `wss://att-ccs-dashboard.it.att.com:3000/ws/enterprise` — a persistent WebSocket, server-push (not client-polled), emitting 4 message types every ~15 seconds: `enterprise_data_push`, `enterprise_call_params_push`, `enterprise_chat_data_push`, `enterprise_chat_params_push`. This is the exact feed behind the header's "LIVE" badge and the Home page donuts/trend charts.
- **Personalization**: `POST /api/favorites/FAVORITE_REPORTS`, `POST /api/recent/RECENT_REPORTS`.

**Key user interactions**
- Browse category → open report → adjust filters → read KPI cards/charts → drill into table rows (expand hierarchy or open detail) → export.
- Star a report as favorite; recently-viewed reports auto-populate a Home widget.
- Admin users additionally: upload CSVs, review validation-failed rows, approve/reject pending agent changes.

---

## 2. Features & Functionality to Port to Mobile

**In scope for current MVP**
- Home dashboard live KPI tiles (donut + bar + trend), sourced from the same WebSocket feed
- Real-time Monitoring category — all 9 reports (3 monitoring variants, 2 hierarchy views, 1 flat active-agents view, 2 skill views, 1 live trend chart)
- Favorites (empty-state today) / Recent Reports (static mock today)
- Full sidebar navigation shell representing every desktop category (for structural completeness and stakeholder demos), with non-real-time categories as clearly-labeled placeholders

**Explicitly deferred (later phases)**
- Historical/analytical reporting (day/week/month, call detail, up to 70-column tables) — needs a genuinely different mobile UX (master-detail, not a table port)
- Agent administration/CRUD (bulk upload, approvals, Genesys sync) — desktop-appropriate workflows; approval *actions* specifically are a good push-notification candidate for a later phase
- AI Search (`nl2sql`) and Chat Transcript Insight Analysis — compelling but not yet scoped
- Alert/threshold-driven push notifications (ties to the desktop's `Alert LOB Threshold` admin screen)
- Export/share functionality

---

## 3. Data Sources & APIs to Be Consumed

**Update:** all 9 real-time reports plus the Home WebSocket feed have now been individually captured from the live dashboard. This section reflects confirmed findings, not assumptions. Real payload samples live in `ccs_dashboard-rn/src/mocks/realCaptures/` and are wired into the app's mocks (replacing the earlier hand-authored fixtures).

**Home dashboard live tiles**
- `wss://att-ccs-dashboard.it.att.com:3000/ws/enterprise` — persistent, server-push, 4 message types every ~15s: `enterprise_data_push`, `enterprise_call_params_push`, `enterprise_chat_data_push`, `enterprise_chat_params_push`. Small payloads (~130-150 bytes each).

**The 9 Real-time Monitoring reports break into three distinct backend patterns:**

| Report | Data source | Payload shape | Notes |
|---|---|---|---|
| Real-time Monitoring | `wss://.../ws/rtm` push (`rtm_data_push`), client sends `{type: 'rtm_subscribe', reportURL, isVoiceSelected, isChatSelected}` | `{voice: {parents: TreeNode[], skillMap: {...}}}` — 5-level recursive BU→Org→LOB→Category→VQ tree, 32 metrics per node | **~2MB per push, every ~15s.** 68 top-level BUs, 2,293 total nodes in one real capture. `skillMap` contains live employee PII (name, ID, site, call duration) per skill. No BU-level subscription filter exists — only a voice/chat toggle. |
| SBS Real-time Monitoring | **Unconfirmed** | Unknown | UI shows a distinct 10-BU subset not found anywhere in the main `/ws/rtm` tree content, and no new WS/REST activity was observed while on this page during capture. Ruled out: simple client-side filtering of the shared tree (verified by exact string search — none of SBS's displayed BU names appear in the tree's JSON). **Needs a dedicated capture session with fresh network traces**, ideally with browser DevTools open to catch anything our headless capture missed (e.g. a cached/localStorage-backed path, or a request fired before our listener attached). |
| ICM Real-time Monitoring | `POST /restAPI/ICMquery/ICM_REAL_TIME_MONITORING`, REST polled ~15s | `{voice: {parents, skillMap, parents5Min, parents30Min, offlinePeris}}` — same tree shape, 39 metrics per node (adds `AVAIL`, `CALLSINPROGRESS`, `LONGESTCALLQ`, `CALLSQNOWTIME`, `AVGDELAYQNOW`, `HANDLESEC*`) | ~1.15MB per poll. Separate backend entirely (matches the distinct `ICM-NON-ATT`/`ICM_USER` RBAC roles seen in the catalog). Also carries a `skillMap` with PII. |
| Real-time Active Agents Hierarchy | `POST /api/query/REAL_TIME_ACTIVE_AGENTS_HIERARCHY` | Flat rows: `BUSINESS_UNIT, AGENT_BU, AGENT_ORG, VENDOR_NAME, SITE_NAME, LOGGEDIN, ONCALL, NOTREADY, READY, ACW_TIME` | **Not a server-side tree** — identical flat shape to the "View" report below; the frontend groups client-side (confirmed: our RN app's original hierarchy-screen approach was architecturally correct). |
| Real-time Active Agents View | `POST /api/query/REAL_TIME_ACTIVE_AGENTS_VIEW` | Same flat shape as Hierarchy above | Rendered as a flat table instead of grouped. |
| Real-time Active Agents Vendor Hierarchy | `POST /api/query/REAL_TIME_ACTIVE_AGENTS_VENDOR_HIERARCHY` | Flat rows: `VENDOR, BUSINESS_UNIT, AGENT_LOB, SITE_NAME, LOGGED_IN, ON_CALL, NOT_READY, READY, ACW, ANSWERED, AHT, ANSWERED_30, AHT_30` | Note the field-naming inconsistency vs. the Hierarchy report above (`LOGGED_IN` vs `LOGGEDIN`, `NOT_READY` vs `NOTREADY`) — this is a real backend inconsistency, not a typo; the mobile data layer needs to normalize it. |
| Real-time Skill Agents View | `POST /api/query/REAL_TIME_SKILL_AGENTS_VIEW` | Flat rows: `SKILL_NAME, LOGGED_IN, ON_CALL, NOT_READY, READY, ACW` | ~77 skills in a real capture. |
| Real-time Skill Chat Agents | `POST /api/query/REAL_TIME_SKILL_CHAT_AGENTS` | Same shape as above | ~24 skills in a real capture. |
| Real-time Monitoring Current Day | `GET /restAPI/RTMSnapshots?bu=<BU>` (+ `GET /restAPI/RTMSnapshots/BUs` for the BU picker) | `[{snapshotTime, data: [{BU, QUEUE, LOGIN, READY, ASA, ...32 fields}]}]`, hourly snapshots across the day | This is a **user-configurable line chart** (metric multi-select + BU picker), not the same thing as the Home page's live WS tiles — our original mock conflated the two; now corrected to a dedicated screen sourced from real snapshot data. |

**Critical implication for mobile:** the ~2MB (Monitoring) and ~1.15MB (ICM) payloads, refreshed every 15 seconds, are not viable to consume raw on a mobile client — bandwidth, battery, and the embedded PII all argue against it. The mobile app cannot just "connect to the same feed." Realistic options to evaluate with the backend team:
1. A dedicated mobile aggregation endpoint that returns only top-level BU rollups by default, with children fetched lazily on drill-down (this is exactly how our RN app's `AdvisorTreeScreen` already renders it, which conveniently means the *client* is ready for this pattern the moment the backend supports it).
2. Excluding `skillMap` (the PII-bearing block) from the default mobile payload entirely, fetched only on an explicit, audited drill-into-skill action.
3. Confirming whether the backend can filter by subscribed BU (today it appears not to for `/ws/rtm`) — worth asking directly since our subscribe-message inspection only found a voice/chat toggle, not a BU filter.

**Auth/personalization (unchanged from earlier capture):**
- `GET /api/reports`, `GET /api/report/<KEY>` (still exposes raw SQL — see §5), `POST /api/favorites/FAVORITE_REPORTS`, `POST /api/recent/RECENT_REPORTS` — shapes as previously documented, no new findings this round.
- `oidc.idp.elogin.att.com` (IBM ISAM/TAM) — native/public client registration still unconfirmed.

**Remaining open item:** SBS Real-time Monitoring's real data source. Recommend a follow-up capture session with full browser DevTools (not just our headless network log) specifically on that page, since our automated capture didn't observe the network activity that must be producing what's on screen.

**Newly discovered interaction layer (Real-time Monitoring family, not yet reflected in the RN scaffold):** drilling into a BU row reveals two additional side panels not previously captured:
- A **VQDN panel** (virtual queue DNs) — a table of individual queue DNs under the selected node, with their own Queue/Max Wait/Offered/etc. columns
- A **SKILLNAME panel** below it — logged-in/on-call/not-ready/ready/ACW counts per skill, tied to the `skills: [...]` array already observed on leaf `ADVISOR_VQ` tree nodes (see the tree shape above) — this is where that field is actually used in the UI, confirming it wasn't dead data

Clicking a **VQDN row** opens a modal with a per-queue trend chart:
- `GET /api/getVQChartDetails/?vq=<VQDN_NAME>&hour=<N>` → Chart.js-ready shape: `{labels: [...], datasets: [...]}` (confirmed empty-state shape only — `{labels: [], datasets: []}` — since the specific queues clicked during capture had no traffic in the window; the populated shape wasn't captured)
- A metric picker with 7 checkboxes: Offered, Answered, Queued, ASA, AHT, Logged In, Ready — each independently toggleable, presumably each maps to one `datasets[]` entry
- An hour-range selector (only "2 Hour" observed; other options not confirmed)

This is a **third distinct charting pattern** in the app, different from both the Home page's WebSocket-driven tiles and the Current Day report's `RTMSnapshots`-driven chart. Not yet built in the RN scaffold — flagged here as a scope decision to make: is per-VQ trend drill-down valuable enough on mobile to justify a 4th screen template, or does it stay desktop-only for v1? Given the mobile UX plan already leans on "notify instead of stare at the grid," this specific feature (manually drilling to find a chart) may be lower priority than the alerting/notification investment discussed earlier — worth a product call, not an engineering one.

**Pagination and search (also confirmed from the real UI, now implemented in the scaffold):** every real report screen shows an explicit page-number control (e.g. "1-12 of 12") and a search box that filters across all visible columns, not just a title field. For mobile: pagination is replaced with standard infinite-scroll (`FlatList` virtualization — no page-number UI needed, this is a deliberate mobile-native deviation from desktop parity, not an oversight), and search-across-all-columns is implemented client-side (`searchUtils.ts`) against the fixtures. Fixture row counts were corrected to match real totals (e.g. 141 rows for Active Agents View, 68 top-level BUs for the Monitoring tree) specifically so search/scroll validation would be meaningful rather than testing against an artificially small sample.

---

## 4. Key User Flows & Interactions to Support

1. **Cold start → login** — native OIDC login (pending client registration), lands on Home
2. **Home glance** — see live enterprise-wide voice/chat health at a glance without navigating anywhere (donuts, bars, trend)
3. **Drawer navigation** — swipe-from-edge or tap-hamburger, browse full category tree, land on Real-time Monitoring
4. **Report list → report detail** — tap a real-time report, see a mobile-appropriate rendering (card list / hierarchy tree / live chart depending on report type), pull-to-refresh
5. **Drill into hierarchy** — expand/collapse BU → vendor → site levels without leaving the screen
6. **(Real, not yet mobile-scoped) Drill to queue-level trend** — on the advisor tree reports, drill down to a specific VQDN and view its own trend chart — see §3 for the newly-discovered `getVQChartDetails` endpoint; open scope question on whether this belongs in mobile v1
7. **Return to Home / switch category** — via drawer, at any depth
8. **(Future) Favorite a report** — star from a report screen, see it surface on Home
9. **(Future) Receive an alert** — push notification when a threshold breaches, tap through to the relevant report

---

## 5. Key Technical Challenges & Constraints

**Confirmed by hands-on work this session, not hypothetical:**
- **Corporate proxy blocked default npm registry** (`407 Proxy Authorization Required` against `registry.npmjs.org`). Resolved by pointing npm at AT&T's internal Artifactory mirror (`apm0013625-npm-group`) with a valid token + explicit proxy config — but this is fragile: one mirror's token had already silently expired, and another mirror returned a non-standard packument shape that broke the React Native CLI's template resolution, requiring a workaround (`--template @react-native-community/template@<version>` pinned explicitly).
- **Corporate TLS interception** (custom root CA) broke unauthenticated downloads (hit this via Playwright's Chromium download). This will affect the RN app's own network calls on real devices unless the corporate CA is trusted via MDM profile — unconfirmed.
- **Auth: implemented and confirmed working, blocked only on a CHIP-issued client ID.** [`react-native-app-auth`](https://github.com/FormidableLabs/react-native-app-auth) 8.4.1 (Nearform, actively maintained) is integrated end-to-end — native AppDelegate/bridging-header wiring on iOS, manifest redirect-scheme config on Android, `pod install` completed successfully. Tapping "Sign in" launches a real native AppAuth session that loads AT&T's actual live login page (`oidc.idp.elogin.att.com`), confirming the integration works correctly all the way to AT&T's identity server.

  **Definitive answer on reusing the web client ID: no.** AT&T's OIDC platform is "Halo.E" (docs: `halo-developer.cso.att.com`), which explicitly defines two RP client types: **Confidential** (can hold a secret; most web apps, including this one — confirmed: the web client's `69437554e8654c54bec80cfd26358cfb` does its code-for-token exchange server-side, no PKCE observed) and **Public** (cannot hold a secret; required for native/mobile apps, must use Authorization Code Flow **with PKCE**). Each app+environment combination gets its own distinct client ID and pre-registered redirect URI — there is no shared/reusable client across web and mobile.

  **What's needed**: submit a new OIDC RP integration via the **Client-Halo Integration Portal (CHIP)** at `https://chip.cso.att.com`, requesting a **Public** client using **Authorization Code Flow with PKCE**. Contrary to an earlier assumption in this doc, **a custom URL scheme redirect (e.g. `com.xample.test.att:/oauthredirect`) is explicitly supported and is Halo.E's documented pattern for native apps** — only web apps are required to use HTTPS FQDN redirects, so no Universal Links/App Links complexity is needed. Non-prod (dev/test/stage, hosted at `oidc.stage.elogin.att.com`) is requested first via a queued form; production is a separate "promotion" step afterward. Client type and PKCE usage are copied from non-prod to production and can't be changed at promotion time, so this must be requested as Public+PKCE from the start. Both the production token endpoint (confirmed directly from Halo.E's own docs: `https://oidc.idp.elogin.att.com/mga/sps/oauth/oauth20/token`) and the authorization endpoint now have first-party confirmation, not just inference from browser capture.

  This library is also provider-agnostic with documented, tested example configs for both generic OIDC and Microsoft/Entra ID specifically, available today. That matters because **AT&T's identity backend is expected to migrate from the current IBM ISAM/TAM to Microsoft Entra ID in a few months** — the later migration should be a config change (issuer, client ID, redirect URI, scopes), not a rewrite.
- **WebSocket auth story is unresolved** — the web app's WS likely rides the session cookie from the browser; a bare RN `WebSocket` has no equivalent cookie jar. Needs a token-based handshake (header or query param), which is a backend change, not just client-side.
- **Backend exposes raw SQL to the browser** (`/api/report/<KEY>` returns `preSelect`, `select2`, `tableName`, `groupBy` fragments). This must not be replicated for mobile — flagged as a security item independent of this project (see §7).
- **The 3 "advisor" tree reports push/return ~1.15-2MB payloads every ~15 seconds**, confirmed by direct capture (Real-time Monitoring, ICM; SBS unconfirmed but likely similar). This is a hard blocker to a naive "just consume the same feed" mobile implementation — see §3 for the confirmed shapes and mitigation options to raise with the backend team.
- **SBS Real-time Monitoring's actual data source is still unknown** after a dedicated capture attempt — the UI shows real, distinct data but no corresponding network/WS activity was observed. Needs another capture pass with full browser DevTools before it can be built for real (currently mocked as a small slice of the main Monitoring tree, explicitly labeled as illustrative-only in code).
- **Distribution channel undefined** — not a public App Store/Play Store app; needs enterprise/MDM distribution (Apple Business Manager, internal catalog), which affects toolchain choice.
- **Toolchain**: chose bare React Native CLI (not Expo managed) specifically because enterprise MDM/App-Protection SDKs typically require native module linking that Expo's managed workflow can't accommodate without ejecting.
- **Native dependency version coupling** — hit a hard version constraint between `react-native-reanimated` 4.6.0 and `react-native-worklets` (needed exactly `0.12.x`); this kind of pinned-peer-dependency fragility should be expected with any future RN/Reanimated upgrades.

---

## 6. Performance & Scalability Requirements

- **WebSocket lifecycle management** — connect on foreground, disconnect on background (implemented via `AppState` listener in `useRealtimeSocket`) to conserve battery/data; reconnect-with-backoff needed for the real socket (mock doesn't yet need it, real one will).
- **Bounded in-memory history** — trend charts use a capped rolling buffer (12 entries) per metric, not unbounded accumulation — same pattern should extend to any future time-series views.
- **List virtualization** — `FlatList` used throughout; if/when historical reports (up to 70 columns, potentially thousands of rows) are added, plan for `FlashList` or equivalent instead of card-per-row rendering of every column.
- **Cellular network resilience** — corporate intranet-only backend means the app is unusable off VPN/MDM tunnel; needs explicit "not connected to corporate network" UX state, not just a spinner.
- **Payload efficiency** — mobile data plans make the desktop's habit of shipping SQL fragments and full metadata blobs on every screen load especially costly; a mobile-tailored endpoint should return only what's rendered.
- **Confirmed, quantified problem case**: Real-time Monitoring pushes a ~2MB tree (2,293 nodes) every ~15s; ICM polls a ~1.15MB tree on the same cadence. At that rate this is roughly 8-14MB/minute per connected client for these two reports alone — untenable on cellular and a real battery/radio cost even on WiFi. The mobile client (already built to lazy-load children on drill-down in `AdvisorTreeScreen`) needs a backend counterpart that actually supports fetching only the expanded subtree, not the full payload with client-side truncation.

---

## 7. Security & Compliance Requirements

- **Auth**: native OIDC (PKCE) once a public client exists; tokens stored in Keychain/Keystore (`react-native-keychain`), never in AsyncStorage or plain files.
- **No SQL/metadata leakage**: the desktop's `/api/report/<KEY>` SQL exposure is a pre-existing issue independent of mobile, but mobile must not consume or cache it — a cleaned mobile-facing endpoint is required.
- **RBAC parity**: reports carry per-report `readPermission`/`writePermission`; mobile must enforce the same visibility rules client-side (already modeled in the catalog structure) and rely on the backend to enforce them server-side too — never trust client-side filtering alone.
- **Corporate network access control**: likely requires MDM-managed VPN/Zscaler tunnel (e.g., Workspace ONE, MobileIron/Ivanti AppConnect) — affects both app distribution and possibly requires an App-Protection SDK integration.
- **Certificate trust**: corporate TLS-interception root CA must be trusted on-device for API calls to succeed at all off preferred networks — needs confirmation from the mobility/security team on how this is provisioned to managed devices.
- **Session handling**: token refresh/expiry, forced logout on revocation, and biometric app-lock (Face ID/Touch ID re-auth) are standard expectations for an internal ops tool with live operational data — not yet implemented.
- **Audit logging parity**: if/when admin actions (approvals, edits) are added to mobile, they need the same audit trail as desktop.
- **Confirmed PII-in-transit**: the Real-time Monitoring and ICM tree payloads both include a `skillMap` block with live employee data — first/last name, employee ID, vendor, site, and current call duration — refreshed continuously. This is real, not a theoretical risk. Mobile should not fetch or cache this block as part of the default report view; if agent-level drill-down is ever needed on mobile, it should be a separate, explicit, audited action, not bundled into the base payload the way the desktop does it today.

---

## 8. Testing & Quality Assurance Requirements

- **Unit tests** — Jest is already scaffolded (`react-native init` default); needs actual test coverage for reducers (`realtimeSlice`), the mock WebSocket, and chart data transforms (donut segment math, trend series extraction).
- **Component/screen tests** — React Native Testing Library for the three reusable screen templates (flat list, hierarchy, live chart) against varying report metadata shapes, since the whole point of the generic renderer pattern is that it must handle all 9 (eventually more) reports correctly.
- **Contract tests against the real backend** — real shapes for 8 of 9 reports are now captured and checked into `src/mocks/realCaptures/`; lock these in as schema fixtures so a backend field rename (already observed once: `NOTREADY` vs `NOT_READY` inconsistency between reports) is caught immediately rather than silently breaking the app. SBS remains the one report needing a real capture (see §3).
- **Real example of why manual navigation testing matters**: a genuine dead-end was shipped and only caught by manual testing — the Real-time Monitoring section (a nested Stack Navigator inside the Drawer) had no way back to the drawer menu, because hiding the Drawer's own header for that route (so the inner stack could show per-report titles) also silently removed the Drawer's auto-injected hamburger button, and the stack's root screen had no back button either. Automated navigation-state tests would need to specifically assert "every reachable screen has a way back to Home" to catch this class of bug, not just "does navigation.navigate() work."
- **E2E** — Detox or Maestro for critical flows (login → Home → drawer → report → back), especially important given React Navigation's drawer/stack interplay.
- **Device/OS matrix** — iOS and Android, at minimum current + previous major OS version; this session only validated iOS Simulator (iPhone 17 Pro) — Android has not yet been verified at all.
- **Network condition testing** — corporate VPN on/off, slow/flaky cellular, WebSocket disconnect/reconnect, since this app is unusually dependent on a specific corporate network topology.
- **Accessibility** — VoiceOver/TalkBack pass on charts and dense stat displays (numeric data in donuts/bars needs accessible labels, not just visual color coding).
- **Security testing** — token storage, certificate handling, and a check that no SQL/internal metadata ever reaches the device, before this goes anywhere near production data.
- **UAT with real supervisors** — the UX bet (cards + drill-down instead of wide tables, notifications instead of constant polling) should be validated with actual users before committing further engineering to the pattern.

---

## 9. Deployment & Maintenance Requirements

- **CI/CD**: needs to run through the same Artifactory npm mirror configuration hit this session — any CI runner will need the same registry/proxy/CA-bundle setup we manually configured locally, or it will fail identically. Document this in the repo's setup instructions (candidate for `AGENTS.md`/CI docs) so it isn't rediscovered painfully by the next engineer or a build agent.
- **Distribution**: enterprise/MDM channel (Apple Business Manager + internal catalog, or Android equivalent), not public stores — provisioning profiles/certs need to be sourced from AT&T's mobile program, not personal developer accounts. (Note: `com.xample.test.att` bundle ID currently set for iOS device builds, tied to a specific Apple Developer account — do not change without explicit instruction.)
- **Crash/error monitoring**: none configured yet (Sentry, AppCenter, or equivalent) — needed before any real user gets a build.
- **OTA update strategy**: consider whether an over-the-air JS update mechanism is available/approved internally (traditional CodePush is deprecated upstream); otherwise every fix requires a full store/MDM redistribution cycle, which matters a lot given this is an internal enterprise app with its own release friction.
- **Dependency/version hygiene**: the reanimated/worklets version coupling hit this session is a preview of ongoing maintenance risk — RN upgrades will need careful peer-dependency verification each time.
- **Runbook for credential expiry**: we personally hit an expired Artifactory token mid-session — worth documenting the token refresh process so it's not a surprise for CI or new team members.

---

## 10. Success Metrics & KPIs

**Adoption**
- % of eligible supervisors/agents (ADVISOR_USER/ATT roles) who install and open the app within 30 days of release
- Weekly active users vs. desktop dashboard's weekly active users (mobile as a genuine complement, not a curiosity)

**Engagement / value delivered**
- Median time from app open to "supervisor has seen current queue health" (should be seconds, not navigation-heavy)
- Recent/Favorites usage rate (signals whether personalization is actually useful once real, not mocked)
- (Once shipped) alert-to-acknowledgment time for threshold-breach push notifications, compared to how long issues currently go unnoticed relying on desktop-only monitoring

**Reliability**
- Crash-free session rate (target: parity with typical enterprise mobile app benchmarks, e.g. >99.5%)
- WebSocket uptime / reconnect success rate on cellular vs. WiFi
- API error rate against the (eventually real, not mocked) backend

**Technical health**
- Time-to-fix for the kind of environment friction hit this session (npm/proxy/cert issues) — should trend toward zero once documented/automated in CI
- Test coverage trend on the reusable screen templates, given they're load-bearing for every current and future report

**Qualitative**
- Supervisor feedback specifically on the "cards + drill-down + notifications" UX bet vs. the desktop's dense-table approach — this is the core hypothesis of the whole mobile effort and should be validated directly, not assumed
