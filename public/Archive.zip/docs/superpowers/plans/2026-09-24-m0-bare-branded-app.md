# M0 — Bare Branded App Implementation Plan

> **For agentic workers:** execute with the Copilot prompt `.github/prompts/execute-plan.prompt.md` (agent mode). With Claude Code, use superpowers:executing-plans instead. Either way: one task at a time, the test must fail before the implementation, and progress is recorded in `2026-09-24-m0-bare-branded-app.progress.md` next to this file. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** A bare React Native app, branded as CCS, shipped to TestFlight as a universal iOS app (iPhone and iPad, all orientations). It opens on a splash screen, lands on a "Real-time dashboard coming soon" screen, and has two build variants (prod and non-prod). Non-prod builds include an environment switcher that prod builds provably don't contain.

**Architecture:** Code is organized by feature, with ports only at the edges (ARCHITECTURE.md §3–4). A tiny local Babel plugin inlines the build constants `__VARIANT__`, `__APP_VERSION__` and `__BUILD_NUMBER__` into the JS at bundle time. Non-prod-only modules are loaded through `__VARIANT__ === 'nonprod' ? require(...) : null` ternaries. Metro's constant folding removes those branches from prod bundles, and a CI script checks the prod bundle to prove it. There's a single composition root, which builds `{ config, logger }` and hands them to the UI through React context.

**Tech Stack:** React Native 0.87.1 (bare CLI, New Architecture), React 19, TypeScript 6 strict, pnpm (hoisted), React Navigation 7 native stack, react-native-bootsplash, react-native-mmkv v4 (+ react-native-nitro-modules), @react-native-firebase/app + crashlytics, Jest + React Native Testing Library, Fastlane.

**Spec:** [`ARCHITECTURE.md`](../../../ARCHITECTURE.md) (esp. §2 M0 row, §4, §5, §8, §9). Conventions: [`AGENTS.md`](../../../AGENTS.md).

## Global Constraints

- React Native **0.87.1**, bare CLI. **No Expo** packages or config. New Architecture on.
- Package manager **pnpm** only; `.npmrc` has `node-linker=hoisted`. Never commit `package-lock.json` or `yarn.lock`.
- Node **>= 22.11**. TypeScript `strict: true`; no `any` without a comment explaining why.
- Only dependencies approved in Task 0 may be added. Anything else: stop and ask.
- Styling uses theme tokens only. No hard-coded colors, spacing, font sizes or radii outside `src/theme/`.
- User-facing strings live in a `strings.ts` next to the code that uses them.
- **iOS first.** M0 native work, runs and distribution are iOS only (iPhone and iPad). Leave `android/` as the template generated it; Android-native steps are marked **DEFERRED** and skipped. JS bundle checks still cover both platforms.
- **Lay out by window size, never by device type.** No `Platform.isPad`, model checks or fixed orientations. iPad Split View, Stage Manager, foldables and rotation are all just window-size changes (ARCHITECTURE.md §8.3).
- Two variants only: `nonprod` and `prod`. Non-prod-only code must never be in a prod JS bundle (`pnpm bundle:verify` enforces this).
- Version format is CalVer `YYYY.M.PATCH`, month not zero-padded (e.g. `2026.9.0`). Build number = CI run number, never set by hand.
- No secrets committed: signing material, `GoogleService-Info.plist` and `google-services.json` are gitignored and injected.
- **`ARCHITECTURE.md` and `docs/superpowers/` are never committed** (the user is still reviewing them). Task 1 adds them to `.git/info/exclude`.
- Conventional Commits (`feat(scope): …`, `chore(scope): …`). Work on branch `feat/m0-bare-app`.
- A task is done only when `pnpm typecheck && pnpm lint && pnpm test` pass.

## Review Focus

1. **A typo in `CCS_VARIANT`** (`production`, `Prod`, `nonProd`) must fail the build loudly, never silently produce a non-prod bundle. Pinned in Task 2, Step 1 (`throws on unknown variant`).
2. **A stale Metro cache** carrying the previous variant's constants into a release bundle (e.g. building prod right after non-prod on the same machine). Pinned in Task 11: `bundle:verify` builds non-prod *then* prod with `--reset-cache`, and Xcode/Gradle bundle steps pass `--reset-cache` (Tasks 12–13).
3. **A corrupt or future-schema environment override in storage** (e.g. `{"tier":"qa"}` or non-JSON written by a later build) must fall back to defaults, not crash at launch. Pinned in Task 8, Step 1 (`ignores corrupt and unknown-schema data`).
4. **The system switching light ↔ dark while the app is open** must re-theme immediately. Pinned in Task 4, Step 1 (`follows scheme changes while mounted`).
5. **Extreme text sizes and window sizes:** the largest accessibility text must scroll, not clip, and a full-width iPad window must not stretch text into unreadable lines. Pinned in Task 6, Step 1 (`Screen scrolls its content`, `Screen caps content width`), with no `numberOfLines` on ComingSoon text (Task 7). Split View and rotation are checked manually in Task 12, Step 5.

---

## File structure (end state of M0)

```
.npmrc                               pnpm hoisting + registry (token via env)
babel.config.js                      preset + build-constants plugin + path aliases
babel/build-constants-plugin.js      inlines __VARIANT__/__APP_VERSION__/__BUILD_NUMBER__
babel/__tests__/build-constants-plugin.test.js
jest.config.js, jest/setup.js        preset, native-module mocks
tsconfig.json                        strict + path aliases
.eslintrc.js                         @react-native + layer boundary rules
index.js                             registers src/app/Root
scripts/calver.js (+ __tests__)      CalVer check/next
scripts/check-bundle.js (+ __tests__) marker check for one bundle
scripts/verify-bundles.js            builds nonprod+prod bundles, runs checks
src/types/build-constants.d.ts       ambient types for the inlined constants
src/app/Root.tsx                     creates services once, renders App
src/app/App.tsx                      providers, root boundary, navigator, splash hide
src/app/compositionRoot.ts           picks adapters, builds Services
src/navigation/types.ts              RootStackParamList
src/navigation/RootNavigator.tsx     stack, screen boundaries, nonprod modal
src/features/coming-soon/            screens/ComingSoonScreen.tsx, strings.ts, __tests__
src/features/env-switcher/           (nonprod only) screens/EnvSwitcherScreen.tsx, strings.ts, __tests__
src/services/context.tsx             Services type, ServicesProvider, useServices
src/services/config/                 types, variants/, index.ts, resolveConfig, describeEnvironment, envOverrideStore
src/services/logging/                types, sanitize, adapters/consoleLogger, adapters/crashlyticsLogger
src/theme/                           tokens, palettes, contrast, ThemeProvider, makeStyles
src/ui/                              Screen, Text, EnvBadge, ErrorBoundary, strings
src/test-utils/renderWithProviders.tsx
assets/brand/ccs-mark.svg            placeholder mark (until icon design)
ios/Config/*.xcconfig                Shared / NonProd / Prod + per-configuration wrappers
ios/fastlane/Fastfile                build + TestFlight upload lanes
docs/setup.md                        corporate network, toolchain, variants runbook
```

---

### Task 0: Inputs and approvals gate (no code)

**Files:** none.

The executor must not start Task 1 until the human has answered every item below. Record the answers at the top of the PR description for Task 1.

- [ ] **Step 1: Collect inputs from the human**

| # | Input | Used in | Default if the human says "use default" |
|---|---|---|---|
| I1 | Base bundle ID (prod): **`com.att.ccsdashboard`** (non-prod = `com.att.ccsdashboard.test`), decided 2026-09-24 | Tasks 12, 13 | decided |
| I2 | Apple Developer Team ID | Task 12 | none, required |
| I3 | iOS deployment target / Android `minSdk`: **iOS 18.0, minSdk 29 (Android 10)**, decided 2026-09-24 | Tasks 12, 13 | decided |
| I4 | Artifactory npm registry URL (the mirror used during discovery) | Task 1, `docs/setup.md` | none, required |
| I5 | Approval of the dependency list in Step 2 | Tasks 1–15 | none, required |
| I6 | Firebase: a non-prod and a prod Firebase app for each platform (App Lead owns the Firebase account), with config files available locally | Task 14 | none, required |
| I7 | App Store Connect (App Lead owns the Apple account): app records for both bundle IDs; API key (key id, issuer id, .p8) | Task 16 | none, required |
| I8 | Do `AGENTS.md`, `.github/copilot-instructions.md` and `docs/discovery/` go into the first commit, and how does `main` get its first commit (direct push or PR)? | Task 1 | none, required |

- [ ] **Step 2: Get explicit approval for these dependencies** (AGENTS.md §2 forbids adding unapproved ones)

| Package | Why | Native impact |
|---|---|---|
| `@react-navigation/native`, `@react-navigation/native-stack` | Root stack + modal group | none beyond the two below |
| `react-native-screens`, `react-native-safe-area-context` | Required by native-stack | pods + gradle |
| `react-native-bootsplash` | Splash hand-off (ARCHITECTURE.md §8.2) | pods + gradle, storyboard + styles |
| `react-native-mmkv` + `react-native-nitro-modules` | Non-prod environment override storage (§5.3) | pods + gradle |
| `@react-native-firebase/app`, `@react-native-firebase/crashlytics` | Crash reporting (§8.5) | pods (SPM, dynamic frameworks) + gradle plugins |
| dev: `@testing-library/react-native` | Component tests | none |
| dev: `babel-plugin-module-resolver` | Path aliases at runtime | none |

Not in M0 (deliberately): Redux Toolkit, RTK Query, react-native-app-auth, keychain, Reanimated, Gesture Handler, react-native-svg, lucide. They arrive with the MVP or with the drawer.

---

### Task 1: Scaffold the app into this repo

**Files:**
- Create: everything the React Native 0.87.1 template produces (`android/`, `ios/`, `index.js`, `app.json`, `package.json`, `babel.config.js`, `metro.config.js`, `jest.config.js`, `tsconfig.json`, `.eslintrc.js`, `.prettierrc.js`, `.watchmanconfig`, `Gemfile`, `.gitignore`)
- Create: `.npmrc`, `jest/setup.js`, `src/app/App.tsx` (moved from root), `src/app/__tests__/App.test.tsx`
- Modify: `.git/info/exclude` (local only, never committed)
- Delete: root `App.tsx`, `__tests__/App.test.tsx`

**Interfaces:**
- Produces: path aliases `@app/*`, `@navigation/*`, `@features/*`, `@services/*`, `@theme/*`, `@ui/*`, `@utils/*`, `@test-utils/*` (mapped to `src/<name>/*`); scripts `pnpm typecheck|lint|test`; module name `CCSDashboard`.

- [ ] **Step 1: Keep review docs out of git (local only)**

```bash
cd <repo root>   # .../ccsdashboard/apm0014857-cct-dashboard-mobile
printf '\n# Under review, never commit (see plan Global Constraints)\nARCHITECTURE.md\ndocs/superpowers/\n' >> .git/info/exclude
git status --short   # ARCHITECTURE.md and docs/superpowers must NOT appear
git checkout -b feat/m0-bare-app
```

- [ ] **Step 2: Generate the template in a scratch directory** (the RN CLI refuses non-empty target directories; the explicit `--template` pin works around the Artifactory packument issue recorded in discovery)

```bash
SCRATCH=$(mktemp -d)
npx @react-native-community/cli@20.2.0 init CCSDashboard \
  --version 0.87.1 \
  --template @react-native-community/template@0.87.1 \
  --pm pnpm --skip-git-init --install-pods false \
  --directory "$SCRATCH/CCSDashboard"
rsync -a --exclude .git --exclude node_modules "$SCRATCH/CCSDashboard/" ./
rm -f package-lock.json yarn.lock
```

Expected: `ios/CCSDashboard.xcodeproj`, `android/`, `App.tsx`, `package.json` with `"name": "CCSDashboard"` now at the repo root. `AGENTS.md`, `docs/` and `.github/` untouched.

- [ ] **Step 3: Write `.npmrc`** (token is read from the environment; never committed)

```ini
node-linker=hoisted
registry=<I4 Artifactory npm registry URL>
//<I4 host and path without protocol>:_authToken=${ARTIFACTORY_NPM_TOKEN}
```

- [ ] **Step 4: Install the approved dev dependencies and the navigation/safe-area stack used from Task 6 on**

```bash
pnpm add -D @testing-library/react-native babel-plugin-module-resolver
pnpm install
```

- [ ] **Step 5: Move `App.tsx` under `src/app/` and point `index.js` at it**

```bash
mkdir -p src/app/__tests__
git mv -f App.tsx src/app/App.tsx 2>/dev/null || mv App.tsx src/app/App.tsx
rm -rf __tests__
```

`index.js`:
```js
import { AppRegistry } from 'react-native';
import App from './src/app/App';
import { name as appName } from './app.json';

AppRegistry.registerComponent(appName, () => App);
```

- [ ] **Step 6: Write the failing alias smoke test** — `src/app/__tests__/App.test.tsx`

```tsx
import React from 'react';
import { render } from '@testing-library/react-native';
import App from '@app/App';

test('renders the app root through the @app alias', () => {
  render(<App />);
});
```

- [ ] **Step 7: Run it to confirm it fails**

Run: `pnpm jest src/app/__tests__/App.test.tsx`
Expected: FAIL with `Cannot find module '@app/App'`.

- [ ] **Step 8: Configure aliases in TypeScript, Babel and Jest**

`tsconfig.json` (TS 6 deprecates `baseUrl`; `paths` are relative to this file):
```json
{
  "extends": "@react-native/typescript-config",
  "compilerOptions": {
    "strict": true,
    "paths": {
      "@app/*": ["./src/app/*"],
      "@navigation/*": ["./src/navigation/*"],
      "@features/*": ["./src/features/*"],
      "@services/*": ["./src/services/*"],
      "@theme/*": ["./src/theme/*"],
      "@ui/*": ["./src/ui/*"],
      "@utils/*": ["./src/utils/*"],
      "@test-utils/*": ["./src/test-utils/*"]
    }
  },
  "include": ["**/*.ts", "**/*.tsx"],
  "exclude": ["**/node_modules", "**/Pods"]
}
```

`babel.config.js`:
```js
const ALIASES = {
  '@app': './src/app',
  '@navigation': './src/navigation',
  '@features': './src/features',
  '@services': './src/services',
  '@theme': './src/theme',
  '@ui': './src/ui',
  '@utils': './src/utils',
  '@test-utils': './src/test-utils',
};

module.exports = api => {
  api.cache.using(() => `${process.env.CCS_VARIANT}|${process.env.CCS_BUILD_NUMBER}`);
  return {
    presets: ['module:@react-native/babel-preset'],
    plugins: [
      ['module-resolver', { extensions: ['.ts', '.tsx', '.js', '.json'], alias: ALIASES }],
    ],
  };
};
```

`jest/setup.js`:
```js
jest.mock('react-native-safe-area-context', () =>
  require('react-native-safe-area-context/jest/mock').default,
);
```

`jest.config.js`:
```js
module.exports = {
  preset: '@react-native/jest-preset',
  setupFiles: ['<rootDir>/jest/setup.js'],
  transformIgnorePatterns: [
    'node_modules/(?!((jest-)?react-native|@react-native(-community)?|@react-navigation|react-native-screens|react-native-safe-area-context|react-native-bootsplash|react-native-mmkv|react-native-nitro-modules|@react-native-firebase)/)',
  ],
};
```

Add `react-native-safe-area-context` now because the mock requires it: `pnpm add react-native-safe-area-context`.

`package.json` scripts (replace the template's `scripts` block):
```json
"scripts": {
  "start": "react-native start",
  "ios:nonprod": "react-native run-ios --scheme CCS-NonProd",
  "test": "jest",
  "lint": "eslint .",
  "typecheck": "tsc --noEmit"
}
```
(`ios:nonprod` starts working after Task 12. An Android script arrives with the deferred Android task.)

- [ ] **Step 9: Run the test, typecheck and lint**

Run: `pnpm jest src/app/__tests__/App.test.tsx && pnpm typecheck && pnpm lint`
Expected: PASS, no type errors, no lint errors.

- [ ] **Step 10: Commit**

Stage only scaffold files; follow the I8 answer for `AGENTS.md`, `.github/`, `docs/discovery/`.
```bash
git add .npmrc .gitignore .eslintrc.js .prettierrc.js .watchmanconfig Gemfile app.json babel.config.js index.js jest.config.js jest/ metro.config.js package.json pnpm-lock.yaml tsconfig.json android ios src
git status --short   # confirm ARCHITECTURE.md and docs/superpowers are absent
git commit -m "chore(app): scaffold React Native 0.87.1 app with pnpm, strict TS and path aliases"
```

---

### Task 2: Build-constants Babel plugin

**Files:**
- Create: `babel/build-constants-plugin.js`, `babel/__tests__/build-constants-plugin.test.js`, `src/types/build-constants.d.ts`
- Modify: `babel.config.js`

**Interfaces:**
- Produces: global constants `__VARIANT__: 'prod' | 'nonprod'`, `__APP_VERSION__: string`, `__BUILD_NUMBER__: string`, inlined as string literals at transform time. Env inputs: `CCS_VARIANT` (default `nonprod`), `CCS_BUILD_NUMBER` (default `0`, digits only).

- [ ] **Step 1: Write the failing tests** — `babel/__tests__/build-constants-plugin.test.js`

```js
/** @jest-environment node */
const { transformSync } = require('@babel/core');
const plugin = require('../build-constants-plugin');
const { version } = require('../../package.json');

function transform(code, env = {}) {
  const saved = { ...process.env };
  delete process.env.CCS_VARIANT;
  delete process.env.CCS_BUILD_NUMBER;
  Object.assign(process.env, env);
  try {
    return transformSync(code, { plugins: [plugin], babelrc: false, configFile: false }).code;
  } finally {
    process.env = saved;
  }
}

test('defaults to nonprod and build 0', () => {
  expect(transform('x = __VARIANT__; y = __BUILD_NUMBER__;')).toBe('x = "nonprod";\ny = "0";');
});

test('inlines prod and the build number from the environment', () => {
  expect(transform('x = __VARIANT__ + __BUILD_NUMBER__;', { CCS_VARIANT: 'prod', CCS_BUILD_NUMBER: '42' }))
    .toBe('x = "prod" + "42";');
});

test('inlines the package.json version', () => {
  expect(transform('v = __APP_VERSION__;')).toBe(`v = "${version}";`);
});

test('throws on unknown variant instead of falling back', () => {
  for (const bad of ['production', 'Prod', 'nonProd', '']) {
    expect(() => transform('x = __VARIANT__;', { CCS_VARIANT: bad })).toThrow(/CCS_VARIANT/);
  }
});

test('throws on a non-numeric build number', () => {
  expect(() => transform('x = 1;', { CCS_BUILD_NUMBER: '12a' })).toThrow(/CCS_BUILD_NUMBER/);
});

test('leaves locally bound identifiers with the same name alone', () => {
  expect(transform('function f(__VARIANT__) { return __VARIANT__; }'))
    .toBe('function f(__VARIANT__) {\n  return __VARIANT__;\n}');
});
```

- [ ] **Step 2: Run to confirm failure**

Run: `pnpm jest babel/__tests__/build-constants-plugin.test.js`
Expected: FAIL with `Cannot find module '../build-constants-plugin'`.

- [ ] **Step 3: Implement** — `babel/build-constants-plugin.js`

```js
// Inlines build constants as string literals so Metro's constant folding can
// drop non-prod branches from prod bundles (ARCHITECTURE.md §5.3).
const { version } = require('../package.json');

const VARIANTS = ['prod', 'nonprod'];

function readConstants() {
  const variant = process.env.CCS_VARIANT === undefined ? 'nonprod' : process.env.CCS_VARIANT;
  if (!VARIANTS.includes(variant)) {
    throw new Error(`CCS_VARIANT must be one of ${VARIANTS.join(', ')}; got "${variant}"`);
  }
  const buildNumber = process.env.CCS_BUILD_NUMBER === undefined ? '0' : process.env.CCS_BUILD_NUMBER;
  if (!/^\d+$/.test(buildNumber)) {
    throw new Error(`CCS_BUILD_NUMBER must be digits only; got "${buildNumber}"`);
  }
  return { __VARIANT__: variant, __APP_VERSION__: version, __BUILD_NUMBER__: buildNumber };
}

module.exports = function buildConstantsPlugin({ types: t }) {
  return {
    name: 'ccs-build-constants',
    pre() {
      this.constants = readConstants();
    },
    visitor: {
      Identifier(path) {
        const { name } = path.node;
        if (!Object.prototype.hasOwnProperty.call(this.constants, name)) return;
        if (!path.isReferencedIdentifier() || path.scope.hasBinding(name, true)) return;
        path.replaceWith(t.stringLiteral(this.constants[name]));
      },
    },
  };
};
```

- [ ] **Step 4: Register the plugin and declare the globals**

In `babel.config.js`, make the plugin list:
```js
    plugins: [
      './babel/build-constants-plugin',
      ['module-resolver', { extensions: ['.ts', '.tsx', '.js', '.json'], alias: ALIASES }],
    ],
```

`src/types/build-constants.d.ts`:
```ts
// Inlined at bundle time by babel/build-constants-plugin.js.
declare const __VARIANT__: 'prod' | 'nonprod';
declare const __APP_VERSION__: string;
declare const __BUILD_NUMBER__: string;
```

- [ ] **Step 5: Run the tests**

Run: `pnpm jest babel && pnpm typecheck && pnpm lint`
Expected: 6 passed; no type or lint errors. If ESLint flags `process`/`require` in `babel/`, add to `.eslintrc.js`: `overrides: [{ files: ['babel/**', 'scripts/**', 'jest/**', 'src/test-utils/**', '*.config.js'], env: { node: true, jest: true } }]`.

- [ ] **Step 6: Commit**

```bash
git add babel babel.config.js src/types .eslintrc.js
git commit -m "feat(build): inline variant, version and build number at bundle time"
```

---

### Task 3: Config service

**Files:**
- Create: `src/services/config/types.ts`, `src/services/config/variants/nonprod.ts`, `src/services/config/variants/prod.ts`, `src/services/config/index.ts`, `src/services/config/resolveConfig.ts`, `src/services/config/describeEnvironment.ts`, `src/services/config/__tests__/resolveConfig.test.ts`, `src/services/config/__tests__/describeEnvironment.test.ts`

**Interfaces:**
- Consumes: `__VARIANT__`, `__APP_VERSION__`, `__BUILD_NUMBER__` (Task 2).
- Produces:
  - `type Variant = 'prod' | 'nonprod'`; `type Tier = 'dev' | 'stage' | 'prod'`; `type NonProdTier = Exclude<Tier, 'prod'>`
  - `interface BaseConfig { variant: Variant; tier: Tier; useMocks: boolean }`
  - `interface BuildInfo { appVersion: string; buildNumber: string }`
  - `interface AppConfig extends BaseConfig, BuildInfo {}`
  - `interface EnvOverride { tier: NonProdTier; useMocks: boolean }`
  - `baseConfig: BaseConfig`, `buildInfo: BuildInfo` (from `@services/config`)
  - `resolveConfig(base: BaseConfig, build: BuildInfo, override: EnvOverride | null): AppConfig`
  - `describeEnvironment(config: AppConfig): string | null`

- [ ] **Step 1: Write failing tests**

`src/services/config/__tests__/resolveConfig.test.ts`:
```ts
import { resolveConfig } from '../resolveConfig';
import { nonprodBase } from '../variants/nonprod';
import { prodBase } from '../variants/prod';

const build = { appVersion: '2026.9.0', buildNumber: '7' };

test('non-prod without override uses the dev tier with mocks', () => {
  expect(resolveConfig(nonprodBase, build, null)).toEqual({
    variant: 'nonprod', tier: 'dev', useMocks: true, appVersion: '2026.9.0', buildNumber: '7',
  });
});

test('non-prod applies a stored override', () => {
  expect(resolveConfig(nonprodBase, build, { tier: 'stage', useMocks: false })).toMatchObject({
    variant: 'nonprod', tier: 'stage', useMocks: false,
  });
});

test('prod ignores any override', () => {
  expect(resolveConfig(prodBase, build, { tier: 'dev', useMocks: true })).toEqual({
    variant: 'prod', tier: 'prod', useMocks: false, appVersion: '2026.9.0', buildNumber: '7',
  });
});
```

`src/services/config/__tests__/describeEnvironment.test.ts`:
```ts
import { describeEnvironment } from '../describeEnvironment';

const build = { appVersion: '2026.9.0', buildNumber: '7' };

test('prod has no environment label', () => {
  expect(describeEnvironment({ variant: 'prod', tier: 'prod', useMocks: false, ...build })).toBeNull();
});

test('non-prod shows BETA, tier and MOCK', () => {
  expect(describeEnvironment({ variant: 'nonprod', tier: 'dev', useMocks: true, ...build })).toBe('BETA · DEV · MOCK');
  expect(describeEnvironment({ variant: 'nonprod', tier: 'stage', useMocks: false, ...build })).toBe('BETA · STAGE');
});
```

- [ ] **Step 2: Run to confirm failure**

Run: `pnpm jest src/services/config`
Expected: FAIL, modules not found.

- [ ] **Step 3: Implement**

`src/services/config/types.ts`:
```ts
export type Variant = 'prod' | 'nonprod';
export type Tier = 'dev' | 'stage' | 'prod';
export type NonProdTier = Exclude<Tier, 'prod'>;

export interface BaseConfig {
  readonly variant: Variant;
  readonly tier: Tier;
  readonly useMocks: boolean;
}

export interface BuildInfo {
  readonly appVersion: string;
  readonly buildNumber: string;
}

export interface AppConfig extends BaseConfig, BuildInfo {}

export interface EnvOverride {
  readonly tier: NonProdTier;
  readonly useMocks: boolean;
}
```

`src/services/config/variants/nonprod.ts`:
```ts
import type { BaseConfig } from '../types';

export const nonprodBase: BaseConfig = { variant: 'nonprod', tier: 'dev', useMocks: true };
```

`src/services/config/variants/prod.ts`:
```ts
import type { BaseConfig } from '../types';

export const prodBase: BaseConfig = { variant: 'prod', tier: 'prod', useMocks: false };
```

`src/services/config/resolveConfig.ts`:
```ts
import type { AppConfig, BaseConfig, BuildInfo, EnvOverride } from './types';

export function resolveConfig(base: BaseConfig, build: BuildInfo, override: EnvOverride | null): AppConfig {
  if (base.variant === 'prod' || override === null) {
    return { ...base, ...build };
  }
  return { ...base, ...build, tier: override.tier, useMocks: override.useMocks };
}
```

`src/services/config/describeEnvironment.ts`:
```ts
import type { AppConfig } from './types';

export function describeEnvironment(config: AppConfig): string | null {
  if (config.variant === 'prod') {
    return null;
  }
  const parts = ['BETA', config.tier.toUpperCase()];
  if (config.useMocks) {
    parts.push('MOCK');
  }
  return parts.join(' · ');
}
```

`src/services/config/index.ts`:
```ts
import type { BaseConfig, BuildInfo } from './types';
import { nonprodBase } from './variants/nonprod';
import { prodBase } from './variants/prod';

export const baseConfig: BaseConfig = __VARIANT__ === 'prod' ? prodBase : nonprodBase;

export const buildInfo: BuildInfo = { appVersion: __APP_VERSION__, buildNumber: __BUILD_NUMBER__ };

export type { AppConfig, BaseConfig, BuildInfo, EnvOverride, NonProdTier, Tier, Variant } from './types';
```

- [ ] **Step 4: Run tests, typecheck, lint**

Run: `pnpm jest src/services/config && pnpm typecheck && pnpm lint`
Expected: 5 passed; clean.

- [ ] **Step 5: Commit**

```bash
git add src/services/config
git commit -m "feat(config): typed per-variant config with non-prod override resolution"
```

---

### Task 4: Theme tokens and provider

**Files:**
- Create: `src/theme/tokens.ts`, `src/theme/palettes.ts`, `src/theme/contrast.ts`, `src/theme/ThemeProvider.tsx`, `src/theme/makeStyles.ts`, `src/theme/index.ts`, `src/theme/__tests__/palettes.test.ts`, `src/theme/__tests__/ThemeProvider.test.tsx`

**Interfaces:**
- Produces:
  - `interface ColorTokens { background; surface; textPrimary; textMuted; border; accent; onAccent; statusGood; statusWarn; statusBad }` (all `string`)
  - `interface Theme { scheme: 'light' | 'dark'; colors: ColorTokens; spacing; radius; typography; layout }` where `layout.maxContentWidth = 640`
  - `ThemeProvider({ children, useScheme? })` where `useScheme` defaults to RN `useColorScheme`
  - `useTheme(): Theme`
  - `makeStyles(factory: (theme: Theme) => T): () => T`
  - `contrastRatio(hexA: string, hexB: string): number`
  - `lightColors`, `darkColors`

- [ ] **Step 1: Write failing tests**

`src/theme/__tests__/palettes.test.ts`:
```ts
import { contrastRatio } from '../contrast';
import { darkColors, lightColors } from '../palettes';

test('light and dark palettes define identical keys', () => {
  expect(Object.keys(darkColors).sort()).toEqual(Object.keys(lightColors).sort());
});

test('contrastRatio matches known WCAG values', () => {
  expect(contrastRatio('#000000', '#FFFFFF')).toBeCloseTo(21, 1);
  expect(contrastRatio('#FFFFFF', '#FFFFFF')).toBeCloseTo(1, 5);
});

describe.each([
  ['light', lightColors],
  ['dark', darkColors],
])('%s palette meets WCAG AA', (_name, c) => {
  test('primary text on background >= 7:1', () => {
    expect(contrastRatio(c.textPrimary, c.background)).toBeGreaterThanOrEqual(7);
  });
  test('muted text on background and surface >= 4.5:1', () => {
    expect(contrastRatio(c.textMuted, c.background)).toBeGreaterThanOrEqual(4.5);
    expect(contrastRatio(c.textMuted, c.surface)).toBeGreaterThanOrEqual(4.5);
  });
  test('onAccent on accent >= 4.5:1', () => {
    expect(contrastRatio(c.onAccent, c.accent)).toBeGreaterThanOrEqual(4.5);
  });
  test('status colors on surface >= 3:1 (non-text UI)', () => {
    for (const status of [c.statusGood, c.statusWarn, c.statusBad]) {
      expect(contrastRatio(status, c.surface)).toBeGreaterThanOrEqual(3);
    }
  });
});
```

`src/theme/__tests__/ThemeProvider.test.tsx`:
```tsx
import React, { useState } from 'react';
import { Text } from 'react-native';
import { act, render, screen } from '@testing-library/react-native';
import { ThemeProvider, useTheme } from '..';
import { darkColors, lightColors } from '../palettes';

let setScheme: (s: 'light' | 'dark') => void = () => {};
function useFakeScheme() {
  const [scheme, set] = useState<'light' | 'dark'>('light');
  setScheme = set;
  return scheme;
}

function Probe() {
  const theme = useTheme();
  return <Text testID="probe">{`${theme.scheme}:${theme.colors.background}`}</Text>;
}

test('follows scheme changes while mounted', () => {
  render(
    <ThemeProvider useScheme={useFakeScheme}>
      <Probe />
    </ThemeProvider>,
  );
  expect(screen.getByTestId('probe')).toHaveTextContent(`light:${lightColors.background}`);
  act(() => setScheme('dark'));
  expect(screen.getByTestId('probe')).toHaveTextContent(`dark:${darkColors.background}`);
});

test('useTheme outside a provider throws a clear error', () => {
  jest.spyOn(console, 'error').mockImplementation(() => {});
  expect(() => render(<Probe />)).toThrow('useTheme must be used inside ThemeProvider');
});
```

- [ ] **Step 2: Run to confirm failure**

Run: `pnpm jest src/theme`
Expected: FAIL, modules not found.

- [ ] **Step 3: Implement**

`src/theme/palettes.ts`:
```ts
export interface ColorTokens {
  readonly background: string;
  readonly surface: string;
  readonly textPrimary: string;
  readonly textMuted: string;
  readonly border: string;
  readonly accent: string;
  readonly onAccent: string;
  readonly statusGood: string;
  readonly statusWarn: string;
  readonly statusBad: string;
}

// Placeholder CCS palette: neutral base + one accent. Design will replace the
// values (ARCHITECTURE.md §8.1); keys must stay identical across schemes.
export const lightColors: ColorTokens = {
  background: '#F7F8FA',
  surface: '#FFFFFF',
  textPrimary: '#0E1726',
  textMuted: '#5B6576',
  border: '#E3E7ED',
  accent: '#2F5BEA',
  onAccent: '#FFFFFF',
  statusGood: '#1F8A4C',
  statusWarn: '#B26A00',
  statusBad: '#C4312B',
};

export const darkColors: ColorTokens = {
  background: '#0B0F17',
  surface: '#151B26',
  textPrimary: '#F2F4F8',
  textMuted: '#9AA4B5',
  border: '#263041',
  accent: '#7C9BFF',
  onAccent: '#0B0F17',
  statusGood: '#4CC38A',
  statusWarn: '#F2B24C',
  statusBad: '#FF6B61',
};
```

`src/theme/tokens.ts`:
```ts
export const spacing = { none: 0, xs: 4, sm: 8, md: 12, lg: 16, xl: 24, xxl: 32, xxxl: 48 } as const;

export const radius = { sm: 6, md: 12, lg: 20, pill: 999 } as const;

// Window-width rules (ARCHITECTURE.md §8.3). Content never stretches past a
// readable width on iPad or unfolded foldables.
export const layout = { maxContentWidth: 640 } as const;

// System fonts (SF Pro / Roboto): Dynamic Type for free, no bundling (ARCHITECTURE.md §8.1).
export const typography = {
  display: { fontSize: 34, lineHeight: 41, fontWeight: '700' },
  title: { fontSize: 22, lineHeight: 28, fontWeight: '600' },
  body: { fontSize: 17, lineHeight: 22, fontWeight: '400' },
  caption: { fontSize: 13, lineHeight: 18, fontWeight: '400' },
  label: { fontSize: 12, lineHeight: 16, fontWeight: '600', letterSpacing: 0.6 },
} as const;

export type TypographyVariant = keyof typeof typography;
```

`src/theme/contrast.ts`:
```ts
function channel(value: number): number {
  const c = value / 255;
  return c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4;
}

function luminance(hex: string): number {
  const n = parseInt(hex.replace('#', ''), 16);
  const r = channel((n >> 16) & 0xff);
  const g = channel((n >> 8) & 0xff);
  const b = channel(n & 0xff);
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}

export function contrastRatio(hexA: string, hexB: string): number {
  const [hi, lo] = [luminance(hexA), luminance(hexB)].sort((a, b) => b - a);
  return (hi + 0.05) / (lo + 0.05);
}
```

`src/theme/ThemeProvider.tsx`:
```tsx
import React, { createContext, useContext, useMemo, type ReactNode } from 'react';
import { useColorScheme } from 'react-native';
import { darkColors, lightColors, type ColorTokens } from './palettes';
import { layout, radius, spacing, typography } from './tokens';

export interface Theme {
  readonly scheme: 'light' | 'dark';
  readonly colors: ColorTokens;
  readonly spacing: typeof spacing;
  readonly radius: typeof radius;
  readonly typography: typeof typography;
  readonly layout: typeof layout;
}

const ThemeContext = createContext<Theme | null>(null);

interface Props {
  children: ReactNode;
  // Injectable so tests (and a later user override) can drive the scheme.
  useScheme?: () => string | null | undefined;
}

export function ThemeProvider({ children, useScheme = useColorScheme }: Props) {
  const scheme = useScheme() === 'dark' ? 'dark' : 'light';
  const theme = useMemo<Theme>(
    () => ({ scheme, colors: scheme === 'dark' ? darkColors : lightColors, spacing, radius, typography, layout }),
    [scheme],
  );
  return <ThemeContext.Provider value={theme}>{children}</ThemeContext.Provider>;
}

export function useTheme(): Theme {
  const theme = useContext(ThemeContext);
  if (theme === null) {
    throw new Error('useTheme must be used inside ThemeProvider');
  }
  return theme;
}
```

`src/theme/makeStyles.ts`:
```ts
import { useMemo } from 'react';
import { StyleSheet } from 'react-native';
import { useTheme, type Theme } from './ThemeProvider';

export function makeStyles<T extends StyleSheet.NamedStyles<T>>(factory: (theme: Theme) => T): () => T {
  return function useStyles(): T {
    const theme = useTheme();
    return useMemo(() => StyleSheet.create(factory(theme)), [theme]);
  };
}
```

`src/theme/index.ts`:
```ts
export { ThemeProvider, useTheme, type Theme } from './ThemeProvider';
export { makeStyles } from './makeStyles';
export type { ColorTokens } from './palettes';
export type { TypographyVariant } from './tokens';
```

- [ ] **Step 4: Run tests, typecheck, lint**

Run: `pnpm jest src/theme && pnpm typecheck && pnpm lint`
Expected: all pass. If a contrast assertion fails, adjust **only** that palette value until it passes and note it in the commit body.

- [ ] **Step 5: Commit**

```bash
git add src/theme
git commit -m "feat(theme): semantic light/dark tokens with WCAG contrast checks"
```

---

### Task 5: Logging port, redaction, console adapter, services context

**Files:**
- Create: `src/services/logging/types.ts`, `src/services/logging/sanitize.ts`, `src/services/logging/adapters/consoleLogger.ts`, `src/services/logging/__tests__/sanitize.test.ts`, `src/services/context.tsx`, `src/app/compositionRoot.ts`, `src/test-utils/renderWithProviders.tsx`

**Interfaces:**
- Consumes: `baseConfig`, `buildInfo`, `resolveConfig`, `AppConfig` (Task 3).
- Produces:
  - `type LogContextKey = 'route' | 'feature' | 'component' | 'boundary' | 'errorKind'`
  - `type LogContext = Partial<Record<LogContextKey, string>>`
  - `interface Logger { info(message: string, context?: LogContext): void; error(error: unknown, context?: LogContext): void }`
  - `sanitizeContext(context: unknown): LogContext`, `toError(value: unknown): Error`
  - `createConsoleLogger(): Logger`
  - `interface Services { config: AppConfig; logger: Logger }`, `ServicesProvider({ value, children })`, `useServices(): Services`
  - `createServices(): Services`
  - `makeTestServices(overrides?: Partial<Services>): Services`, `renderWithProviders(ui, { services? })`

- [ ] **Step 1: Write failing tests** — `src/services/logging/__tests__/sanitize.test.ts`

```ts
import { sanitizeContext, toError } from '../sanitize';

test('keeps only allow-listed string keys', () => {
  expect(
    sanitizeContext({
      route: 'ComingSoon',
      feature: 'coming-soon',
      token: 'eyJhbGciOi...',
      authorization: 'Bearer abc',
      email: 'someone@att.com',
      errorKind: 'network',
    }),
  ).toEqual({ route: 'ComingSoon', feature: 'coming-soon', errorKind: 'network' });
});

test('drops non-string values and truncates long ones', () => {
  const long = 'x'.repeat(500);
  expect(sanitizeContext({ route: 42, component: long })).toEqual({ component: 'x'.repeat(100) });
});

test('tolerates non-object input', () => {
  expect(sanitizeContext(undefined)).toEqual({});
  expect(sanitizeContext('route=Home')).toEqual({});
});

test('toError wraps non-Error values without leaking them', () => {
  const err = toError({ accessToken: 'secret' });
  expect(err).toBeInstanceOf(Error);
  expect(err.message).toBe('Non-Error value thrown (object)');
  const real = new Error('boom');
  expect(toError(real)).toBe(real);
});
```

- [ ] **Step 2: Run to confirm failure**

Run: `pnpm jest src/services/logging`
Expected: FAIL, module not found.

- [ ] **Step 3: Implement logging**

`src/services/logging/types.ts`:
```ts
export type LogContextKey = 'route' | 'feature' | 'component' | 'boundary' | 'errorKind';

export type LogContext = Partial<Record<LogContextKey, string>>;

export interface Logger {
  info(message: string, context?: LogContext): void;
  error(error: unknown, context?: LogContext): void;
}
```

`src/services/logging/sanitize.ts`:
```ts
import type { LogContext, LogContextKey } from './types';

// Allow-list, not deny-list: anything not named here never leaves the device
// (AGENTS.md §8: no tokens, PII or KPI values in logs).
const ALLOWED_KEYS: ReadonlyArray<LogContextKey> = ['route', 'feature', 'component', 'boundary', 'errorKind'];
const MAX_VALUE_LENGTH = 100;

export function sanitizeContext(context: unknown): LogContext {
  if (typeof context !== 'object' || context === null) {
    return {};
  }
  const source = context as Record<string, unknown>;
  const clean: LogContext = {};
  for (const key of ALLOWED_KEYS) {
    const value = source[key];
    if (typeof value === 'string') {
      clean[key] = value.slice(0, MAX_VALUE_LENGTH);
    }
  }
  return clean;
}

export function toError(value: unknown): Error {
  if (value instanceof Error) {
    return value;
  }
  return new Error(`Non-Error value thrown (${typeof value})`);
}
```

`src/services/logging/adapters/consoleLogger.ts`:
```ts
import { sanitizeContext, toError } from '../sanitize';
import type { Logger } from '../types';

export function createConsoleLogger(): Logger {
  return {
    info(message, context) {
      console.log(`[ccs] ${message}`, sanitizeContext(context));
    },
    error(error, context) {
      console.warn('[ccs] error', toError(error).message, sanitizeContext(context));
    },
  };
}
```

- [ ] **Step 4: Implement the services context and composition root**

`src/services/context.tsx`:
```tsx
import React, { createContext, useContext, type ReactNode } from 'react';
import type { AppConfig } from './config';
import type { Logger } from './logging/types';

export interface Services {
  readonly config: AppConfig;
  readonly logger: Logger;
}

const ServicesContext = createContext<Services | null>(null);

export function ServicesProvider({ value, children }: { value: Services; children: ReactNode }) {
  return <ServicesContext.Provider value={value}>{children}</ServicesContext.Provider>;
}

export function useServices(): Services {
  const services = useContext(ServicesContext);
  if (services === null) {
    throw new Error('useServices must be used inside ServicesProvider');
  }
  return services;
}
```

`src/app/compositionRoot.ts`:
```ts
import { baseConfig, buildInfo } from '@services/config';
import { resolveConfig } from '@services/config/resolveConfig';
import type { Services } from '@services/context';
import { createConsoleLogger } from '@services/logging/adapters/consoleLogger';

// The only place adapters are chosen (ARCHITECTURE.md §4.1 rule 2).
export function createServices(): Services {
  return {
    config: resolveConfig(baseConfig, buildInfo, null),
    logger: createConsoleLogger(),
  };
}
```

`src/test-utils/renderWithProviders.tsx`:
```tsx
import React, { type ReactElement } from 'react';
import { render } from '@testing-library/react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { ServicesProvider, type Services } from '@services/context';
import { ThemeProvider } from '@theme/index';

export function makeTestServices(overrides: Partial<Services> = {}): Services {
  return {
    config: { variant: 'nonprod', tier: 'dev', useMocks: true, appVersion: '2026.9.0', buildNumber: '7' },
    logger: { info: jest.fn(), error: jest.fn() },
    ...overrides,
  };
}

export function renderWithProviders(ui: ReactElement, { services = makeTestServices() }: { services?: Services } = {}) {
  return {
    services,
    ...render(
      <SafeAreaProvider>
        <ServicesProvider value={services}>
          <ThemeProvider>{ui}</ThemeProvider>
        </ServicesProvider>
      </SafeAreaProvider>,
    ),
  };
}
```

- [ ] **Step 5: Run tests, typecheck, lint**

Run: `pnpm jest src/services && pnpm typecheck && pnpm lint`
Expected: all pass.

- [ ] **Step 6: Commit**

```bash
git add src/services src/app/compositionRoot.ts src/test-utils
git commit -m "feat(logging): allow-list redacting logger port, console adapter and services context"
```

---

### Task 6: UI primitives

**Files:**
- Create: `src/ui/Screen.tsx`, `src/ui/Text.tsx`, `src/ui/EnvBadge.tsx`, `src/ui/ErrorBoundary.tsx`, `src/ui/strings.ts`, `src/ui/index.ts`, `src/ui/__tests__/Screen.test.tsx`, `src/ui/__tests__/EnvBadge.test.tsx`, `src/ui/__tests__/ErrorBoundary.test.tsx`

**Interfaces:**
- Consumes: `makeStyles`, `useTheme`, `TypographyVariant` (Task 4); `renderWithProviders` (Task 5).
- Produces:
  - `Screen({ children, testID? })`: safe-area, themed background, **scrolling** content (`testID="screen-scroll"`), centered and capped at `theme.layout.maxContentWidth` (`testID="screen-content"`)
  - `Text({ variant?: TypographyVariant = 'body', tone?: 'primary' | 'muted' | 'accent' | 'onAccent' = 'primary', ...TextProps })`
  - `EnvBadge({ label: string })`
  - `ErrorBoundary({ level: 'root' | 'screen' | 'widget', resetKeys?: ReadonlyArray<unknown>, onError?: (error: unknown) => void, children })`
  - `ui/` imports nothing from `@services`, `@features`, `@navigation`, `@app` (Task 9 enforces this)

- [ ] **Step 1: Write failing tests**

`src/ui/__tests__/Screen.test.tsx`:
```tsx
import React from 'react';
import { screen } from '@testing-library/react-native';
import { renderWithProviders } from '@test-utils/renderWithProviders';
import { Screen, Text } from '..';

test('Screen scrolls its content so large Dynamic Type never clips', () => {
  renderWithProviders(
    <Screen>
      <Text>Hello</Text>
    </Screen>,
  );
  const scroll = screen.getByTestId('screen-scroll');
  expect(scroll.type).toBe('RCTScrollView');
  expect(screen.getByText('Hello')).toBeOnTheScreen();
});

test('Screen caps content width so iPad and unfolded layouts stay readable', () => {
  renderWithProviders(
    <Screen>
      <Text>Wide</Text>
    </Screen>,
  );
  expect(screen.getByTestId('screen-content')).toHaveStyle({ width: '100%', maxWidth: 640, alignSelf: 'center' });
});
```

`src/ui/__tests__/EnvBadge.test.tsx`:
```tsx
import React from 'react';
import { screen } from '@testing-library/react-native';
import { renderWithProviders } from '@test-utils/renderWithProviders';
import { EnvBadge } from '..';

test('renders the label with an accessible description', () => {
  renderWithProviders(<EnvBadge label="BETA · DEV · MOCK" />);
  expect(screen.getByText('BETA · DEV · MOCK')).toBeOnTheScreen();
  expect(screen.getByLabelText('Environment: BETA · DEV · MOCK')).toBeOnTheScreen();
});
```

`src/ui/__tests__/ErrorBoundary.test.tsx`:
```tsx
import React from 'react';
import { Text as RNText } from 'react-native';
import { fireEvent, screen } from '@testing-library/react-native';
import { renderWithProviders } from '@test-utils/renderWithProviders';
import { ErrorBoundary } from '..';
import { uiStrings } from '../strings';

let shouldThrow = true;
function Bomb() {
  if (shouldThrow) {
    throw new Error('kaboom');
  }
  return <RNText>recovered</RNText>;
}

beforeEach(() => {
  shouldThrow = true;
  jest.spyOn(console, 'error').mockImplementation(() => {});
});

test.each([
  ['root', uiStrings.rootTitle],
  ['screen', uiStrings.screenTitle],
  ['widget', uiStrings.widgetUnavailable],
] as const)('%s level renders its fallback and reports the error', (level, text) => {
  const onError = jest.fn();
  renderWithProviders(
    <ErrorBoundary level={level} onError={onError}>
      <Bomb />
    </ErrorBoundary>,
  );
  expect(screen.getByText(text)).toBeOnTheScreen();
  expect(onError).toHaveBeenCalledWith(expect.objectContaining({ message: 'kaboom' }));
});

test('Try again resets the boundary', () => {
  renderWithProviders(
    <ErrorBoundary level="root">
      <Bomb />
    </ErrorBoundary>,
  );
  shouldThrow = false;
  fireEvent.press(screen.getByRole('button', { name: uiStrings.retry }));
  expect(screen.getByText('recovered')).toBeOnTheScreen();
});

test('changing resetKeys resets the boundary', () => {
  const view = renderWithProviders(
    <ErrorBoundary level="screen" resetKeys={['a']}>
      <Bomb />
    </ErrorBoundary>,
  );
  shouldThrow = false;
  view.rerender(
    <ErrorBoundary level="screen" resetKeys={['b']}>
      <Bomb />
    </ErrorBoundary>,
  );
  expect(screen.getByText('recovered')).toBeOnTheScreen();
});
```

Note: `rerender` replaces the whole tree passed to `render`, dropping providers. If that breaks theming, change the test to wrap with the same providers: import `SafeAreaProvider`, `ServicesProvider`, `ThemeProvider` and `makeTestServices`, and pass the fully wrapped tree to `view.rerender`.

- [ ] **Step 2: Run to confirm failure**

Run: `pnpm jest src/ui`
Expected: FAIL, modules not found.

- [ ] **Step 3: Implement**

`src/ui/strings.ts`:
```ts
export const uiStrings = {
  rootTitle: 'Something went wrong',
  rootBody: 'Please try again. If this keeps happening, restart the app.',
  screenTitle: "This screen couldn't load",
  screenBody: 'Try again, or go back.',
  widgetUnavailable: 'Unavailable',
  retry: 'Try again',
  environmentLabel: (label: string) => `Environment: ${label}`,
} as const;
```

`src/ui/Text.tsx`:
```tsx
import React from 'react';
import { Text as RNText, type TextProps } from 'react-native';
import { useTheme, type ColorTokens, type TypographyVariant } from '@theme/index';

type Tone = 'primary' | 'muted' | 'accent' | 'onAccent';

const TONE_TO_TOKEN: Record<Tone, keyof ColorTokens> = {
  primary: 'textPrimary',
  muted: 'textMuted',
  accent: 'accent',
  onAccent: 'onAccent',
};

interface Props extends TextProps {
  variant?: TypographyVariant;
  tone?: Tone;
}

export function Text({ variant = 'body', tone = 'primary', style, ...rest }: Props) {
  const theme = useTheme();
  return <RNText style={[theme.typography[variant], { color: theme.colors[TONE_TO_TOKEN[tone]] }, style]} {...rest} />;
}
```

`src/ui/Screen.tsx`:
```tsx
import React, { type ReactNode } from 'react';
import { ScrollView, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { makeStyles } from '@theme/index';

const useStyles = makeStyles(theme => ({
  safeArea: { flex: 1, backgroundColor: theme.colors.background },
  scrollContent: { flexGrow: 1, padding: theme.spacing.xl },
  // Width-driven, not device-driven: fills phones, centers on iPad/foldables.
  content: { flexGrow: 1, width: '100%', maxWidth: theme.layout.maxContentWidth, alignSelf: 'center' },
}));

export function Screen({ children, testID }: { children: ReactNode; testID?: string }) {
  const styles = useStyles();
  return (
    <SafeAreaView style={styles.safeArea} edges={['top', 'bottom', 'left', 'right']} testID={testID}>
      <ScrollView contentContainerStyle={styles.scrollContent} testID="screen-scroll">
        <View style={styles.content} testID="screen-content">
          {children}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}
```

`src/ui/EnvBadge.tsx`:
```tsx
import React from 'react';
import { View } from 'react-native';
import { makeStyles } from '@theme/index';
import { uiStrings } from './strings';
import { Text } from './Text';

const useStyles = makeStyles(theme => ({
  badge: {
    alignSelf: 'center',
    borderRadius: theme.radius.pill,
    borderWidth: 1,
    borderColor: theme.colors.accent,
    paddingHorizontal: theme.spacing.md,
    paddingVertical: theme.spacing.xs,
  },
}));

export function EnvBadge({ label }: { label: string }) {
  const styles = useStyles();
  return (
    <View style={styles.badge} accessible accessibilityLabel={uiStrings.environmentLabel(label)}>
      <Text variant="label" tone="accent">
        {label}
      </Text>
    </View>
  );
}
```

`src/ui/ErrorBoundary.tsx`:
```tsx
import React, { Component, type ReactNode } from 'react';
import { Pressable, View } from 'react-native';
import { makeStyles } from '@theme/index';
import { uiStrings } from './strings';
import { Text } from './Text';

type Level = 'root' | 'screen' | 'widget';

interface Props {
  level: Level;
  resetKeys?: ReadonlyArray<unknown>;
  // Injected by the caller so ui/ never imports services (ARCHITECTURE.md §4.1 rule 3).
  onError?: (error: unknown) => void;
  children: ReactNode;
}

interface State {
  hasError: boolean;
}

function keysChanged(a: ReadonlyArray<unknown> = [], b: ReadonlyArray<unknown> = []): boolean {
  return a.length !== b.length || a.some((value, i) => !Object.is(value, b[i]));
}

export class ErrorBoundary extends Component<Props, State> {
  state: State = { hasError: false };

  static getDerivedStateFromError(): State {
    return { hasError: true };
  }

  componentDidCatch(error: unknown) {
    this.props.onError?.(error);
  }

  componentDidUpdate(prev: Props) {
    if (this.state.hasError && keysChanged(prev.resetKeys, this.props.resetKeys)) {
      this.reset();
    }
  }

  reset = () => this.setState({ hasError: false });

  render() {
    if (!this.state.hasError) {
      return this.props.children;
    }
    return <ErrorFallback level={this.props.level} onRetry={this.reset} />;
  }
}

const useStyles = makeStyles(theme => ({
  full: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: theme.spacing.xl, gap: theme.spacing.md, backgroundColor: theme.colors.background },
  widget: { padding: theme.spacing.md, borderRadius: theme.radius.md, borderWidth: 1, borderColor: theme.colors.border, backgroundColor: theme.colors.surface },
  button: { paddingHorizontal: theme.spacing.xl, paddingVertical: theme.spacing.md, borderRadius: theme.radius.pill, backgroundColor: theme.colors.accent },
}));

function ErrorFallback({ level, onRetry }: { level: Level; onRetry: () => void }) {
  const styles = useStyles();
  if (level === 'widget') {
    return (
      <View style={styles.widget}>
        <Text tone="muted">{uiStrings.widgetUnavailable}</Text>
      </View>
    );
  }
  return (
    <View style={styles.full}>
      <Text variant="title" accessibilityRole="header">
        {level === 'root' ? uiStrings.rootTitle : uiStrings.screenTitle}
      </Text>
      <Text tone="muted">{level === 'root' ? uiStrings.rootBody : uiStrings.screenBody}</Text>
      <Pressable accessibilityRole="button" accessibilityLabel={uiStrings.retry} onPress={onRetry} style={styles.button}>
        <Text tone="onAccent">{uiStrings.retry}</Text>
      </Pressable>
    </View>
  );
}
```

`src/ui/index.ts`:
```ts
export { EnvBadge } from './EnvBadge';
export { ErrorBoundary } from './ErrorBoundary';
export { Screen } from './Screen';
export { Text } from './Text';
```

- [ ] **Step 4: Run tests, typecheck, lint**

Run: `pnpm jest src/ui && pnpm typecheck && pnpm lint`
Expected: all pass.

- [ ] **Step 5: Commit**

```bash
git add src/ui
git commit -m "feat(ui): Screen, Text, EnvBadge and three-level ErrorBoundary primitives"
```

---

### Task 7: Navigation, ComingSoon screen, app root

**Files:**
- Create: `src/navigation/types.ts`, `src/navigation/RootNavigator.tsx`, `src/features/coming-soon/strings.ts`, `src/features/coming-soon/screens/ComingSoonScreen.tsx`, `src/features/coming-soon/__tests__/ComingSoonScreen.test.tsx`, `src/app/Root.tsx`
- Modify: `src/app/App.tsx` (replace template), `src/app/__tests__/App.test.tsx`, `index.js`
- Remove dependency: `@react-native/new-app-screen`

**Interfaces:**
- Consumes: `useServices`, `Services` (Task 5); `describeEnvironment` (Task 3); `Screen`, `Text`, `EnvBadge`, `ErrorBoundary` (Task 6); `makeStyles`, `useTheme` (Task 4); `createServices` (Task 5).
- Produces:
  - `type RootStackParamList = { ComingSoon: undefined; EnvSwitcher: undefined }`
  - `RootNavigator({ onReady?: () => void })`
  - `App({ services }: { services: Services })` (named export) and `Root` (default export of `src/app/Root.tsx`)
  - `ComingSoonScreen` with `onLongPress` (1500 ms) on the version line that navigates to `EnvSwitcher` **only when `config.variant === 'nonprod'`**

- [ ] **Step 1: Install navigation**

```bash
pnpm add @react-navigation/native @react-navigation/native-stack react-native-screens
pnpm remove @react-native/new-app-screen
```

- [ ] **Step 2: Write failing tests**

`src/features/coming-soon/__tests__/ComingSoonScreen.test.tsx`:
```tsx
import React from 'react';
import { fireEvent, screen } from '@testing-library/react-native';
import { makeTestServices, renderWithProviders } from '@test-utils/renderWithProviders';
import { ComingSoonScreen } from '../screens/ComingSoonScreen';
import { comingSoonStrings } from '../strings';

function renderScreen(services = makeTestServices()) {
  const navigation = { navigate: jest.fn() };
  // Only `navigation.navigate` is used by this screen.
  const props = { navigation, route: { key: 'ComingSoon-1', name: 'ComingSoon' } } as unknown as React.ComponentProps<typeof ComingSoonScreen>;
  renderWithProviders(<ComingSoonScreen {...props} />, { services });
  return navigation;
}

test('shows the coming-soon message and the version', () => {
  renderScreen();
  expect(screen.getByText(comingSoonStrings.headline)).toBeOnTheScreen();
  expect(screen.getByText('Version 2026.9.0 (7)')).toBeOnTheScreen();
});

test('non-prod shows the environment badge and long-press opens the switcher', () => {
  const navigation = renderScreen();
  expect(screen.getByText('BETA · DEV · MOCK')).toBeOnTheScreen();
  fireEvent(screen.getByText('Version 2026.9.0 (7)'), 'longPress');
  expect(navigation.navigate).toHaveBeenCalledWith('EnvSwitcher');
});

test('prod shows no badge and long-press does nothing', () => {
  const navigation = renderScreen(
    makeTestServices({ config: { variant: 'prod', tier: 'prod', useMocks: false, appVersion: '2026.9.0', buildNumber: '7' } }),
  );
  expect(screen.queryByText(/BETA/)).toBeNull();
  fireEvent(screen.getByText('Version 2026.9.0 (7)'), 'longPress');
  expect(navigation.navigate).not.toHaveBeenCalled();
});

test('no text is line-limited (large Dynamic Type must wrap, not clip)', () => {
  renderScreen();
  for (const node of screen.UNSAFE_root.findAll(n => n.props.numberOfLines !== undefined)) {
    throw new Error(`Unexpected numberOfLines on ${String(node.type)}`);
  }
});
```

Replace `src/app/__tests__/App.test.tsx`:
```tsx
import React from 'react';
import { render, screen } from '@testing-library/react-native';
import { makeTestServices } from '@test-utils/renderWithProviders';
import { App } from '@app/App';
import { comingSoonStrings } from '@features/coming-soon/strings';

test('boots straight to the coming-soon screen', async () => {
  render(<App services={makeTestServices()} />);
  expect(await screen.findByText(comingSoonStrings.headline)).toBeOnTheScreen();
});
```

- [ ] **Step 3: Run to confirm failure**

Run: `pnpm jest src/features/coming-soon src/app`
Expected: FAIL, modules not found / `App` is not a named export.

- [ ] **Step 4: Implement**

`src/navigation/types.ts`:
```ts
import type { NativeStackScreenProps } from '@react-navigation/native-stack';

export type RootStackParamList = {
  ComingSoon: undefined;
  // Registered only in non-prod builds (ARCHITECTURE.md §5.3).
  EnvSwitcher: undefined;
};

export type RootStackScreenProps<T extends keyof RootStackParamList> = NativeStackScreenProps<RootStackParamList, T>;
```

`src/features/coming-soon/strings.ts`:
```ts
export const comingSoonStrings = {
  appName: 'CCS',
  headline: 'Real-time dashboard coming soon',
  body: 'Live contact-center KPIs for leadership, at a glance.',
  version: (appVersion: string, buildNumber: string) => `Version ${appVersion} (${buildNumber})`,
  envSwitcherHint: 'Long-press to open environment settings',
} as const;
```

`src/features/coming-soon/screens/ComingSoonScreen.tsx`:
```tsx
import React from 'react';
import { Pressable, View } from 'react-native';
import type { RootStackScreenProps } from '@navigation/types';
import { describeEnvironment } from '@services/config/describeEnvironment';
import { useServices } from '@services/context';
import { makeStyles } from '@theme/index';
import { EnvBadge, Screen, Text } from '@ui/index';
import { comingSoonStrings as strings } from '../strings';

const useStyles = makeStyles(theme => ({
  hero: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: theme.spacing.md },
  mark: {
    width: 72,
    height: 72,
    borderRadius: theme.radius.lg,
    backgroundColor: theme.colors.accent,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: theme.spacing.lg,
  },
  centered: { textAlign: 'center' },
  footer: { alignItems: 'center', gap: theme.spacing.sm, paddingTop: theme.spacing.xl },
}));

export function ComingSoonScreen({ navigation }: RootStackScreenProps<'ComingSoon'>) {
  const { config } = useServices();
  const styles = useStyles();
  const envLabel = describeEnvironment(config);
  const canOpenEnvSwitcher = config.variant === 'nonprod';

  return (
    <Screen>
      <View style={styles.hero}>
        <View style={styles.mark} accessibilityElementsHidden importantForAccessibility="no-hide-descendants">
          <Text variant="title" tone="onAccent">
            {strings.appName}
          </Text>
        </View>
        <Text variant="title" accessibilityRole="header" style={styles.centered}>
          {strings.headline}
        </Text>
        <Text tone="muted" style={styles.centered}>
          {strings.body}
        </Text>
      </View>
      <View style={styles.footer}>
        {envLabel !== null ? <EnvBadge label={envLabel} /> : null}
        <Pressable
          onLongPress={canOpenEnvSwitcher ? () => navigation.navigate('EnvSwitcher') : undefined}
          delayLongPress={1500}
          accessibilityHint={canOpenEnvSwitcher ? strings.envSwitcherHint : undefined}>
          <Text variant="caption" tone="muted">
            {strings.version(config.appVersion, config.buildNumber)}
          </Text>
        </Pressable>
      </View>
    </Screen>
  );
}
```

`src/navigation/RootNavigator.tsx`:
```tsx
import React, { useCallback, useMemo } from 'react';
import { DarkTheme, DefaultTheme, NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { ComingSoonScreen } from '@features/coming-soon/screens/ComingSoonScreen';
import { useServices } from '@services/context';
import { useTheme } from '@theme/index';
import { ErrorBoundary } from '@ui/index';
import type { RootStackParamList } from './types';

const Stack = createNativeStackNavigator<RootStackParamList>();

export function RootNavigator({ onReady }: { onReady?: () => void }) {
  const theme = useTheme();
  const { logger } = useServices();

  const navigationTheme = useMemo(() => {
    const base = theme.scheme === 'dark' ? DarkTheme : DefaultTheme;
    return {
      ...base,
      colors: {
        ...base.colors,
        background: theme.colors.background,
        card: theme.colors.surface,
        text: theme.colors.textPrimary,
        border: theme.colors.border,
        primary: theme.colors.accent,
      },
    };
  }, [theme]);

  const screenLayout = useCallback(
    ({ children, route }: { children: React.ReactNode; route: { key: string; name: string } }) => (
      <ErrorBoundary
        level="screen"
        resetKeys={[route.key]}
        onError={error => logger.error(error, { boundary: 'screen', route: route.name })}>
        {children}
      </ErrorBoundary>
    ),
    [logger],
  );

  return (
    <NavigationContainer theme={navigationTheme} onReady={onReady}>
      <Stack.Navigator screenOptions={{ headerShown: false }} screenLayout={screenLayout}>
        <Stack.Screen name="ComingSoon" component={ComingSoonScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
```

`src/app/App.tsx` (replace the template entirely):
```tsx
import React, { useCallback } from 'react';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { RootNavigator } from '@navigation/RootNavigator';
import { ServicesProvider, type Services } from '@services/context';
import { ThemeProvider } from '@theme/index';
import { ErrorBoundary } from '@ui/index';

export function App({ services }: { services: Services }) {
  const onRootError = useCallback((error: unknown) => services.logger.error(error, { boundary: 'root' }), [services]);

  return (
    <SafeAreaProvider>
      <ServicesProvider value={services}>
        <ThemeProvider>
          <ErrorBoundary level="root" onError={onRootError}>
            <RootNavigator />
          </ErrorBoundary>
        </ThemeProvider>
      </ServicesProvider>
    </SafeAreaProvider>
  );
}
```

`src/app/Root.tsx`:
```tsx
import React, { useState } from 'react';
import { App } from './App';
import { createServices } from './compositionRoot';

export default function Root() {
  const [services] = useState(createServices);
  return <App services={services} />;
}
```

`index.js`:
```js
import { AppRegistry } from 'react-native';
import Root from './src/app/Root';
import { name as appName } from './app.json';

AppRegistry.registerComponent(appName, () => Root);
```

- [ ] **Step 5: Run tests, typecheck, lint**

Run: `pnpm jest && pnpm typecheck && pnpm lint`
Expected: all pass. If `screenLayout`'s parameter type doesn't match the installed React Navigation typings, import the navigator's own type instead: `NonNullable<React.ComponentProps<typeof Stack.Navigator>['screenLayout']>`.

- [ ] **Step 6: Manual check on the iOS simulator** (variants arrive in Task 12; use the template scheme for now)

```bash
cd ios && bundle install && bundle exec pod install && cd ..
pnpm start --reset-cache &   # in a separate terminal
pnpm react-native run-ios --scheme CCSDashboard
```
Expected: the ComingSoon screen with the "CCS" mark, headline, body, the `BETA · DEV · MOCK` badge and `Version 0.0.1 (0)`. Toggle Settings → Developer → Dark Appearance: colors switch without a restart.

- [ ] **Step 7: Commit**

```bash
git add src/navigation src/features/coming-soon src/app index.js package.json pnpm-lock.yaml ios/Podfile.lock
git commit -m "feat(coming-soon): root stack with screen boundaries and the coming-soon screen"
```

---

### Task 8: Non-prod environment switcher

**Files:**
- Create: `src/services/config/envOverrideStore.ts`, `src/services/config/__tests__/envOverrideStore.test.ts`, `src/features/env-switcher/strings.ts`, `src/features/env-switcher/screens/EnvSwitcherScreen.tsx`, `src/features/env-switcher/__tests__/EnvSwitcherScreen.test.tsx`
- Modify: `src/app/compositionRoot.ts`, `src/navigation/RootNavigator.tsx`, `jest/setup.js`

**Interfaces:**
- Consumes: `EnvOverride`, `NonProdTier` (Task 3); `useServices` (Task 5); UI primitives (Task 6); `RootStackScreenProps` (Task 7).
- Produces:
  - `ENV_OVERRIDE_STORE_ID = 'ccs-nonprod-env-override'`: **this string is the non-prod bundle marker used by Task 11**
  - `interface KeyValueStorage { getString(key: string): string | undefined; set(key: string, value: string): void; remove(key: string): unknown }`
  - `createEnvOverrideStore(storage: KeyValueStorage): { read(): EnvOverride | null; write(o: EnvOverride): void; clear(): void }`
  - `getEnvOverrideStore()`: lazily created, MMKV-backed singleton
  - `EnvSwitcherScreen`

- [ ] **Step 1: Write failing store tests** — `src/services/config/__tests__/envOverrideStore.test.ts`

```ts
import { createEnvOverrideStore, ENV_OVERRIDE_STORE_ID, type KeyValueStorage } from '../envOverrideStore';

function memoryStorage(): KeyValueStorage & { data: Map<string, string> } {
  const data = new Map<string, string>();
  return {
    data,
    getString: key => data.get(key),
    set: (key, value) => void data.set(key, value),
    remove: key => data.delete(key),
  };
}

test('round-trips an override', () => {
  const store = createEnvOverrideStore(memoryStorage());
  expect(store.read()).toBeNull();
  store.write({ tier: 'stage', useMocks: false });
  expect(store.read()).toEqual({ tier: 'stage', useMocks: false });
  store.clear();
  expect(store.read()).toBeNull();
});

test('ignores corrupt and unknown-schema data', () => {
  const storage = memoryStorage();
  const store = createEnvOverrideStore(storage);
  for (const raw of ['not json', '{"tier":"qa","useMocks":true}', '{"tier":"stage"}', 'null', '[]', '{"tier":"prod","useMocks":false}']) {
    storage.data.set('override', raw);
    expect(store.read()).toBeNull();
  }
});

test('store id matches the marker the prod-bundle check looks for', () => {
  // eslint-disable-next-line @typescript-eslint/no-require-imports -- plain CJS script
  const { NONPROD_ONLY_MARKERS } = require('../../../../scripts/check-bundle') as { NONPROD_ONLY_MARKERS: string[] };
  expect(NONPROD_ONLY_MARKERS).toContain(ENV_OVERRIDE_STORE_ID);
});
```

The third test stays red until Task 11. Mark it `test.skip` now with a comment `// enabled in Task 11`; Task 11 Step 5 removes the `.skip`.

- [ ] **Step 2: Run to confirm failure**

Run: `pnpm jest src/services/config/__tests__/envOverrideStore.test.ts`
Expected: FAIL, module not found.

- [ ] **Step 3: Implement the store**

```bash
pnpm add react-native-mmkv react-native-nitro-modules
```

`src/services/config/envOverrideStore.ts`:
```ts
import { createMMKV } from 'react-native-mmkv';
import type { EnvOverride } from './types';

// Non-prod only. This id doubles as the marker `pnpm bundle:verify` searches
// for: it must never appear in a prod bundle (ARCHITECTURE.md §5.3).
export const ENV_OVERRIDE_STORE_ID = 'ccs-nonprod-env-override';
const KEY = 'override';

export interface KeyValueStorage {
  getString(key: string): string | undefined;
  set(key: string, value: string): void;
  remove(key: string): unknown;
}

function isEnvOverride(value: unknown): value is EnvOverride {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) {
    return false;
  }
  const candidate = value as Record<string, unknown>;
  return (candidate.tier === 'dev' || candidate.tier === 'stage') && typeof candidate.useMocks === 'boolean';
}

export function createEnvOverrideStore(storage: KeyValueStorage) {
  return {
    read(): EnvOverride | null {
      const raw = storage.getString(KEY);
      if (raw === undefined) {
        return null;
      }
      try {
        const parsed: unknown = JSON.parse(raw);
        return isEnvOverride(parsed) ? { tier: parsed.tier, useMocks: parsed.useMocks } : null;
      } catch {
        return null;
      }
    },
    write(override: EnvOverride): void {
      storage.set(KEY, JSON.stringify(override));
    },
    clear(): void {
      storage.remove(KEY);
    },
  };
}

export type EnvOverrideStore = ReturnType<typeof createEnvOverrideStore>;

let defaultStore: EnvOverrideStore | undefined;

export function getEnvOverrideStore(): EnvOverrideStore {
  defaultStore ??= createEnvOverrideStore(createMMKV({ id: ENV_OVERRIDE_STORE_ID }));
  return defaultStore;
}
```

Append to `jest/setup.js` (deterministic in-memory MMKV for tests):
```js
jest.mock('react-native-mmkv', () => {
  const stores = new Map();
  return {
    createMMKV: ({ id = 'mmkv.default' } = {}) => {
      if (!stores.has(id)) stores.set(id, new Map());
      const data = stores.get(id);
      return {
        getString: key => data.get(key),
        set: (key, value) => void data.set(key, value),
        remove: key => data.delete(key),
        clearAll: () => data.clear(),
      };
    },
  };
});
```

- [ ] **Step 4: Run store tests**

Run: `pnpm jest src/services/config`
Expected: PASS (the skipped marker test is reported as skipped).

- [ ] **Step 5: Write failing screen tests** — `src/features/env-switcher/__tests__/EnvSwitcherScreen.test.tsx`

```tsx
import React from 'react';
import { fireEvent, screen } from '@testing-library/react-native';
import { getEnvOverrideStore } from '@services/config/envOverrideStore';
import { makeTestServices, renderWithProviders } from '@test-utils/renderWithProviders';
import { EnvSwitcherScreen } from '../screens/EnvSwitcherScreen';
import { envSwitcherStrings as strings } from '../strings';

type Props = React.ComponentProps<typeof EnvSwitcherScreen>;
const props = { navigation: {}, route: { key: 'EnvSwitcher-1', name: 'EnvSwitcher' } } as unknown as Props;

beforeEach(() => getEnvOverrideStore().clear());

test('saving persists the chosen tier and mock setting and asks for a restart', () => {
  renderWithProviders(<EnvSwitcherScreen {...props} />);
  fireEvent.press(screen.getByRole('radio', { name: strings.tierLabel.stage }));
  fireEvent(screen.getByRole('switch', { name: strings.mocksLabel }), 'valueChange', false);
  fireEvent.press(screen.getByRole('button', { name: strings.save }));
  expect(getEnvOverrideStore().read()).toEqual({ tier: 'stage', useMocks: false });
  expect(screen.getByText(strings.restartNotice)).toBeOnTheScreen();
});

test('reset clears the stored override', () => {
  getEnvOverrideStore().write({ tier: 'stage', useMocks: false });
  renderWithProviders(<EnvSwitcherScreen {...props} />);
  fireEvent.press(screen.getByRole('button', { name: strings.reset }));
  expect(getEnvOverrideStore().read()).toBeNull();
});

test('test non-fatal is reported through the logger, not Crashlytics directly', () => {
  const services = makeTestServices();
  renderWithProviders(<EnvSwitcherScreen {...props} />, { services });
  fireEvent.press(screen.getByRole('button', { name: strings.testNonFatal }));
  expect(services.logger.error).toHaveBeenCalledWith(
    expect.objectContaining({ message: 'CCS test non-fatal' }),
    { feature: 'env-switcher' },
  );
});
```

- [ ] **Step 6: Run to confirm failure**

Run: `pnpm jest src/features/env-switcher`
Expected: FAIL, module not found.

- [ ] **Step 7: Implement the screen**

`src/features/env-switcher/strings.ts`:
```ts
import type { NonProdTier } from '@services/config';

export const envSwitcherStrings = {
  title: 'Environment',
  current: (label: string) => `Running: ${label}`,
  tierHeading: 'Backend tier',
  tierLabel: { dev: 'Dev', stage: 'Stage' } satisfies Record<NonProdTier, string>,
  mocksLabel: 'Use mock data',
  save: 'Save',
  reset: 'Reset to defaults',
  restartNotice: 'Saved. Close and reopen the app to apply.',
  testNonFatal: 'Send test non-fatal to Crashlytics',
  testNonFatalSent: 'Test non-fatal sent.',
} as const;
```

`src/features/env-switcher/screens/EnvSwitcherScreen.tsx`:
```tsx
import React, { useState } from 'react';
import { Pressable, Switch, View } from 'react-native';
import type { RootStackScreenProps } from '@navigation/types';
import type { EnvOverride, NonProdTier } from '@services/config';
import { describeEnvironment } from '@services/config/describeEnvironment';
import { getEnvOverrideStore } from '@services/config/envOverrideStore';
import { useServices } from '@services/context';
import { makeStyles, useTheme } from '@theme/index';
import { Screen, Text } from '@ui/index';
import { envSwitcherStrings as strings } from '../strings';

const TIERS: ReadonlyArray<NonProdTier> = ['dev', 'stage'];

const useStyles = makeStyles(theme => ({
  section: { gap: theme.spacing.sm, marginBottom: theme.spacing.xl },
  option: { padding: theme.spacing.lg, borderRadius: theme.radius.md, borderWidth: 1, borderColor: theme.colors.border, backgroundColor: theme.colors.surface },
  optionSelected: { borderColor: theme.colors.accent, borderWidth: 2 },
  row: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  primaryButton: { alignItems: 'center', padding: theme.spacing.lg, borderRadius: theme.radius.pill, backgroundColor: theme.colors.accent },
  secondaryButton: { alignItems: 'center', padding: theme.spacing.lg },
}));

export function EnvSwitcherScreen(_props: RootStackScreenProps<'EnvSwitcher'>) {
  const { config, logger } = useServices();
  const theme = useTheme();
  const styles = useStyles();
  const store = getEnvOverrideStore();
  const [draft, setDraft] = useState<EnvOverride>(
    () => store.read() ?? { tier: config.tier === 'prod' ? 'dev' : config.tier, useMocks: config.useMocks },
  );
  const [notice, setNotice] = useState<string | null>(null);

  const update = (next: Partial<EnvOverride>) => {
    setDraft(current => ({ ...current, ...next }));
    setNotice(null);
  };

  return (
    <Screen>
      <View style={styles.section}>
        <Text tone="muted">{strings.current(describeEnvironment(config) ?? '')}</Text>
      </View>
      <View style={styles.section}>
        <Text variant="title" accessibilityRole="header">
          {strings.tierHeading}
        </Text>
        {TIERS.map(tier => (
          <Pressable
            key={tier}
            accessibilityRole="radio"
            accessibilityLabel={strings.tierLabel[tier]}
            accessibilityState={{ checked: draft.tier === tier }}
            onPress={() => update({ tier })}
            style={[styles.option, draft.tier === tier && styles.optionSelected]}>
            <Text>{strings.tierLabel[tier]}</Text>
          </Pressable>
        ))}
      </View>
      <View style={[styles.section, styles.row]}>
        <Text>{strings.mocksLabel}</Text>
        <Switch
          accessibilityLabel={strings.mocksLabel}
          value={draft.useMocks}
          onValueChange={useMocks => update({ useMocks })}
          trackColor={{ true: theme.colors.accent, false: theme.colors.border }}
        />
      </View>
      <View style={styles.section}>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel={strings.save}
          style={styles.primaryButton}
          onPress={() => {
            store.write(draft);
            setNotice(strings.restartNotice);
          }}>
          <Text tone="onAccent">{strings.save}</Text>
        </Pressable>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel={strings.reset}
          style={styles.secondaryButton}
          onPress={() => {
            store.clear();
            setNotice(strings.restartNotice);
          }}>
          <Text tone="accent">{strings.reset}</Text>
        </Pressable>
        {notice !== null ? <Text tone="muted">{notice}</Text> : null}
      </View>
      <Pressable
        accessibilityRole="button"
        accessibilityLabel={strings.testNonFatal}
        style={styles.secondaryButton}
        onPress={() => {
          logger.error(new Error('CCS test non-fatal'), { feature: 'env-switcher' });
          setNotice(strings.testNonFatalSent);
        }}>
        <Text tone="accent">{strings.testNonFatal}</Text>
      </Pressable>
    </Screen>
  );
}
```

- [ ] **Step 8: Wire it in only for non-prod**

`src/app/compositionRoot.ts`: replace the `config:` line and add the override read:
```ts
import { baseConfig, buildInfo, type EnvOverride } from '@services/config';
// ...
function readEnvOverride(): EnvOverride | null {
  // Ternary + require so Metro constant-folds the store out of prod bundles
  // (ARCHITECTURE.md §5.3). An early `return` would leave the require reachable to the bundler.
  return __VARIANT__ === 'nonprod'
    ? // eslint-disable-next-line @typescript-eslint/no-require-imports -- conditional non-prod module
      (require('@services/config/envOverrideStore') as typeof import('@services/config/envOverrideStore'))
        .getEnvOverrideStore()
        .read()
    : null;
}

export function createServices(): Services {
  return {
    config: resolveConfig(baseConfig, buildInfo, readEnvOverride()),
    logger: createConsoleLogger(),
  };
}
```

`src/navigation/RootNavigator.tsx`: add below the `Stack` declaration:
```tsx
import type { RootStackScreenProps } from './types';

// Resolved at bundle time; prod bundles never contain the switcher (ARCHITECTURE.md §5.3).
const EnvSwitcherScreen: React.ComponentType<RootStackScreenProps<'EnvSwitcher'>> | null =
  __VARIANT__ === 'nonprod'
    ? // eslint-disable-next-line @typescript-eslint/no-require-imports -- conditional non-prod module
      (require('@features/env-switcher/screens/EnvSwitcherScreen') as typeof import('@features/env-switcher/screens/EnvSwitcherScreen'))
        .EnvSwitcherScreen
    : null;
```
and inside `<Stack.Navigator>` after the ComingSoon screen:
```tsx
        {EnvSwitcherScreen !== null ? (
          <Stack.Group screenOptions={{ presentation: 'modal', headerShown: true, title: 'Environment' }}>
            <Stack.Screen name="EnvSwitcher" component={EnvSwitcherScreen} />
          </Stack.Group>
        ) : null}
```
Move `'Environment'` into `src/navigation/strings.ts` as `export const navigationStrings = { envSwitcherTitle: 'Environment' } as const;` and use `navigationStrings.envSwitcherTitle`.

- [ ] **Step 9: Run all tests, typecheck, lint**

Run: `pnpm jest && pnpm typecheck && pnpm lint`
Expected: all pass (one skipped).

- [ ] **Step 10: Manual check**

```bash
cd ios && bundle exec pod install && cd ..
pnpm react-native run-ios --scheme CCSDashboard
```
Long-press the version line for 1.5 s → the Environment modal opens. Choose Stage, turn mocks off, Save, kill and relaunch the app → the badge reads `BETA · STAGE`.

- [ ] **Step 11: Commit**

```bash
git add src jest/setup.js package.json pnpm-lock.yaml ios/Podfile.lock
git commit -m "feat(env-switcher): non-prod tier and mock override with test non-fatal"
```

---

### Task 9: Layer boundary lint rules

**Files:**
- Modify: `.eslintrc.js`

**Interfaces:**
- Produces: lint errors for the ARCHITECTURE.md §4.1 rules. Later features must add their own cross-feature block (pattern shown below).

- [ ] **Step 1: Write a deliberate violation** (temporary, never committed)

`src/features/coming-soon/__violation__.ts`:
```ts
import { createConsoleLogger } from '@services/logging/adapters/consoleLogger';
import { createMMKV } from 'react-native-mmkv';
import { EnvSwitcherScreen } from '@features/env-switcher/screens/EnvSwitcherScreen';
export const v = [createConsoleLogger, createMMKV, EnvSwitcherScreen];
```
`src/ui/__violation__.ts`:
```ts
import { useServices } from '@services/context';
export const v = useServices;
```

- [ ] **Step 2: Run lint to confirm it currently passes (i.e. the rules are missing)**

Run: `pnpm eslint src/features/coming-soon/__violation__.ts src/ui/__violation__.ts`
Expected: no `no-restricted-imports` errors.

- [ ] **Step 3: Add the rules** — `.eslintrc.js`

```js
const ADAPTERS = {
  group: ['**/adapters/**'],
  message: 'Features depend on service ports, never adapters (ARCHITECTURE.md §4.1).',
};
const NATIVE_MODULES = {
  group: ['react-native-mmkv', '@react-native-firebase/*', 'react-native-bootsplash'],
  message: 'Native modules are wrapped by services/ or app/ (ARCHITECTURE.md §4.1).',
};
const APP_LAYER = { group: ['@app/*'], message: 'Only index.js imports app/.' };

function featureRules(name) {
  return {
    files: [`src/features/${name}/**`],
    rules: {
      'no-restricted-imports': [
        'error',
        {
          patterns: [
            ADAPTERS,
            NATIVE_MODULES,
            APP_LAYER,
            { group: ['@features/*', `!@features/${name}/**`], message: 'Features never import other features (ARCHITECTURE.md §4.1).' },
          ],
        },
      ],
    },
  };
}

module.exports = {
  root: true,
  extends: '@react-native',
  overrides: [
    { files: ['babel/**', 'scripts/**', 'jest/**', 'src/test-utils/**', '*.config.js', '.eslintrc.js'], env: { node: true, jest: true } },
    featureRules('coming-soon'),
    featureRules('env-switcher'),
    {
      files: ['src/ui/**', 'src/theme/**'],
      rules: {
        'no-restricted-imports': [
          'error',
          {
            patterns: [
              { group: ['@services/*', '@features/*', '@navigation/*', '@app/*'], message: 'ui/ and theme/ know nothing about services, features or navigation (ARCHITECTURE.md §4.1).' },
              NATIVE_MODULES,
            ],
          },
        ],
      },
    },
  ],
};
```

- [ ] **Step 4: Confirm the violations are now caught**

Run: `pnpm eslint src/features/coming-soon/__violation__.ts src/ui/__violation__.ts`
Expected: 4 errors: adapters, `react-native-mmkv`, the cross-feature import, and `@services/context` from `ui/`.

- [ ] **Step 5: Delete the violation files and lint the whole repo**

```bash
rm src/features/coming-soon/__violation__.ts src/ui/__violation__.ts
pnpm lint
```
Expected: clean. (`RootNavigator` imports features, which is allowed. `navigation/` is the composition layer for screens.)

- [ ] **Step 6: Commit**

```bash
git add .eslintrc.js
git commit -m "chore(lint): enforce layer boundaries between features, services, ui and theme"
```

---

### Task 10: CalVer versioning

**Files:**
- Create: `scripts/calver.js`, `scripts/__tests__/calver.test.js`
- Modify: `package.json` (`version`, scripts)

**Interfaces:**
- Produces: `isCalVer(v: string): boolean`, `nextCalVer(current: string, now: Date): string`; CLI `node scripts/calver.js check|next`; scripts `version:check`, `version:next`.

- [ ] **Step 1: Write failing tests** — `scripts/__tests__/calver.test.js`

```js
/** @jest-environment node */
const { isCalVer, nextCalVer } = require('../calver');

test.each(['2026.9.0', '2026.9.1', '2026.10.0', '2026.12.15'])('%s is valid', v => {
  expect(isCalVer(v)).toBe(true);
});

test.each(['2026.09.0', '2026.13.0', '2026.0.1', '26.9.0', '2026.9', '2026.9.01', '1.0.0'])('%s is invalid', v => {
  expect(isCalVer(v)).toBe(false);
});

const sept = new Date(2026, 8, 24);
const oct = new Date(2026, 9, 2);

test('same month bumps the patch', () => {
  expect(nextCalVer('2026.9.0', sept)).toBe('2026.9.1');
  expect(nextCalVer('2026.9.1', sept)).toBe('2026.9.2');
});

test('a new month starts at .0', () => {
  expect(nextCalVer('2026.9.3', oct)).toBe('2026.10.0');
});

test('migrates a non-CalVer starting version to the current month', () => {
  expect(nextCalVer('0.0.1', sept)).toBe('2026.9.0');
});

test('refuses to go backwards in time', () => {
  expect(() => nextCalVer('2026.10.0', sept)).toThrow(/older than/);
});
```

- [ ] **Step 2: Run to confirm failure**

Run: `pnpm jest scripts/__tests__/calver.test.js`
Expected: FAIL, module not found.

- [ ] **Step 3: Implement** — `scripts/calver.js`

```js
// CalVer YYYY.M.PATCH (ARCHITECTURE.md §9.2). Month is not zero-padded so the
// result is also valid semver for npm/package.json.
const fs = require('node:fs');
const path = require('node:path');

const PATTERN = /^(\d{4})\.([1-9]|1[0-2])\.(0|[1-9]\d*)$/;

function isCalVer(v) {
  return PATTERN.test(v);
}

function nextCalVer(current, now) {
  const year = now.getFullYear();
  const month = now.getMonth() + 1;
  const match = PATTERN.exec(current);
  if (!match) {
    return `${year}.${month}.0`;
  }
  const [curYear, curMonth, patch] = match.slice(1).map(Number);
  if (curYear === year && curMonth === month) {
    return `${year}.${month}.${patch + 1}`;
  }
  if (curYear > year || (curYear === year && curMonth > month)) {
    throw new Error(`Current version ${current} is newer than today; the clock is older than the last release`);
  }
  return `${year}.${month}.0`;
}

function main([command]) {
  const pkgPath = path.join(__dirname, '..', 'package.json');
  const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf8'));
  if (command === 'check') {
    if (!isCalVer(pkg.version)) {
      console.error(`package.json version "${pkg.version}" is not CalVer YYYY.M.PATCH`);
      process.exit(1);
    }
    console.log(`version ${pkg.version} OK`);
    return;
  }
  if (command === 'next') {
    pkg.version = nextCalVer(pkg.version, new Date());
    fs.writeFileSync(pkgPath, `${JSON.stringify(pkg, null, 2)}\n`);
    console.log(pkg.version);
    return;
  }
  console.error('usage: node scripts/calver.js check|next');
  process.exit(2);
}

if (require.main === module) {
  main(process.argv.slice(2));
}

module.exports = { isCalVer, nextCalVer };
```

The error message says "newer than today" but the test expects `/older than/`. It matches because the message also contains "the clock is older than the last release". Keep both phrases.

- [ ] **Step 4: Run the tests**

Run: `pnpm jest scripts/__tests__/calver.test.js`
Expected: PASS.

- [ ] **Step 5: Set the first version and add scripts**

```bash
node scripts/calver.js next     # 0.0.1 -> e.g. 2026.9.0
```
Add to `package.json` `scripts`:
```json
"version:check": "node scripts/calver.js check",
"version:next": "node scripts/calver.js next"
```
Run: `pnpm version:check`. Expected: `version 2026.9.0 OK` (or the current month).

- [ ] **Step 6: Commit**

```bash
git add scripts package.json
git commit -m "chore(release): calendar versioning YYYY.M.PATCH with check and bump scripts"
```

---

### Task 11: Prod-bundle verification (sentinel check)

**Files:**
- Create: `scripts/check-bundle.js`, `scripts/__tests__/check-bundle.test.js`, `scripts/verify-bundles.js`
- Modify: `package.json` scripts; `src/services/config/__tests__/envOverrideStore.test.ts` (un-skip)

**Interfaces:**
- Consumes: `ENV_OVERRIDE_STORE_ID` (Task 8).
- Produces: `NONPROD_ONLY_MARKERS: string[]`, `checkBundle(source: string, variant: 'prod' | 'nonprod'): { ok: boolean; message: string }`; scripts `bundle:verify`, `ci:verify`.

- [ ] **Step 1: Write failing tests** — `scripts/__tests__/check-bundle.test.js`

```js
/** @jest-environment node */
const { checkBundle, NONPROD_ONLY_MARKERS } = require('../check-bundle');

const withMarkers = `var a=1;${NONPROD_ONLY_MARKERS.map(m => `"${m}"`).join(';')};`;
const clean = 'var a=1;';

test('prod passes without markers and fails with them', () => {
  expect(checkBundle(clean, 'prod').ok).toBe(true);
  const result = checkBundle(withMarkers, 'prod');
  expect(result.ok).toBe(false);
  expect(result.message).toMatch(/contains non-prod code/);
});

test('nonprod must contain every marker, otherwise the prod check is vacuous', () => {
  expect(checkBundle(withMarkers, 'nonprod').ok).toBe(true);
  const result = checkBundle(clean, 'nonprod');
  expect(result.ok).toBe(false);
  expect(result.message).toMatch(/missing/);
});
```

- [ ] **Step 2: Run to confirm failure**

Run: `pnpm jest scripts/__tests__/check-bundle.test.js`
Expected: FAIL, module not found.

- [ ] **Step 3: Implement the check** — `scripts/check-bundle.js`

```js
// Strings that exist only in non-prod-only modules. Keep in sync with
// ENV_OVERRIDE_STORE_ID (a unit test enforces it).
const NONPROD_ONLY_MARKERS = ['ccs-nonprod-env-override'];

function checkBundle(source, variant) {
  const found = NONPROD_ONLY_MARKERS.filter(marker => source.includes(marker));
  if (variant === 'prod') {
    return found.length === 0
      ? { ok: true, message: 'no non-prod markers' }
      : { ok: false, message: `prod bundle contains non-prod code: ${found.join(', ')}` };
  }
  const missing = NONPROD_ONLY_MARKERS.filter(marker => !found.includes(marker));
  return missing.length === 0
    ? { ok: true, message: 'all non-prod markers present' }
    : { ok: false, message: `non-prod bundle is missing markers ${missing.join(', ')}; was a marker renamed?` };
}

module.exports = { checkBundle, NONPROD_ONLY_MARKERS };
```

- [ ] **Step 4: Implement the bundle runner** — `scripts/verify-bundles.js`

```js
// Builds minified release bundles for both variants (non-prod first, so a
// stale cache would leak into prod if --reset-cache were missing) and checks them.
const { execFileSync } = require('node:child_process');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { checkBundle } = require('./check-bundle');

const outDir = fs.mkdtempSync(path.join(os.tmpdir(), 'ccs-bundles-'));
let failed = false;

for (const variant of ['nonprod', 'prod']) {
  for (const platform of ['ios', 'android']) {
    const bundle = path.join(outDir, `${variant}.${platform}.jsbundle`);
    execFileSync(
      'pnpm',
      ['exec', 'react-native', 'bundle',
        '--platform', platform, '--dev', 'false', '--minify', 'true',
        '--entry-file', 'index.js', '--bundle-output', bundle,
        '--assets-dest', path.join(outDir, `assets-${variant}-${platform}`),
        '--reset-cache'],
      { stdio: 'inherit', env: { ...process.env, CCS_VARIANT: variant, CCS_BUILD_NUMBER: process.env.CCS_BUILD_NUMBER || '0' } },
    );
    const result = checkBundle(fs.readFileSync(bundle, 'utf8'), variant);
    console.log(`${result.ok ? 'PASS' : 'FAIL'} ${variant}/${platform}: ${result.message}`);
    failed = failed || !result.ok;
  }
}

process.exit(failed ? 1 : 0);
```

Add to `package.json` `scripts`:
```json
"bundle:verify": "node scripts/verify-bundles.js",
"ci:verify": "pnpm typecheck && pnpm lint && pnpm test && pnpm version:check && pnpm bundle:verify"
```

- [ ] **Step 5: Un-skip the marker sync test**

In `src/services/config/__tests__/envOverrideStore.test.ts` change `test.skip('store id matches…` back to `test(` and delete the `// enabled in Task 11` comment.

- [ ] **Step 6: Run unit tests, then the real bundle verification**

Run: `pnpm jest && pnpm bundle:verify`
Expected: all unit tests pass (none skipped); four `PASS` lines: `nonprod/ios`, `nonprod/android` (markers present) and `prod/ios`, `prod/android` (no markers).

**If a `prod/*` line FAILs**, Metro didn't fold the ternary away. Use this fallback, which swaps non-prod modules for stubs at resolution time when `CCS_VARIANT=prod`:

`src/services/config/envOverrideStore.prod-stub.ts`:
```ts
export function getEnvOverrideStore(): never {
  throw new Error('env override store is not available in prod builds');
}
```
`src/features/env-switcher/screens/EnvSwitcherScreen.prod-stub.tsx`:
```tsx
export const EnvSwitcherScreen = null;
```
`metro.config.js` (merge into the template's config object):
```js
const path = require('node:path');
const STUBBED_IN_PROD = [
  path.resolve(__dirname, 'src/services/config/envOverrideStore.ts'),
  path.resolve(__dirname, 'src/features/env-switcher/screens/EnvSwitcherScreen.tsx'),
];
const config = {
  resolver: {
    resolveRequest: (context, moduleName, platform) => {
      const resolved = context.resolveRequest(context, moduleName, platform);
      if (process.env.CCS_VARIANT === 'prod' && resolved.type === 'sourceFile' && STUBBED_IN_PROD.includes(resolved.filePath)) {
        return { type: 'sourceFile', filePath: resolved.filePath.replace(/\.tsx?$/, m => `.prod-stub${m}`) };
      }
      return resolved;
    },
  },
};
```
Re-run `pnpm bundle:verify` until all four lines pass, and note in the commit body which mechanism is in use.

- [ ] **Step 7: Commit**

```bash
git add scripts package.json src/services/config/__tests__/envOverrideStore.test.ts
git commit -m "chore(build): prove non-prod code is absent from prod bundles"
```

---

### Task 12: iOS build variants

**Files:**
- Create: `ios/Config/Shared.xcconfig`, `ios/Config/NonProd.xcconfig`, `ios/Config/Prod.xcconfig`, `ios/Config/Debug.xcconfig`, `ios/Config/ReleaseNonProd.xcconfig`, `ios/Config/Release.xcconfig`, `ios/CCSDashboard/Images.xcassets/AppIcon-Beta.appiconset/` (copy of `AppIcon.appiconset`)
- Modify: `ios/CCSDashboard.xcodeproj/project.pbxproj` (via Xcode), `ios/CCSDashboard/Info.plist`, `ios/Podfile`, `ios/.xcode.env`, shared schemes under `ios/CCSDashboard.xcodeproj/xcshareddata/xcschemes/`

**Interfaces:**
- Consumes: I1 bundle ID (`com.att.ccsdashboard`), I2 team ID, I3 deployment target iOS 18.0 (Task 0).
- Produces: schemes `CCS-NonProd` (Run = `Debug`, Archive = `Release-NonProd`) and `CCS` (Run and Archive = `Release`); build setting `CCS_VARIANT` exported to the bundle phase; `MARKETING_VERSION` and `CURRENT_PROJECT_VERSION` overridable via `xcargs`.

- [ ] **Step 1: Write the xcconfigs**

`ios/Config/Shared.xcconfig`:
```
CCS_BASE_BUNDLE_ID = com.att.ccsdashboard
DEVELOPMENT_TEAM = <I2>
IPHONEOS_DEPLOYMENT_TARGET = 18.0
// Universal app: iPhone (1) and iPad (2)
TARGETED_DEVICE_FAMILY = 1,2
MARKETING_VERSION = 0.0.0
CURRENT_PROJECT_VERSION = 0
```
`ios/Config/NonProd.xcconfig`:
```
#include "Shared.xcconfig"
CCS_VARIANT = nonprod
PRODUCT_BUNDLE_IDENTIFIER = $(CCS_BASE_BUNDLE_ID).test
APP_DISPLAY_NAME = CCS Beta
ASSETCATALOG_COMPILER_APPICON_NAME = AppIcon-Beta
```
`ios/Config/Prod.xcconfig`:
```
#include "Shared.xcconfig"
CCS_VARIANT = prod
PRODUCT_BUNDLE_IDENTIFIER = $(CCS_BASE_BUNDLE_ID)
APP_DISPLAY_NAME = CCS
ASSETCATALOG_COMPILER_APPICON_NAME = AppIcon
```
`ios/Config/Debug.xcconfig`:
```
#include "../Pods/Target Support Files/Pods-CCSDashboard/Pods-CCSDashboard.debug.xcconfig"
#include "NonProd.xcconfig"
```
`ios/Config/ReleaseNonProd.xcconfig`:
```
#include "../Pods/Target Support Files/Pods-CCSDashboard/Pods-CCSDashboard.release-nonprod.xcconfig"
#include "NonProd.xcconfig"
```
`ios/Config/Release.xcconfig`:
```
#include "../Pods/Target Support Files/Pods-CCSDashboard/Pods-CCSDashboard.release.xcconfig"
#include "Prod.xcconfig"
```

- [ ] **Step 2: Configure the Xcode project** (Xcode UI; commit the resulting `project.pbxproj` diff)

1. Open `ios/CCSDashboard.xcworkspace`. Project `CCSDashboard` → Info → Configurations → duplicate `Release` and name it `Release-NonProd`.
2. Add the `ios/Config` folder to the project (no target membership).
3. For the **CCSDashboard target**, set "Based on Configuration File": Debug → `Debug.xcconfig`, Release-NonProd → `ReleaseNonProd.xcconfig`, Release → `Release.xcconfig`.
4. Target → Build Settings: select and **delete** the target-level values of `PRODUCT_BUNDLE_IDENTIFIER`, `DEVELOPMENT_TEAM`, `MARKETING_VERSION`, `CURRENT_PROJECT_VERSION` and `IPHONEOS_DEPLOYMENT_TARGET`, so the xcconfig values apply. They should show in plain (not bold) text afterwards.
5. Product → Scheme → Manage Schemes: rename `CCSDashboard` to `CCS` (Run → Build Configuration `Release`; Archive → `Release`). Duplicate it as `CCS-NonProd` (Run → `Debug`; Archive → `Release-NonProd`). Tick **Shared** on both.
6. In `Images.xcassets`, duplicate `AppIcon` as `AppIcon-Beta` (a placeholder until the icon design; ARCHITECTURE.md open item 2).

- [ ] **Step 3: Info.plist, Podfile, bundle-phase env**

`ios/CCSDashboard/Info.plist`: set `CFBundleDisplayName` to `$(APP_DISPLAY_NAME)`. Set orientations so iPad multitasking (Split View, Slide Over, Stage Manager) works; it requires all four on iPad, and `UIRequiresFullScreen` must be absent or `false`:
```xml
<key>UISupportedInterfaceOrientations</key>
<array>
  <string>UIInterfaceOrientationPortrait</string>
  <string>UIInterfaceOrientationLandscapeLeft</string>
  <string>UIInterfaceOrientationLandscapeRight</string>
</array>
<key>UISupportedInterfaceOrientations~ipad</key>
<array>
  <string>UIInterfaceOrientationPortrait</string>
  <string>UIInterfaceOrientationPortraitUpsideDown</string>
  <string>UIInterfaceOrientationLandscapeLeft</string>
  <string>UIInterfaceOrientationLandscapeRight</string>
</array>
``` Confirm `CFBundleShortVersionString` = `$(MARKETING_VERSION)` and `CFBundleVersion` = `$(CURRENT_PROJECT_VERSION)`.

`ios/Podfile`: change `platform :ios, min_ios_version_supported` to `platform :ios, '18.0'` (I3), and after `prepare_react_native_project!` add:
```ruby
project 'CCSDashboard', 'Debug' => :debug, 'Release-NonProd' => :release, 'Release' => :release
```

`ios/.xcode.env`: append:
```bash
# Build settings (CCS_VARIANT, CURRENT_PROJECT_VERSION) are exported to this phase.
export CCS_BUILD_NUMBER="${CURRENT_PROJECT_VERSION:-0}"
# Never reuse a Metro cache across variants (plan Review Focus #2).
export EXTRA_PACKAGER_ARGS="--reset-cache"
```

Then:
```bash
cd ios && bundle exec pod install && cd ..
```
Expected: CocoaPods warns that it did not set the base configuration because a custom one is set. That's expected, because our xcconfigs `#include` the Pods files.

- [ ] **Step 4: Verify the build settings resolve per scheme**

```bash
xcodebuild -workspace ios/CCSDashboard.xcworkspace -scheme CCS-NonProd -configuration Debug -showBuildSettings \
  | grep -E ' (CCS_VARIANT|PRODUCT_BUNDLE_IDENTIFIER|APP_DISPLAY_NAME|ASSETCATALOG_COMPILER_APPICON_NAME|TARGETED_DEVICE_FAMILY) ='
xcodebuild -workspace ios/CCSDashboard.xcworkspace -scheme CCS -configuration Release -showBuildSettings \
  | grep -E ' (CCS_VARIANT|PRODUCT_BUNDLE_IDENTIFIER|APP_DISPLAY_NAME|ASSETCATALOG_COMPILER_APPICON_NAME) ='
```
Expected: `nonprod`, `com.att.ccsdashboard.test`, `CCS Beta`, `AppIcon-Beta`, `1,2`; then `prod`, `com.att.ccsdashboard`, `CCS`, `AppIcon` (the second grep has no device-family filter, which is fine).

- [ ] **Step 5: Run both on the simulator**

```bash
pnpm ios:nonprod
pnpm react-native run-ios --scheme CCS --mode Release
```
Expected: two apps side by side, named "CCS Beta" (with badge; long-press works) and "CCS" (no badge; long-press does nothing).

Then check the window-size cases on an **iPad** simulator (use the smallest and largest available, e.g. iPad mini and iPad Pro 13-inch), plus the smallest supported iPhone:
```bash
pnpm react-native run-ios --scheme CCS-NonProd --simulator "iPad mini (A17 Pro)"
```
- Rotate (⌘← / ⌘→): content re-centers, nothing clips.
- Split View at ⅓ and ½ width, and Slide Over: content fills the narrow window like a phone.
- Full-width landscape: text column is capped (~640 pt), centered, not stretched edge to edge.
- Settings → Accessibility → Larger Text at maximum: content scrolls.

- [ ] **Step 6: Commit** (flag at the top of the PR description: **native project change**, AGENTS.md §17.5)

```bash
git add ios
git commit -m "chore(ios): prod and non-prod build variants via xcconfig and shared schemes"
```

---

### Task 13: Android build variants — **DEFERRED (skip in M0)**

> iOS is prioritized (ARCHITECTURE.md §2). Skip this whole task; leave `android/` as generated. Keep it for when Android is prioritized. The ledger line is `Task 13: skipped (deferred, iOS first)`.


**Files:**
- Modify: `android/app/build.gradle`, `android/app/src/main/res/values/strings.xml`, `android/build.gradle` (minSdk 29 from I3)

**Interfaces:**
- Consumes: I1, I3 (Task 0); `CCS_VARIANT`, `CCS_BUILD_NUMBER` env.
- Produces: flavors `nonprod` (`applicationIdSuffix ".test"`, name "CCS Beta") and `prod` (name "CCS"); release bundling fails if `CCS_VARIANT` doesn't match the flavor.

- [ ] **Step 1: Edit `android/app/build.gradle`**

Inside `react { … }` add:
```groovy
    debuggableVariants = ["nonprodDebug", "prodDebug", "nonprodDebugOptimized", "prodDebugOptimized"]
    // Never reuse a Metro cache across variants (plan Review Focus #2).
    extraPackagerArgs = ["--reset-cache"]
```

Above `android { … }` add:
```groovy
def packageJson = new groovy.json.JsonSlurper().parse(file("../../package.json"))
def ccsBuildNumber = (System.getenv("CCS_BUILD_NUMBER") ?: "1")
if (!(ccsBuildNumber ==~ /\d+/)) {
    throw new GradleException("CCS_BUILD_NUMBER must be digits only; got '${ccsBuildNumber}'")
}
```

In `android { defaultConfig { … } }` set:
```groovy
        applicationId "com.att.ccsdashboard"
        versionCode ccsBuildNumber.toInteger()
        versionName packageJson.version
```

Inside `android { … }` add:
```groovy
    flavorDimensions += "variant"
    productFlavors {
        nonprod {
            dimension "variant"
            applicationIdSuffix ".test"
            resValue "string", "app_name", "CCS Beta"
        }
        prod {
            dimension "variant"
            resValue "string", "app_name", "CCS"
        }
    }
```

At the end of the file:
```groovy
// The JS bundle's variant comes from CCS_VARIANT (babel/build-constants-plugin.js);
// refuse to package a release whose bundle variant disagrees with the flavor.
tasks.configureEach { task ->
    if (task.name ==~ /createBundle(Nonprod|Prod)Release.*JsAndAssets/) {
        task.doFirst {
            def expected = task.name.contains("Prod") ? "prod" : "nonprod"
            if (System.getenv("CCS_VARIANT") != expected) {
                throw new GradleException("CCS_VARIANT must be '${expected}' for ${task.name}; got '${System.getenv("CCS_VARIANT")}'")
            }
        }
    }
}
```
(`"Nonprod"` does not contain `"Prod"` with a capital P, so `contains("Prod")` tells the flavors apart.)

`android/app/src/main/res/values/strings.xml`: remove the `app_name` entry (the flavors now provide it).

`android/build.gradle`: set `minSdkVersion = 29` (I3; Android 10).

- [ ] **Step 2: Verify**

```bash
cd android
./gradlew :app:assembleNonprodDebug
CCS_VARIANT=nonprod ./gradlew :app:assembleNonprodRelease
./gradlew :app:assembleProdRelease; echo "exit=$?"
CCS_VARIANT=prod ./gradlew :app:assembleProdRelease
cd ..
```
Expected: the first two succeed; the third fails with `CCS_VARIANT must be 'prod' for createBundleProdReleaseJsAndAssets` (non-zero exit); the fourth succeeds. Release builds are signed with the debug keystore for now. Real Android signing (MAD Sign) is outside M0.

- [ ] **Step 3: Run on an emulator**

Run: `pnpm android:nonprod`
Expected: "CCS Beta" launches on the ComingSoon screen with the badge.

- [ ] **Step 4: Commit** (flag: **native project change**)

```bash
git add android
git commit -m "chore(android): prod and non-prod product flavors with variant guard"
```

---

### Task 14: Firebase Crashlytics

**Files:**
- Create: `src/services/logging/adapters/crashlyticsLogger.ts`, `src/services/logging/__tests__/crashlyticsLogger.test.ts`, `firebase.json`, `ios/Firebase/.gitkeep`, `android/app/src/nonprod/.gitkeep`, `android/app/src/prod/.gitkeep`
- Modify: `src/app/compositionRoot.ts`, `jest/setup.js`, `.gitignore`, `ios/Podfile`, `ios/CCSDashboard/AppDelegate.swift`, Xcode build phases, `android/build.gradle`, `android/app/build.gradle`

**Interfaces:**
- Consumes: `Logger`, `sanitizeContext`, `toError` (Task 5); variants (Tasks 12–13); I6.
- Produces: `createCrashlyticsLogger(): Logger`. The composition root uses it when `!__DEV__`.

- [ ] **Step 1: Install**

```bash
pnpm add @react-native-firebase/app @react-native-firebase/crashlytics
```

- [ ] **Step 2: Write failing adapter tests** — `src/services/logging/__tests__/crashlyticsLogger.test.ts`

```ts
import { getCrashlytics, log, recordError, setAttributes } from '@react-native-firebase/crashlytics';
import { createCrashlyticsLogger } from '../adapters/crashlyticsLogger';

beforeEach(() => jest.clearAllMocks());

test('error records a non-fatal with only allow-listed attributes', () => {
  const logger = createCrashlyticsLogger();
  const err = new Error('boom');
  logger.error(err, { route: 'ComingSoon', token: 'secret' } as never);
  expect(setAttributes).toHaveBeenCalledWith(getCrashlytics(), { route: 'ComingSoon' });
  expect(recordError).toHaveBeenCalledWith(getCrashlytics(), err);
});

test('error without context skips attributes', () => {
  createCrashlyticsLogger().error('string thrown');
  expect(setAttributes).not.toHaveBeenCalled();
  expect(recordError).toHaveBeenCalledWith(getCrashlytics(), expect.objectContaining({ message: 'Non-Error value thrown (string)' }));
});

test('info writes a breadcrumb line with sanitized context', () => {
  createCrashlyticsLogger().info('app ready', { feature: 'coming-soon', email: 'x@y' } as never);
  expect(log).toHaveBeenCalledWith(getCrashlytics(), 'app ready feature=coming-soon');
});
```

Append to `jest/setup.js`:
```js
jest.mock('@react-native-firebase/crashlytics', () => {
  const instance = {};
  return {
    getCrashlytics: jest.fn(() => instance),
    log: jest.fn(),
    recordError: jest.fn(),
    setAttributes: jest.fn(() => Promise.resolve()),
  };
});
```

- [ ] **Step 3: Run to confirm failure**

Run: `pnpm jest src/services/logging`
Expected: FAIL, adapter module not found.

- [ ] **Step 4: Implement** — `src/services/logging/adapters/crashlyticsLogger.ts`

```ts
import { getCrashlytics, log, recordError, setAttributes } from '@react-native-firebase/crashlytics';
import { sanitizeContext, toError } from '../sanitize';
import type { Logger } from '../types';

export function createCrashlyticsLogger(): Logger {
  const crashlytics = getCrashlytics();
  return {
    info(message, context) {
      const pairs = Object.entries(sanitizeContext(context)).map(([k, v]) => `${k}=${v}`);
      log(crashlytics, [message, ...pairs].join(' '));
    },
    error(error, context) {
      const attributes = sanitizeContext(context);
      if (Object.keys(attributes).length > 0) {
        void setAttributes(crashlytics, attributes);
      }
      recordError(crashlytics, toError(error));
    },
  };
}
```

`src/app/compositionRoot.ts`: import `createCrashlyticsLogger` and change the logger line to:
```ts
    logger: __DEV__ ? createConsoleLogger() : createCrashlyticsLogger(),
```

Run: `pnpm jest && pnpm typecheck && pnpm lint`. Expected: all pass.

- [ ] **Step 5: Native setup: iOS** (RNFirebase default on RN ≥ 0.75 is SPM, which requires **dynamic** framework linkage)

`ios/Podfile`, inside `target 'CCSDashboard' do`, before `use_react_native!`:
```ruby
  use_frameworks! :linkage => :dynamic
```
Remove the template's `linkage = ENV['USE_FRAMEWORKS']` block so linkage isn't set twice.

`ios/CCSDashboard/AppDelegate.swift`: add `import FirebaseCore` after the other imports, and make `FirebaseApp.configure()` the first line of `application(_:didFinishLaunchingWithOptions:)`.

Xcode → target → Build Phases → New Run Script Phase named "Copy GoogleService-Info.plist", placed **before** "Copy Bundle Resources":
```bash
SRC="${SRCROOT}/Firebase/${CCS_VARIANT}/GoogleService-Info.plist"
if [ ! -f "$SRC" ]; then
  echo "error: missing $SRC (CI injects it; locally copy it from the Firebase console, see docs/setup.md)"
  exit 1
fi
cp "$SRC" "${BUILT_PRODUCTS_DIR}/${PRODUCT_NAME}.app/GoogleService-Info.plist"
```
Add the Crashlytics dSYM upload phase exactly as the RNFirebase Crashlytics iOS docs for the installed version describe.

Put the I6 files at `ios/Firebase/nonprod/GoogleService-Info.plist` and `ios/Firebase/prod/GoogleService-Info.plist`.

- [ ] **Step 6: Native setup: Android — DEFERRED (skip in M0)**

> Skip; do this with Task 13 when Android is prioritized. RNFirebase still autolinks on Android; if `pnpm bundle:verify` or tests are unaffected (they are JS-only), nothing else is needed now.


Put the I6 files at `android/app/src/nonprod/google-services.json` and `android/app/src/prod/google-services.json` (the Google Services plugin picks them up per flavor). Add the `com.google.gms.google-services` and `com.google.firebase.crashlytics` Gradle plugins with the versions the RNFirebase docs list for the installed version (classpath in `android/build.gradle`, `apply plugin:` in `android/app/build.gradle`).

- [ ] **Step 7: Keep secrets out of git; configure collection**

`.gitignore` append:
```
# Firebase config is injected by CI per variant (ARCHITECTURE.md §5.2)
ios/Firebase/*/GoogleService-Info.plist
android/app/src/*/google-services.json
```
`firebase.json`:
```json
{
  "react-native": {
    "crashlytics_debug_enabled": false,
    "crashlytics_auto_collection_enabled": true
  }
}
```

- [ ] **Step 8: Verify end to end**

```bash
cd ios && bundle exec pod install && cd ..
git status --short | grep -E 'GoogleService|google-services' && echo "LEAK" || echo "no Firebase files staged"
pnpm react-native run-ios --scheme CCS-NonProd --mode Release-NonProd
```
In the app: long-press version → "Send test non-fatal to Crashlytics" → background and reopen the app (Crashlytics sends reports on the next launch). Expected: within ~5 minutes the non-prod Firebase console → Crashlytics → Non-fatals shows `CCS test non-fatal` with a `feature` key of `env-switcher`, and nothing else in custom keys. Expected git output: `no Firebase files staged`.

- [ ] **Step 9: Commit** (flag: **native project change + new dependency + Firebase config**)

```bash
git add src jest/setup.js firebase.json .gitignore ios android package.json pnpm-lock.yaml
git commit -m "feat(logging): Crashlytics adapter with per-variant Firebase config"
```

---

### Task 15: Splash screen

**Files:**
- Create: `assets/brand/ccs-mark.svg`, generated `assets/bootsplash/*`, iOS `BootSplash.storyboard` + asset set, Android `bootsplash_*` resources
- Modify: `ios/CCSDashboard/AppDelegate.swift`, `ios/CCSDashboard/Info.plist`, `android/app/src/main/java/**/MainActivity.kt`, `android/app/src/main/res/values/styles.xml`, `android/app/src/main/AndroidManifest.xml`, `src/app/App.tsx`, `src/app/__tests__/App.test.tsx`, `jest/setup.js`

**Interfaces:**
- Consumes: `RootNavigator({ onReady })` (Task 7).
- Produces: the native splash stays up until the navigator is ready, then fades out (`BootSplash.hide({ fade: true })`).

- [ ] **Step 1: Placeholder mark** (replaced when the icon design lands; ARCHITECTURE.md open item 2) — `assets/brand/ccs-mark.svg`

```svg
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 256">
  <g fill="#FFFFFF">
    <rect x="40" y="136" width="40" height="80" rx="12"/>
    <rect x="108" y="88" width="40" height="128" rx="12"/>
    <rect x="176" y="40" width="40" height="176" rx="12"/>
  </g>
</svg>
```

- [ ] **Step 2: Install and generate** (accent background works in both light and dark mode without the paid dark-mode option)

```bash
pnpm add react-native-bootsplash
pnpm react-native-bootsplash generate assets/brand/ccs-mark.svg \
  --platforms=ios --background=2F5BEA --logo-width=120 --assets-output=assets/bootsplash
```
Expected: iOS `BootSplash.storyboard` + `BootSplashLogo` image set, Android `bootsplash_logo` drawables and `bootsplash_background` color. Confirm `ios/CCSDashboard/Info.plist` has `UILaunchStoryboardName` = `BootSplash`; set it if the CLI didn't.

- [ ] **Step 3: Native wiring**

`ios/CCSDashboard/AppDelegate.swift`: add `import RNBootSplash`, and in `class ReactNativeDelegate` add:
```swift
  override func customize(_ rootView: RCTRootView) {
    super.customize(rootView)
    RNBootSplash.initWithStoryboard("BootSplash", rootView: rootView)
  }
```

**Android (DEFERRED; skip in M0, do with Task 13):** `android/app/src/main/res/values/styles.xml`, add:
```xml
<style name="BootTheme" parent="Theme.BootSplash">
  <item name="postBootSplashTheme">@style/AppTheme</item>
  <item name="bootSplashBackground">@color/bootsplash_background</item>
  <item name="bootSplashLogo">@drawable/bootsplash_logo</item>
</style>
```
`AndroidManifest.xml`: set the main activity's `android:theme="@style/BootTheme"`.

`MainActivity.kt`: add `import android.os.Bundle` and `import com.zoontek.rnbootsplash.RNBootSplash`, then override `onCreate`. For react-native-screens **< 4.16**:
```kotlin
  override fun onCreate(savedInstanceState: Bundle?) {
    RNBootSplash.init(this, R.style.BootTheme)
    super.onCreate(null)
  }
```
Check the installed react-native-screens version (`pnpm why react-native-screens`). If it's **≥ 4.16**, use the `MainActivity` snippet from the react-native-bootsplash README section for that version instead.

- [ ] **Step 4: Write the failing JS test**

Append to `jest/setup.js`:
```js
jest.mock('react-native-bootsplash', () => ({
  hide: jest.fn(() => Promise.resolve()),
  isVisible: jest.fn(() => false),
}));
```

Add to `src/app/__tests__/App.test.tsx`:
```tsx
import BootSplash from 'react-native-bootsplash';

test('hides the native splash with a fade once navigation is ready', async () => {
  render(<App services={makeTestServices()} />);
  await screen.findByText(comingSoonStrings.headline);
  expect(BootSplash.hide).toHaveBeenCalledWith({ fade: true });
});
```

Run: `pnpm jest src/app`
Expected: FAIL (`hide` not called).

- [ ] **Step 5: Hide on navigation ready** — `src/app/App.tsx`

```tsx
import BootSplash from 'react-native-bootsplash';
// ...
  const onNavigationReady = useCallback(() => {
    void BootSplash.hide({ fade: true });
  }, []);
// ...
            <RootNavigator onReady={onNavigationReady} />
```

Run: `pnpm jest && pnpm typecheck && pnpm lint`. Expected: all pass.

- [ ] **Step 6: Manual check on both platforms**

```bash
cd ios && bundle exec pod install && cd ..
pnpm ios:nonprod
```
Expected: the accent-blue splash with the white mark, then a smooth fade into ComingSoon with no white flash or visual jump. Repeat in dark mode, and on an iPad simulator in both orientations: the logo stays centered.

- [ ] **Step 7: Commit** (flag: **native project change + new dependency**)

```bash
git add assets src jest/setup.js ios android package.json pnpm-lock.yaml
git commit -m "feat(app): branded splash with native-to-JS hand-off"
```

---

### Task 16: Fastlane lanes, first TestFlight build, setup docs

**Files:**
- Create: `ios/fastlane/Fastfile`, `ios/fastlane/Appfile`, `docs/setup.md`
- Modify: `Gemfile`

**Interfaces:**
- Consumes: schemes (Task 12), CalVer (Task 10), `ci:verify` (Task 11), I7.
- Produces: `bundle exec fastlane ios build variant:nonprod|prod` and `bundle exec fastlane ios upload`. These are CI-agnostic entry points that the RevUp template (ARCHITECTURE.md open item 3) will call.

- [ ] **Step 1: Add Fastlane**

`Gemfile` append: `gem 'fastlane'`. Then run `bundle install`.

`ios/fastlane/Appfile`:
```ruby
team_id(ENV.fetch('CCS_APPLE_TEAM_ID'))
```

`ios/fastlane/Fastfile`:
```ruby
require 'json'

default_platform(:ios)

VARIANTS = {
  'nonprod' => { scheme: 'CCS-NonProd', configuration: 'Release-NonProd' },
  'prod'    => { scheme: 'CCS',         configuration: 'Release' },
}.freeze

platform :ios do
  desc 'Build a signed IPA: fastlane ios build variant:nonprod|prod (needs CCS_BUILD_NUMBER)'
  lane :build do |options|
    variant = options[:variant].to_s
    settings = VARIANTS[variant] || UI.user_error!("variant must be one of #{VARIANTS.keys.join(', ')}")
    version = JSON.parse(File.read(File.expand_path('../../package.json', __dir__)))['version']
    build_number = ENV.fetch('CCS_BUILD_NUMBER') { UI.user_error!('CCS_BUILD_NUMBER is required (CI run number)') }
    UI.user_error!("CCS_BUILD_NUMBER must be digits only") unless build_number.match?(/\A\d+\z/)

    build_app(
      workspace: 'CCSDashboard.xcworkspace',
      scheme: settings[:scheme],
      configuration: settings[:configuration],
      clean: true,
      export_method: 'app-store',
      output_directory: 'build',
      output_name: "CCS-#{variant}-#{version}-#{build_number}",
      xcargs: "MARKETING_VERSION=#{version} CURRENT_PROJECT_VERSION=#{build_number}",
    )
  end

  desc 'Upload the last built IPA to TestFlight (App Store Connect API key via env)'
  lane :upload do
    api_key = app_store_connect_api_key(
      key_id: ENV.fetch('ASC_KEY_ID'),
      issuer_id: ENV.fetch('ASC_ISSUER_ID'),
      key_content: ENV.fetch('ASC_KEY_CONTENT_BASE64'),
      is_key_content_base64: true,
    )
    upload_to_testflight(api_key: api_key, skip_waiting_for_build_processing: true)
  end
end
```

- [ ] **Step 2: Verify lane argument validation**

```bash
cd ios
bundle exec fastlane ios build variant:production; echo "exit=$?"
env -u CCS_BUILD_NUMBER bundle exec fastlane ios build variant:nonprod; echo "exit=$?"
cd ..
```
Expected: both fail fast with the `variant must be one of` / `CCS_BUILD_NUMBER is required` messages.

- [ ] **Step 3: Write `docs/setup.md`**

````markdown
# Developer setup — CCS Dashboard Mobile

## Toolchain
- Node >= 22.11 (`.nvmrc` optional), pnpm via `corepack enable`
- Xcode (current stable) + Ruby/Bundler (`bundle install` at repo root)
- JDK 17, Android SDK (API level from `android/build.gradle`)

## Corporate network
- npm registry: `.npmrc` points at the Artifactory mirror (<I4>). Export `ARTIFACTORY_NPM_TOKEN` in your shell profile. **Tokens expire:** a `401`/`407` from `pnpm install` usually means you need a fresh token from Artifactory → your profile → "Generate identity token".
- Proxy: export `HTTP_PROXY`/`HTTPS_PROXY` if your network requires it.
- TLS inspection: export `NODE_EXTRA_CA_CERTS=/path/to/corporate-root-ca.pem` so Node trusts the corporate root CA.

## Variants
| | Run locally | Bundle ID |
|---|---|---|
| non-prod | `pnpm ios:nonprod` | `com.att.ccsdashboard.test` |
| prod | `pnpm react-native run-ios --scheme CCS --mode Release` | `com.att.ccsdashboard` |

- The JS variant comes from `CCS_VARIANT` at bundle time. Metro in dev defaults to `nonprod`. To debug prod JS: `CCS_VARIANT=prod pnpm start --reset-cache`.
- Non-prod builds: long-press the version line on the home screen for the environment switcher.

## Firebase config (never committed)
Copy from the Firebase console (ask the App Lead for access):
- `ios/Firebase/nonprod/GoogleService-Info.plist`, `ios/Firebase/prod/GoogleService-Info.plist`
- `android/app/src/nonprod/google-services.json`, `android/app/src/prod/google-services.json`

## Before pushing
`pnpm ci:verify` runs typecheck, lint, tests, the CalVer check and the prod-bundle check.

## Releasing (until the RevUp pipeline exists)
```bash
pnpm version:next                       # only for a new release; commit the bump
pnpm ci:verify
cd ios && CCS_BUILD_NUMBER=<next build number> bundle exec fastlane ios build variant:nonprod
ASC_KEY_ID=… ASC_ISSUER_ID=… ASC_KEY_CONTENT_BASE64=… bundle exec fastlane ios upload
git tag v<version>+<build number> && git push --tags
```
````

- [ ] **Step 4: Ship the first non-prod build to TestFlight** (human performs this; needs I7 and signing on the machine)

```bash
pnpm ci:verify
cd ios
CCS_BUILD_NUMBER=1 bundle exec fastlane ios build variant:nonprod
ASC_KEY_ID=… ASC_ISSUER_ID=… ASC_KEY_CONTENT_BASE64=… bundle exec fastlane ios upload
cd ..
git tag "v$(node -p "require('./package.json').version")+1"
```
Expected: the build appears in App Store Connect → TestFlight for `com.att.ccsdashboard.test`. An internal tester installs "CCS Beta" and sees the splash, then ComingSoon with `Version 2026.9.0 (1)`.

- [ ] **Step 5: Commit**

```bash
git add Gemfile Gemfile.lock ios/fastlane docs/setup.md
git commit -m "chore(release): Fastlane build and TestFlight lanes, developer setup guide"
```

---

## M0 exit checklist (ARCHITECTURE.md §2)

- [ ] Non-prod build installed from TestFlight by an internal tester (Task 16 Step 4)
- [ ] Crashlytics shows the test non-fatal with only allow-listed keys (Task 14 Step 8)
- [ ] `pnpm bundle:verify` passes: prod bundles contain no non-prod code (Task 11)
- [ ] `pnpm ci:verify` green on a clean clone
- [ ] ARCHITECTURE.md and `docs/superpowers/` never appeared in any commit: `git log --all --name-only | grep -E 'ARCHITECTURE.md|docs/superpowers'` prints nothing

## Deferred (not M0)
- RevUp pipeline wiring (the template is still to come; it calls `pnpm ci:verify` and the Fastlane lanes), Veracode
- **Android**: Task 13 (flavors), Task 14 Step 6 (Firebase Android), Task 15 Android splash wiring, an `android:nonprod` script, signing with MAD Sign and Firebase App Distribution. minSdk 29 is already decided.
- Real app icon and brand palette (swap `AppIcon`/`AppIcon-Beta`, `assets/brand/ccs-mark.svg`, palette values)
- `eslint-plugin-boundaries` to replace the per-feature lint blocks once there are more than a few features
