# CCS Dashboard Mobile Application — Architecture & Delivery Plan

**Status:** Draft for review
**Prepared for:** Project stakeholders, engineering leads, executive sponsors
**Prepared by:** Karthik Meda, App Lead
**Phase:** Research & Planning

---

## 1. Executive Summary

The CCS Dashboard is AT&T's web-based unified contact center platform, providing real-time monitoring, historical reporting, agent profile management, analytics, and performance visibility across Voice and Chat channels enterprise-wide. This document proposes a phased plan to deliver a companion mobile application, beginning with a deliberately narrow Minimum Viable Product (MVP): a **Business Unit-level executive summary view** of the same Real-time Monitoring KPIs that senior leadership already relies on today.

This plan is the output of an initial research phase: technical analysis of the existing web application (its architecture, data sources, and authentication model), since no formal documentation of the system exists today. The findings below directly inform the proposed design and development approach, and — importantly — inform a realistic view of scope and sequencing for leadership decision-making.

**MVP Definition:** A simple mobile application (iOS and Android) displaying a **Business Unit-level rollup** of the Real-time Monitoring report, limited to the key KPIs executive leadership actively monitors today: **Queue, Answered, Abandoned, Logged In, On Call, Not Ready, Ready, Access, and Access (30-min)**. No per-agent, per-skill, or drill-down detail — a single, glanceable view per Business Unit. The intent is to ship something simple first, then expand scope iteratively based on feedback from the user community, rather than attempting full feature depth up front.

**Key recommendation:** Treat this as a staged program (Research → Design → Development → Iterate) rather than a single fixed-scope delivery. The research phase surfaced meaningful architectural complexity that should shape scope and timeline decisions before development commitments are finalized. Details follow.

---

## 2. Background

### 2.1 What is the CCS Dashboard?

A React-based single-page web application providing:
- Real-time monitoring of agent and queue status across Voice and Chat
- Historical and analytical reporting (day/week/month, call detail records)
- Agent profile administration (bulk provisioning, approvals, Genesys sync)
- 290 distinct reports across these categories, accumulated over multiple years of development

### 2.2 Why Mobile?

The desktop dashboard is optimized for sustained, deep analysis at a workstation — dense tables, multi-panel layouts, and detailed drill-downs. It is not designed for the quick, on-the-go checks that supervisors and managers increasingly need. A mobile companion app addresses a genuinely different use case: **glanceable, real-time visibility, anywhere** — not a port of the desktop experience.

### 2.3 Why Start With Real-time Monitoring?

Of the 290 reports in the system, Real-time Monitoring is the highest-value candidate for a mobile-first experience:
- It answers the question mobile is best suited for ("what's happening right now?"), versus historical/analytical reports better suited to desktop analysis
- Its underlying data is narrower in scope than the full reporting suite, making it a more tractable first increment
- It's the area most likely to benefit from mobile-native capabilities (push notifications on threshold breaches) that the desktop simply cannot offer

---

## 3. Objectives & Success Criteria

| Objective | Success Criteria |
|---|---|
| Deliver real-time visibility on mobile | Executive leadership and supervisors can view live, BU-level KPI status without a desktop |
| Ship something simple, then iterate | MVP is intentionally minimal; scope expansion is driven by user community feedback, not upfront speculation |
| Respect enterprise security & compliance | Native AT&T SSO; no sensitive data cached insecurely; PII handling reviewed |
| Establish a scalable technical foundation | Architecture supports adding further KPIs, drill-down depth, and report categories in later phases without a rewrite |
| Set realistic expectations | Leadership has an evidence-based view of scope, risk, and sequencing — not a best-case estimate |

---

## 4. Scope

### 4.1 In Scope (MVP)
- A single view: **Business Unit-level rollup** of the Real-time Monitoring report — one row per Business Unit (including the enterprise-wide total), no deeper drill-down (no Organization/LOB/Category/Queue-level detail, no per-agent or per-skill data)
- Limited to **nine key KPIs**, matching what executive leadership already actively monitors on the desktop today:

  | KPI | Description |
  |---|---|
  | Queue | Calls currently waiting in queue |
  | Answered | Calls answered |
  | Abandoned | Calls abandoned before being answered |
  | Logged In | Agents currently logged in |
  | On Call | Agents currently on a call |
  | Not Ready | Agents logged in but not available to take calls |
  | Ready | Agents available and waiting for a call |
  | Access | Service accessibility rate (day) |
  | Access (30-min) | Service accessibility rate, trailing 30 minutes |

- Native AT&T SSO authentication
- iOS and Android

### 4.2 Explicitly Out of Scope (MVP)
- Any drill-down below Business Unit level (Organization, LOB, Category, Queue, Skill, or per-agent detail)
- Any KPI beyond the nine listed above (the full Real-time Monitoring report exposes 30+ metrics per row on desktop; MVP intentionally shows only what executive leadership actively uses)
- The other real-time report variants (SBS, ICM, Vendor Hierarchy, Skill views, the historical trend chart) and all historical/analytical reporting
- Agent profile administration (bulk provisioning, approval workflows)
- Push notifications / alerting (candidate for a fast-follow phase — see §9)
- Data entry or write operations of any kind (MVP is read-only/display)

**Scope philosophy:** this is a deliberately minimal first release. Expansion — additional KPIs, drill-down depth, additional report categories — should be prioritized based on actual feedback from the user community once the MVP is in their hands, not built speculatively ahead of demonstrated need.

---

## 5. Phase 1 — Research (Completed / In Progress)

### 5.1 Objectives
Establish a factual, evidence-based understanding of the existing system before committing to a technical design — since no documentation of the web application or its backend exists today.

### 5.2 Methodology
In the absence of documentation, research was conducted via direct technical analysis of the live web application: inspecting its network and real-time data traffic while navigating the application as an authenticated user, and reviewing AT&T's internal identity platform documentation for mobile authentication requirements.

### 5.3 Key Findings

**System complexity**
- The CCS Dashboard has been in development for 5+ years and comprises 290 distinct reports
- No formal API or architecture documentation exists; institutional knowledge is not currently captured in artifacts
- The backend uses **at least five different data-delivery patterns** even within the single Real-time Monitoring category: a high-frequency streamed data feed, a separately-polled feed with a different schema, a generic query-based reporting engine, a historical-snapshot chart data source, and a distinct per-queue chart data source
- Backend field-naming is inconsistent across structurally similar reports (e.g., the same concept named `NOTREADY` in one report and `NOT_READY` in another), indicative of multiple teams/eras of development without a unifying data contract

**Data volume and sensitivity**
- The real-time data feeds are substantial: the core Real-time Monitoring feed refreshes on the order of every 15 seconds with a multi-megabyte payload representing the full organizational hierarchy, down to individual agents and skills
- These feeds include live employee-identifiable information (names, employee IDs, current call duration) as part of the standard payload
- **Implication for mobile:** the existing feeds cannot be consumed as-is by a mobile client without redesign — the full payload is impractical for cellular networks and battery life, and the embedded personal data warrants a compliance review before any mobile consumption, regardless of technical feasibility
- **This directly shaped the MVP scope decision (§4):** by limiting the mobile experience to a Business Unit-level rollup with nine specific KPIs — rather than the full drill-down hierarchy the desktop offers — the mobile data request becomes substantially lighter and, critically, **never needs to touch the personal/agent-level data** in the first place. This is expected to meaningfully simplify the data-contract and compliance discussion in §6.3, though it should still be formally confirmed with the backend/platform team.

**Authentication**
- AT&T's corporate identity platform is **Halo.E**. Research into Halo.E's own developer documentation and integration portal (Client-Halo Integration Portal, "CHIP") clarified the requirements for mobile authentication:
  - Mobile applications must be registered as a distinct **Public client** using the **Authorization Code Flow with PKCE** — a different registration than the one used by the existing web application, which is a **Confidential client** (server-side secret, not suitable for a mobile binary)
  - Each application and environment (dev/test/stage/production) requires its own registered client through a formal request-and-approval process
  - Native mobile apps can use a custom URL redirect scheme (not requiring more complex web-based redirect infrastructure), simplifying the integration path
  - This registration must be requested through the project owner / identity team and is a **program dependency**, not an engineering task — see §9

**UX considerations**
- The desktop UI's density (tables with up to 70 columns, side-by-side multi-panel layouts) is a deliberate design for sustained desk-based analysis and is not appropriate to port directly to mobile
- A mobile-appropriate design will require its own UX pass — card-based summaries, progressive disclosure/drill-down navigation, and status-driven visual design (color-coded indicators) in place of dense tabular grids

### 5.4 Research Phase Deliverables
- This document
- A detailed technical findings record (data source inventory, confirmed API/data shapes, authentication requirements) maintained as a living reference for the engineering team
- A UX density assessment identifying which desktop patterns require mobile-specific redesign

---

## 6. Phase 2 — Design (Proposed)

### 6.1 Information Architecture & UX Design

**Design principle:** Mobile is a companion to the desktop, not a replacement — it should excel at what desktop cannot (instant glanceability, notifications, portability) rather than attempt full feature parity. For this MVP specifically, the goal is the simplest possible experience that surfaces the nine KPIs leadership already watches, not a mobile port of the desktop's full reporting depth.

**Proposed MVP design (intentionally simple):**
- **A single primary screen**: a scrollable list of Business Units (including an enterprise-wide total), each shown as a card with the nine KPIs from §4.1
- **Color-coded status indicators** (e.g. based on Access/Service Level thresholds) so leadership can identify at-risk Business Units at a glance, without reading every number
- **No navigation depth beyond this screen** for MVP — no drill-down into Organization/LOB/Queue/Skill/Agent level (that data isn't in scope; see §4.2)
- **Search/filter** by Business Unit name, so a leader can quickly find their own area
- Pull-to-refresh and/or a live-updating connection (final mechanism to be confirmed with the data contract discussion in §6.3)

This deliberately small surface area is what makes this a true MVP: it can be designed, built, and validated quickly, with expansion (additional KPIs, drill-down, other report categories) driven by actual usage feedback rather than upfront speculation (see §4's scope philosophy and §11 for the proposed post-MVP iteration approach).

This phase's deliverable is a lightweight UX design package (wireframes/prototype) reviewed with a design team and validated against real usage patterns before development begins — the scope here is intentionally small enough that this should be a fast design cycle, not a lengthy one.

### 6.2 Technical Architecture

Proposed high-level architecture:

```
┌─────────────────────────────┐
│      Mobile Application      │
│   (iOS / Android, shared     │
│    React Native codebase)    │
└───────────┬──────────────────┘
            │
   ┌────────┴─────────┐
   │  Authentication    │   Native AT&T SSO (Halo.E, Public client + PKCE)
   │  Layer             │
   └────────┬─────────┘
            │
   ┌────────┴─────────┐
   │  Data Access Layer │   Handles API calls + a live-data connection,
   │                    │   with app-appropriate refresh/reconnect behavior
   └────────┬─────────┘
            │
   ┌────────┴─────────────────────┐
   │   CCS Dashboard Backend        │
   │   (existing systems — subject  │
   │   to the mobile-readiness      │
   │   considerations in §6.3)      │
   └────────────────────────────────┘
```

**Recommended stack** (subject to confirmation with engineering leadership):
- **React Native** (single codebase for iOS + Android), chosen over a fully native or web-wrapper approach to balance development velocity with the native capabilities required (secure credential storage, background/foreground lifecycle handling for live data, potential future push notification support)
- Enterprise MDM-compatible distribution approach (not the public app stores), consistent with how other internal AT&T mobile applications are distributed
- Native authentication library implementing the industry-standard protocol AT&T's Halo.E platform already supports (RFC 8252 / OAuth 2.0 for native apps), rather than a browser-embedded login

### 6.3 Data Architecture — A Decision Point for This Phase

The research phase surfaced that the current real-time data feeds, in full, are not mobile-ready (see §5.3) — they carry the entire organizational hierarchy down to individual agents, along with personal data, refreshed on a multi-megabyte payload every ~15 seconds. **The MVP scope defined in §4 substantially simplifies this problem**: because mobile only needs a Business Unit-level rollup of nine specific KPIs, the request to the backend/platform team is narrow and well-defined, not an open-ended redesign:

1. **A lightweight, BU-level-only data contract** — top-level rollup rows only (the same rollup the desktop already computes for its own summary views), limited to the nine KPIs in §4.1, with no organization/LOB/queue/skill/agent-level detail included
2. **Confirmation that this scoped contract avoids personal data entirely** — since agent-level and skill-level detail (where personal data lives in the current feeds) is out of scope for MVP by design, this should be a straightforward confirmation rather than a lengthy compliance redesign, but should still be explicitly verified with the backend/platform and security teams before development begins
3. **Confirmation of the live-update mechanism** for this narrower payload (e.g., a lightweight polling interval or a scoped push mechanism — either is viable at this reduced data volume, unlike the full-feed case)

This remains a **design-phase decision requiring backend/platform team collaboration**, not something mobile engineering can resolve unilaterally — but the MVP scope decision makes this a materially easier conversation than it would be for the full-featured experience.

### 6.4 Security & Compliance Design
- Authentication via AT&T's native SSO (Halo.E, Public client, PKCE) — see §5.3
- Secure on-device credential storage (platform Keychain/Keystore, not general-purpose storage)
- No caching of personally-identifiable data on-device beyond what's required for the current session view
- Distribution via enterprise MDM channel, consistent with AT&T mobile application security policy
- Security review of the data contract in §6.3 before development of live-data features

### 6.5 Design Phase Deliverables
- UX wireframes/prototype, validated with representative end users (supervisors)
- Finalized technical architecture document
- Agreed mobile data contract with the backend/platform team
- Security/compliance sign-off on the data handling approach

---

## 7. Phase 3 — Development (Proposed)

### 7.1 Approach
Iterative, incremental delivery, matching the deliberately minimal MVP scope in §4: build and validate the single BU-level KPI view end-to-end (authentication + the one screen) before considering any scope expansion. This is a small enough MVP that it should be built as one cohesive first release, not split into further internal phases — the phasing that matters here is **MVP → real user feedback → prioritized expansion**, not a large multi-step build-out before anything reaches users.

### 7.2 Indicative Workstream Breakdown
1. **Foundation**: project setup, authentication integration (Halo.E Public client/PKCE), basic navigation
2. **The MVP screen**: the Business Unit-level KPI list/card view, built against the finalized lightweight data contract from Phase 2 (§6.3)
3. **Hardening**: performance, offline/network-loss handling, accessibility, security testing
4. **Release preparation**: enterprise distribution setup, CI/CD pipeline, UAT with representative leadership/supervisor users
5. **Feedback loop**: a defined mechanism for collecting user community feedback post-launch to prioritize the next round of scope (additional KPIs, drill-down depth, additional report categories) — see §11

### 7.3 Testing & Quality Assurance
- Unit and component testing throughout development, not deferred to the end
- Contract testing against the agreed data shapes from Phase 2, so a backend change is caught immediately
- Device/OS coverage across current and prior major iOS/Android versions
- Network condition testing (corporate VPN on/off, degraded connectivity) given the app's dependency on AT&T's internal network
- User acceptance testing with actual supervisors before release, to validate the mobile UX approach (§6.1) against real usage

### 7.4 Deployment & Operations
- Enterprise MDM distribution (not public app stores)
- CI/CD pipeline for repeatable builds across iOS and Android
- Crash/error monitoring from the first release
- A defined process for iterating post-launch based on user feedback

---

## 8. Timeline Approach — A Note on Realistic Planning

Rather than propose a fixed calendar date for full delivery at this stage, this plan recommends the following sequencing principle: **each phase's scope and duration should be sized based on what the preceding phase reveals**, not estimated up front in the absence of information.

This is not a hedge — it reflects a specific, evidenced finding from the research phase: this is a mature, undocumented system, and the research conducted so far (covering roughly one report category out of 290) already surfaced multiple non-obvious architectural patterns and a data-readiness gap that required direct technical investigation to uncover. Committing to a full-scope timeline before the Phase 2 data-contract discussion (§6.3) concludes with the backend team risks a plan built on assumptions rather than facts.

**Recommended immediate next steps:**
1. Approve the MVP scope defined in §4
2. Initiate the Halo.E CHIP registration request in parallel with design work, since identity team turnaround is outside engineering's control (§5.3, §9)
3. Convene the backend/platform team discussion on the mobile data contract (§6.3) as the critical path item for Phase 2
4. Engage a design resource for the UX work in §6.1
5. Size Phase 3's timeline once §6.3 and the UX design are resolved, since both materially affect development scope

---

## 9. Risks & Dependencies

| Item | Type | Owner | Notes |
|---|---|---|---|
| Halo.E Public client registration (CHIP) | Dependency | Identity/Platform team | Required before any real authentication can function; process and requirements are understood (§5.3) but turnaround time is external |
| Lightweight, BU-level data contract for the nine MVP KPIs | Dependency | Backend/Platform team | Current feeds are not mobile-ready in full, but the MVP's narrow scope (§4) substantially simplifies this ask (§6.3); still needs formal confirmation |
| Personal data (PII) handling in real-time feeds | Risk | Security/Compliance | Needs explicit review and sign-off before live data reaches a mobile client |
| Enterprise distribution channel setup | Dependency | Mobility/IT | MDM enrollment and distribution process for a new application |
| UX validation with real users | Risk | Design + Product | Mobile's value proposition (glanceable + notification-driven vs. desktop's dense tables) should be validated with supervisors before heavy development investment |
| Scope creep beyond Real-time Monitoring | Risk | Project leadership | This plan explicitly scopes MVP to one report category (§4); expanding scope should be a deliberate, informed decision, not an assumption |

---

## 10. Open Questions for Leadership

1. Confirm the MVP scope in §4 is approved as the committed first deliverable
2. Identify a design resource/team to own the UX work in §6.1
3. Identify backend/platform team counterparts for the data contract discussion in §6.3
4. Confirm who initiates the Halo.E CHIP registration request, and the expected timeline
5. Confirm the enterprise distribution/MDM process and who owns it
6. Confirm ownership and cadence of the post-MVP feedback process described in §11

---

## 11. Post-MVP Iteration Approach

Because the MVP is intentionally minimal (§4), how scope expands afterward matters as much as the initial build. Proposed approach:

1. **Release the MVP to a limited initial user community** (e.g. the executive leadership group who requested these specific KPIs) rather than a broad rollout, to gather focused feedback quickly
2. **Establish a lightweight feedback channel** (e.g. a recurring short survey or direct check-ins with the initial user group) to capture what's missing or valuable
3. **Prioritize expansion candidates based on actual demand**, likely including (in no particular order, to be determined by feedback):
   - Additional KPIs beyond the initial nine
   - Drill-down from Business Unit into Organization/Team/Queue level
   - Additional real-time report variants (e.g. Chat-specific views, Skill-level views)
   - Push notifications for threshold breaches (a natural fit once specific KPI thresholds that matter to users are better understood)
4. **Re-run a lightweight version of the Research phase (§5) for each significant expansion**, since this program's research already demonstrated that this system has non-obvious complexity that benefits from investigation before design/build commitments are made — this should become a standing practice for this program, not a one-time exercise.

---

## Appendix A — Glossary

| Term | Meaning |
|---|---|
| CCS Dashboard | The existing web-based contact center monitoring/reporting platform |
| Halo.E | AT&T's internal OIDC identity platform |
| CHIP | Client-Halo Integration Portal — the self-service portal for registering OIDC client integrations with Halo.E |
| RP | Relying Party — an application integrated with an identity provider (here, Halo.E) |
| PKCE | Proof Key for Code Exchange — a security extension to OAuth 2.0 required for native/mobile ("public") clients |
| MDM | Mobile Device Management — the enterprise system for managing and distributing corporate mobile applications |

## Appendix B — MVP KPI Field Reference

For engineering reference, mapping the nine MVP KPIs (§4.1) to their underlying backend field names as observed in the existing system:

| Displayed KPI | Backend Field |
|---|---|
| Queue | `QUEUE` |
| Answered | `ANS` |
| Abandoned | `ABAN` |
| Logged In | `LOGIN` |
| On Call | `ONCALL` |
| Not Ready | `NR` |
| Ready | `READY` |
| Access | `ACCESS` |
| Access (30-min) | `ACCESS_30` |

## Appendix C — References

- AT&T Halo.E Developer Documentation: `halo-developer.cso.att.com`
- Client-Halo Integration Portal (CHIP): `chip.cso.att.com`
