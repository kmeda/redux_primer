# AGENTS.md — CCS Dashboard (React Native)

Guidance for AI coding agents (Copilot agent mode, Devin, Claude, etc.) working in this repo.
Read this file fully before planning or writing code. When this file conflicts with your defaults, this file wins.

---

## 1. Project context

- **What:** Internal mobile companion to the existing CCS web dashboard (desktop-heavy UX).
- **MVP scope:** A mobile version of the existing **realtime report** only. Executive leadership uses it to monitor contact-center KPIs.
- **Out of scope for MVP:** Anything that changes platform state. The CCaaS platform and PRT (Primary Routing Tool) own call-flow controls, and they are business-critical. **This app is read-only.** Never add actions that modify routing, call flows, or platform configuration.
- **Distribution:** Internal only. iOS via TestFlight, Android via Firebase App Distribution, both built from GitHub Actions. No public app store release.
- **Growth path:** Start simple, then expand based on feedback from the user community. Prefer designs that are easy to extend over ones that anticipate features we don't have yet.

Background docs live in `docs/`. Start with `docs/discovery/` for the web app analysis and data shapes.

**Supported platforms** <!-- TODO: confirm with stakeholders -->
- iOS minimum: <!-- TODO --> (never below React Native's minimum). Android minSdk: <!-- TODO --> (never below React Native's default).
- Phones first. Tablet support: <!-- TODO: yes/no -->. Orientation: <!-- TODO: portrait only, or landscape for charts -->.
- Test on the smallest supported phone and largest supported screen before merging UI changes.

## 2. Tech stack

| Area | Choice | Notes |
|---|---|---|
| Runtime | Node >= 22.11 | |
| Package manager | pnpm | `.npmrc` sets `node-linker=hoisted` (required for Metro/autolinking). Never use npm or yarn; never commit `package-lock.json` or `yarn.lock`. |
| Framework | React Native CLI (bare), 0.87.x, React 19 | **No Expo.** Do not add Expo packages or config. New Architecture on. |
| Language | TypeScript 6, `strict: true` | No `any` without a comment explaining why. |
| Navigation | React Navigation 7 (native stack + drawer) | Typed route params in `src/navigation/types.ts`. |
| State | Redux Toolkit 2 + react-redux 9 | Slices for client/UI state only. |
| Server data | RTK Query | All REST calls go through RTK Query endpoints. |
| HTTP | nitro-fetch | RTK Query's fetch implementation. <!-- TODO: add when API layer is built --> |
| Realtime | WebSocket service (see §6) | <!-- TODO: confirm protocol after discovery --> |
| Auth | OIDC via react-native-app-auth | Silent token refresh, see §8. |
| Secure storage | react-native-keychain | Keychain (iOS) / Keystore (Android). |
| Theming | In-house design tokens, light + dark | **No UI component library.** See §11. |
| Icons | lucide-react-native | Uses react-native-svg. Import icons individually. Do not use @react-native-vector-icons. |
| Animation/gestures | Reanimated 4 + worklets, Gesture Handler | |
| Crash reporting | Firebase Crashlytics (@react-native-firebase) | Only through `services/logging`. |
| Push | Firebase Cloud Messaging / APNs | Post-MVP unless stated otherwise. |
| Tests | Jest + React Native Testing Library | |
| Patching | patch-package | Patches in `patches/`, each with a comment on why. |
| CI/CD | GitHub Actions + Fastlane | TestFlight + Firebase App Distribution. |

**Do not add new dependencies without explicit approval.** If a task seems to need one, stop and propose it with: the package, why, alternatives considered, native impact (pods/gradle), and license.

## 3. Repository layout

```
src/
  app/            # App root, providers, store setup
  navigation/     # Root + drawer navigators, root param lists, linking (see §7)
  features/       # One folder per feature (e.g. realtime-report/)
    <feature>/
      navigation/ # This feature's stack + its ParamList types
      screens/
      components/
      hooks/
      api.ts      # RTK Query endpoints for this feature
      slice.ts    # Redux slice, only if the feature needs client state
      types.ts
      strings.ts  # User-facing strings for this feature
      __tests__/
  services/
    api/          # RTK Query base API, baseQuery, mock baseQuery
    realtime/     # WebSocket connection manager
    auth/         # OIDC, token refresh, secure storage
    logging/      # Logger + Crashlytics wrapper
    config/       # Remote Config, feature flags, force-update check
  theme/          # Design tokens, light/dark palettes, ThemeProvider, useTheme
  ui/             # Shared primitives built on tokens (Text, Card, Icon, Screen...)
  config/         # Typed env config (see §4)
  utils/
fixtures/         # Mock data captured from Playwright discovery sessions
docs/             # Discovery docs, ADRs (docs/adr/)
.github/          # Workflows, PR template, prompts/, agents/, copilot-instructions.md
reference/        # Prototype MVP — READ ONLY, see below
```

Rules:
- Features don't import from each other's internals. Shared code moves to `services/`, `ui/`, or `utils/`.
- Use path aliases (`@features/...`, `@services/...`) instead of deep relative imports.

### The `reference/` folder
`reference/` contains a working prototype built against mock data. Use it to understand screens, layout, and data shapes. **Never import from it, copy it wholesale, or modify it.** Rebuild features using this repo's structure and conventions.

## 4. Environments and build variants
Three environments: **dev**, **staging**, **prod**.

- iOS: one scheme and `.xcconfig` per environment. Android: one `productFlavor` per environment.
- Separate bundle IDs so all three install side by side: `<!-- TODO: base id -->.dev`, `.staging`, and the base ID for prod.
- Distinguish non-prod builds visibly: app name suffix ("CCS Dev", "CCS Staging") and a badged app icon.
- One Firebase project (or app) per environment, each with its own `GoogleService-Info.plist` / `google-services.json`, injected by CI. Never commit prod Firebase files.
- All environment values are read through one typed `config` object in `src/config/`. Never read env variables or build settings anywhere else. <!-- TODO: config mechanism, e.g. react-native-config or a build-time generated TS file -->
- dev defaults to `useMocks: true`; staging and prod never use mocks.
- Adding a new config value means adding it to every environment and to the `config` type in the same PR.

## 5. Data and the mock layer

- Mock data in `fixtures/` came from real Playwright sessions against the web app. Treat it as the source of truth for response shapes until real endpoints are wired.
- `services/api` provides a mock `baseQuery` that serves fixtures. It is selected by `config.useMocks`. Feature code must not know whether it is talking to mocks or the real API.
- Every API response type lives in the feature's `types.ts`. Derive types from fixtures; don't invent fields.
- Websocket messages get the same treatment: a mock realtime source that replays fixture events.

## 6. Realtime and app lifecycle

The realtime report is the core of the app. Handle it with care.

- One connection manager in `services/realtime/`. Screens subscribe through hooks; they never open sockets directly.
- Reconnect with exponential backoff and jitter. Cap retries and surface a visible "reconnecting / offline" state to the user.
- **AppState:**
  - On background: close or pause the socket and stop polling. Don't keep connections alive in the background.
  - On foreground: reconnect, then refetch a snapshot (RTK Query refetch) so stale data is replaced before live updates resume.
- Always show data freshness (e.g. "Updated 12s ago"). Executives must never mistake stale numbers for live ones.
- Throttle UI updates from high-frequency messages. Batch state writes; don't re-render per message.

## 7. Navigation

Navigation depth is not folder depth. Folders stay flat by feature; each feature owns its part of the navigation tree.

**Structure (max three navigator levels):**
1. Root stack in `src/navigation/RootNavigator.tsx`: auth gate (Login vs App) plus a root **modal group** for sheets and dialogs that can open from anywhere (filters, settings, pickers).
2. Drawer in `src/navigation/DrawerNavigator.tsx`: composes feature stacks. It imports each feature's stack and knows nothing about the screens inside.
3. One native stack per feature in `src/features/<feature>/navigation/<Feature>Stack.tsx`.

Anything deeper is **pushed screens within the feature's stack**, not more nested navigators. Do not add a fourth navigator level without an ADR.

**Hierarchical drill-downs** (e.g. site → group → team → advisor): use one screen that takes `{ nodeId, level }` and pushes itself for the next level (`navigation.push`, not `navigate`). Never create a screen or navigator per hierarchy level. Derive breadcrumbs from params or the stack.

**Typing:**
- Each feature defines its `<Feature>StackParamList` in `navigation/types.ts`.
- Root param lists in `src/navigation/types.ts` reference feature stacks with `NavigatorScreenParams<...>`.
- Screens use typed props (`NativeStackScreenProps<...>`). No untyped `useNavigation()` calls.
- Params carry IDs and small primitives only, never full objects or API payloads. Screens look data up by ID via RTK Query.

**Boundaries:**
- A feature navigates to another feature only through root-level typed routes, never by importing the other feature's screens.
- Screens don't know which drawer item or parent navigator they live under.
- Deep-link config is declared per feature and merged in `src/navigation/linking.ts`.

**Realtime and navigation:** screens deeper in a stack stay mounted. Subscribe to realtime data with focus-aware hooks (`useIsFocused` / `useFocusEffect`) so hidden screens don't keep processing live updates.

## 8. Auth and security

- Tokens live only in secure storage. Never in Redux-persist, AsyncStorage, logs, or crash reports.
- Token refresh is handled centrally in `services/auth`. RTK Query's baseQuery retries once after a refresh on 401, then signs the user out.
- Never log tokens, headers, user identifiers, or KPI payloads. The logger must redact by default.
- Crashlytics: no PII or KPI data in logs, custom keys, or breadcrumbs. Report non-fatal errors through the logger, not by calling Crashlytics directly.
- No analytics or telemetry to endpoints other than approved ones in `config/`.
- Never commit secrets, certificates, provisioning profiles, keystores, or `.env` files. Use GitHub Actions secrets.

**Device and session security** <!-- TODO: confirm each item with the security team -->
- MDM / app protection (e.g. Intune): <!-- TODO: required? --> If required, its SDK may wrap auth and storage. Decide before building those layers.
- App-switcher privacy: show a privacy overlay when the app goes inactive so KPI data isn't captured in the task-switcher snapshot.
- Session timeout: <!-- TODO: idle timeout and behavior (lock vs sign out) -->.
- Jailbroken / rooted devices: <!-- TODO: policy (allow, warn, block) -->.
- Screenshots / screen recording: <!-- TODO: policy -->.
- Certificate pinning: not used unless an ADR approves it (corporate TLS-inspection proxies can break pinning).

## 9. Error handling

Errors are handled in layers. Each layer catches what the layer above can't.

**1. Render errors: error boundaries (three levels)**
- **Root boundary** in `src/app/` wraps the whole app. Fallback: full-screen "Something went wrong" with a Try again action that resets the boundary. Last resort only.
- **Screen boundary** on every screen, applied once per feature stack via React Navigation's `screenLayout`, not hand-wrapped per screen. Fallback keeps the header and back navigation working so the user can leave the broken screen.
- **Widget boundary** around each independent KPI card/tile, so one bad tile never blanks the dashboard. Fallback is a compact "Unavailable" tile.
- One shared `ErrorBoundary` component in `src/ui/` with a `level` prop (`root | screen | widget`) and a `resetKeys` prop. Every boundary reports to `services/logging` with its level and route name.

**2. Data errors: state, not exceptions**
Error boundaries do not catch async errors, event handlers, or RTK Query failures. Handle those as state:
- The base query normalizes every failure into one `AppError` type: `{ kind: 'network' | 'timeout' | 'auth' | 'forbidden' | 'notFound' | 'server' | 'validation' | 'unknown', status?, message, retryable }`.
- Screens render the error state from `AppError.kind` with a retry action when `retryable`. Don't `throw` from hooks to reach a boundary.
- `auth` errors: one refresh attempt (see §8), then sign out with a clear message.
- Validate response shapes at the API boundary for critical KPI endpoints; a malformed payload becomes a `validation` error, not a render crash.

**3. Realtime errors**
Socket failures are connection **state** (`connecting | live | reconnecting | offline | failed`), exposed by the realtime hooks and shown in the UI with data freshness. Never surface them as thrown errors or blocking alerts.

**4. Global handlers**
Firebase Crashlytics handles uncaught JS errors and native crashes. Do not override `ErrorUtils.setGlobalHandler` or add other global handlers without an ADR.

**User-facing messages**
- Friendly, specific, and actionable ("Couldn't load queue data. Check your connection and try again.").
- Never show raw error messages, stack traces, status codes, or payloads to users.
- Prefer inline error states over alerts and toasts. Reserve alerts for actions the user must acknowledge.

**Logging**
- `services/logging` is the only path to Crashlytics: `logger.error(error, context)` records a non-fatal with route, feature, and `AppError.kind`.
- Context must follow §8: no tokens, PII, or KPI values.
- Don't swallow errors: every `catch` either handles the error meaningfully or logs it.

**Offline** <!-- TODO: decide on connectivity detection, e.g. @react-native-community/netinfo -->

**Testing:** each boundary level has a test that renders its fallback; screens have tests for their error state using a failing mock base query.

## 10. Performance
The realtime report is the most performance-sensitive part of the app. Measure before optimizing.

- **Lists:** always virtualized (`FlatList`/`SectionList` or <!-- TODO: FlashList? -->). Stable `keyExtractor` from IDs, never indexes. No `ScrollView` + `map` for lists that can grow.
- **Re-render budget:** realtime-driven UI updates at most <!-- TODO: e.g. once per second --> per screen. Batch and throttle incoming messages before they reach Redux.
- **Granular subscriptions:** each KPI tile selects only its own data with memoized selectors (`createSelector`), and tiles are `React.memo`. A single metric update must not re-render the whole dashboard.
- **Hidden screens:** pause realtime processing when not focused (see §7).
- **Animations** run on the UI thread with Reanimated; never animate with `setState` loops.
- **Charts:** downsample data to what the chart can actually display before rendering.
- **Profiling:** use React DevTools Profiler and Hermes profiling on a release-mode build on a mid-range Android device. Include before/after numbers in performance PRs.

## 11. Theming, tokens and icons

- There is no UI library. All visual values come from tokens in `src/theme/`.
- Tokens are **semantic**, not raw: `colors.background`, `colors.surface`, `colors.textPrimary`, `colors.textMuted`, `colors.border`, `colors.statusGood / statusWarn / statusBad`, plus `spacing`, `radius`, `typography`, `elevation`.
- Light and dark palettes define the same token keys. The active theme follows the system (`useColorScheme`), with room for a user override later.
- Components read tokens via `useTheme()`. Never import a palette directly, and never hard-code colors, spacing, font sizes, or radii.
- Build `StyleSheet`s from the theme (e.g. a `makeStyles(theme)` helper) so styles update on theme change.
- KPI status colors must remain distinguishable in both modes and never rely on color alone; pair them with an icon or label.
- Icons: use the `ui/Icon` wrapper around lucide-react-native so size and color come from tokens. Import only the icons you use.
- New shared components go in `src/ui/` only when used by two or more features.

## 12. Code conventions

- Function components and hooks only.
- Name components and files in PascalCase (`KpiCard.tsx`), hooks `useSomething.ts`, everything else camelCase.
- Styles: tokens only (see §11).
- Every screen handles four states: loading, error, empty, and data (errors per §9).
- Accessibility: set `accessibilityLabel` on interactive and KPI elements; support dynamic type.
- Prefer small, pure functions for KPI calculations and formatting, with unit tests.
- Keep comments for *why*, not *what*.

**Localization:** English only. Do not add i18n libraries or translation scaffolding. Keep user-facing strings in each feature's `strings.ts` so they can be extracted later. Format numbers, percentages, durations, and dates with `Intl` and the device locale, via shared helpers in `src/utils/format.ts`.

## 13. Testing

- Each PR that adds logic adds tests.
- Unit tests for utils, selectors, formatting, reconnection logic.
- Component tests with RNTL for screens: cover loading, error, empty, and data states using fixtures.
- Don't snapshot entire screens. Assert on what the user sees.

## 14. Commands

```bash
pnpm install
pnpm ios
pnpm android
pnpm start
pnpm test
pnpm lint
pnpm typecheck            # tsc --noEmit
cd ios && bundle exec pod install
```

Before declaring a task done, run: `pnpm typecheck && pnpm lint && pnpm test`. All must pass.

## 15. Release, versioning and feature flags
**Versioning**
- Marketing version follows semver (`MAJOR.MINOR.PATCH`) and is set in one place. <!-- TODO: source of truth, e.g. package.json version synced to native by Fastlane -->
- Build numbers come from CI (e.g. GitHub Actions run number) and always increase. Never set them by hand.
- Every release build is tagged in git (`v1.4.0+123`).
- Tester release notes are generated from conventional commits since the last tag.

**Distribution**
- iOS: TestFlight (internal testers). Android: Firebase App Distribution.
- staging builds go out from `main`; prod builds from release tags. <!-- TODO: confirm -->

**Force update**
Internal builds get no store update prompts, so the app enforces a minimum version itself:
- Remote Config keys `min_supported_build_ios` and `min_supported_build_android`.
- Checked on launch and on foreground. Below minimum → a blocking screen explaining the update, linking to TestFlight / the Firebase App Tester.
- Raise the minimum when an API or data contract changes in a way old builds can't handle.

**Feature flags and kill switches** (Firebase Remote Config)
- Every user-facing feature beyond the MVP core ships behind a flag named `feature_<name>_enabled`.
- Flags are declared once, typed, with safe in-code defaults, in `src/services/config/flags.ts`. Read them through a `useFlag()` hook, never from Remote Config directly.
- Fetch on launch and foreground; the app must work with defaults if the fetch fails.
- A disabled flag hides the entry point (drawer item, button) and shows a friendly "Unavailable" screen if reached via deep link.
- Remove flags once a feature is stable; each flag PR notes its intended removal.

## 16. Git, pull requests and dependencies
**Branching:** trunk-based. Short-lived branches off `main` named `feat/…`, `fix/…`, `chore/…`, `docs/…`. Keep branches under a few days old.

**Commits:** Conventional Commits (`feat(realtime-report): add queue hierarchy drill-down`). Scope is the feature folder or area. These feed tester release notes.

**Pull requests**
- Squash-merge into `main`. The PR title becomes the commit message, so it must follow Conventional Commits.
- Use `.github/pull_request_template.md`, which mirrors the Definition of Done (§18).
- Branch protection: CI green and at least one human approval. <!-- TODO: required reviewers / CODEOWNERS -->

**Dependencies**
- Automated update PRs via <!-- TODO: Dependabot or Renovate -->, weekly, grouped (React Native core, navigation, Firebase, dev tooling).
- React Native upgrades are their own PR, done within <!-- TODO: e.g. two months --> of a new minor release, following the React Native Upgrade Helper. Native diffs get human review (§19).
- Review every patch in `patches/` on each upgrade; delete patches that are no longer needed.
- `pnpm audit` runs in CI; high-severity findings block merging.

## 17. How agents should work here

1. **Plan first.** For anything beyond a small edit, post a short plan (files to touch, approach, risks) and wait for approval.
2. **Small PRs.** One concern per PR. If a task grows, stop and split it.
3. **Stay in scope.** Don't refactor unrelated code or "improve" things you weren't asked to touch. Note them in the PR description instead.
4. **Ask when unsure.** If requirements, data shapes, or behavior are unclear, ask. Don't guess, and don't fabricate API fields or endpoints.
5. **Native changes need a flag.** Any change to `ios/`, `android/`, Podfile, Gradle files, `Info.plist`, `AndroidManifest.xml`, signing, or entitlements must be called out explicitly at the top of the PR description.
6. **Follow the ADRs** in `docs/adr/`. If a task conflicts with an ADR, stop and raise it instead of working around it.
7. **PR description must include:** what changed, why, how it was tested, screenshots for UI changes (iOS and Android), and any follow-ups.

**Reusable prompts** in `.github/prompts/` (use them instead of ad-hoc instructions):
- `new-feature.prompt.md`: scaffold a feature folder with stack, types, API, strings, tests.
- `new-screen.prompt.md`: add a screen with all four states, screen boundary, typed params.
- `new-adr.prompt.md`: draft an ADR from the template in the appendix.
- `bugfix.prompt.md`: reproduce with a failing test first, then fix.
- `pr-review.prompt.md`: review a diff against this file and the Definition of Done.

**Custom agents** in `.github/agents/`, one per role. Each stays in its lane:
- **Lead:** breaks work into tasks, writes plans and ADRs, flags risks. Does not write feature code.
- **Designer:** tokens, theming, layout, accessibility, light/dark parity. Works in `src/theme/`, `src/ui/`, and feature `components/`.
- **Dev:** implements approved plans within scope, with tests.
- **QA:** writes and extends tests, probes edge cases (offline, token expiry, background/foreground, empty and error states), and checks work against the Definition of Done.

A human approves every plan and merges every PR.

## 18. Definition of Done
A task is done only when all of these are true:

- [ ] Meets the acceptance criteria of the task or plan
- [ ] `pnpm typecheck && pnpm lint && pnpm test` pass locally and in CI
- [ ] New logic has tests; screens have tests for loading, error, empty, and data states
- [ ] Works on iOS and Android, in light and dark mode, verified on a device or simulator
- [ ] Accessibility labels set; layout holds with large dynamic type
- [ ] No hard-coded styles, strings outside `strings.ts`, or untyped navigation
- [ ] No tokens, PII, or KPI values logged
- [ ] New config values exist in every environment; new features are behind a flag
- [ ] Native, CI, auth, or dependency changes are flagged at the top of the PR
- [ ] PR description complete, with iOS and Android screenshots for UI changes
- [ ] Docs, ADRs, and this file updated if a convention changed

## 19. Human review required

Agents may draft, but a human must review and approve before merging:
- Anything in auth, token handling, or secure storage
- CI/CD workflows, Fastlane lanes, signing, and release config
- Native project files
- New dependencies or patches
- Realtime connection logic
- Environment config, Firebase config files, and build variants
- Feature-flag defaults and force-update thresholds
- Security controls (§8): privacy overlay, session timeout, device policy

## Appendix: ADR template

Store ADRs as `docs/adr/NNN-short-title.md`, numbered sequentially. Never edit an accepted ADR's decision; supersede it with a new one.

```markdown
# NNN. Title

- Status: Proposed | Accepted | Superseded by NNN
- Date: YYYY-MM-DD
- Deciders: names

## Context
What problem or question needs a decision, and what constraints apply.

## Decision
What we chose, stated plainly.

## Alternatives considered
Each option with a line on why it wasn't chosen.

## Consequences
What becomes easier, what becomes harder, and any follow-up work.
```
