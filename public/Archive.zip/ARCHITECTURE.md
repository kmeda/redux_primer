# ARCHITECTURE.md — CCS Dashboard Mobile

- **Status:** Draft for review (uncommitted)
- **Date:** 2026-09-24
- **Owner:** Karthik Meda, App Lead
- **Companion docs:** [`AGENTS.md`](AGENTS.md) (conventions, Definition of Done, review rules), [`docs/discovery/`](docs/discovery/) (web app analysis, data shapes, auth research)

This document describes the **shape** of the app and the **reasons** behind it: layers, boundaries, data flow, environments, and delivery. `AGENTS.md` is the rulebook for day-to-day coding and wins on conventions. Where this document changes a convention, the change is listed in [§11](#11-follow-up-changes-to-agentsmd) and applied to `AGENTS.md` only after this document is approved.

---

## 1. Context and goals

**What:** an internal, **read-only** mobile companion to the CCS web dashboard, used by executive leadership to keep an eye on real-time contact-center KPIs.

**What it is not:** a port of the desktop app. The desktop app is a dense, 290-report system used at a desk. Mobile should do what the desktop can't: quick glances, being with the user wherever they are, and later on, alerts. The app never changes platform state. PRT (Primary Routing Tool) and the CCaaS platform own call-flow controls, and they are business-critical.

**Architectural goals, in priority order:**
1. **Hold up while things are still unknown.** The data transport, the backend contract, the identity provider and the MDM policy are all still undecided (see [§10](#10-open-items-register)). Each unknown sits behind a boundary so that settling it later is a local change.
2. **Secure by construction.** No PII by design, tokens only in platform secure storage, no non-prod code in prod binaries.
3. **Small now, easy to extend.** Build only what the current milestone needs. Record where growth will happen instead of building for it ahead of time.
4. **Safe for agents.** Much of the code will be written by AI agents, so layering rules are enforced by lint, not by trust.

## 2. Milestones

| Milestone | Scope | Exit criteria |
|---|---|---|
| **M0 — Bare branded app** | Splash → "Real-time dashboard coming soon" screen. Theme tokens (light and dark), typed config for the two variants, non-prod environment switcher, Crashlytics, CI pipeline to TestFlight. **iOS only** (universal: iPhone and iPad). **No auth, no Redux, no data layer.** | Non-prod build installed from TestFlight by internal testers. Crashlytics receives a test non-fatal. The prod-bundle sentinel check passes. |
| **MVP — BU summary** | Halo.E sign-in, a Business Unit–level rollup of 9 KPIs (Queue, Answered, Abandoned, Logged In, On Call, Not Ready, Ready, Access, Access 30-min), search by BU, data freshness, color-coded status. | Blocked on: the CHIP client, the BU data contract, and the MDM decision ([§10](#10-open-items-register)). |
| **Later** | Side drawer and navigation, more KPIs, drill-down, other real-time reports, push alerts, favorites. | Chosen based on feedback from the executive user group. |

Scope sources: `docs/discovery/CCS_MOBILE_ARCHITECTURE_PLAN.md` §4 (MVP definition) and `docs/discovery/APP_ANALYSIS_AND_PLAN.md` (the full real-time report inventory, for later phases). Where these differ from older docs, the MVP definition above is the one to follow.

## 3. Architectural style

**Feature-first organization, with hexagonal ports only at the edges where facts are likely to change.**

We considered and rejected:
- **Full clean/hexagonal layers** (`domain/application/infrastructure/presentation`). The overhead is out of proportion for an app that will have one screen for months, and it would wrap RTK Query's cache and lifecycle in extra abstraction. Individual features can still grow into this later if needed.
- **A monorepo of packages** (the myAT&T model). That model exists for many teams sharing code. CCS is one team with nothing else consuming its packages, so it would only add workspace, build-graph and Metro costs.

Ports go where change is expected: the **data transport** (WebSocket or polling is still undecided), **identity** (ISAM is moving to Entra ID), **configuration** (variant and environment), and **logging** (the vendor). Everything else is plain React and RTK code.

## 4. System context and layers

```
┌──────────────────────── CCS Mobile (RN, bare, New Arch) ────────────────────────┐
│  app/          bootstrap, providers, composition root, root error boundary        │
│  navigation/   root stack (M0: Splash → ComingSoon; later: auth gate → drawer)    │
│  features/     <feature>/ screens, components, hooks, api.ts, types.ts, strings   │
│      │ depends on PORTS only                                                      │
│      ▼                                                                            │
│  services/  ── ports ──────────────── adapters ─────────────────────────────      │
│    config     AppConfig            build-time variant + non-prod env switcher      │
│    auth       AuthProvider         Halo.E (ISAM) now → Entra ID later (config)     │
│    realtime   LiveSource<T>        mock | REST-poll | WebSocket  (TBD by backend)  │
│    api        RTK Query baseQuery  mock | nitro-fetch                              │
│    logging    Logger               Crashlytics (redacting)                         │
│  theme/ ui/ utils/   tokens, primitives, formatters (no business logic)           │
└──────────────────────────────────────┬──────────────────────────────────────────┘
                                       │ corporate network (VPN / MDM tunnel)
             ┌─────────────────────────┼──────────────────────────┐
         Halo.E OIDC            CCS backend (mobile           Firebase
       (Public + PKCE)          BU contract: pending)    (Crashlytics, Remote Config)
```

### 4.1 Dependency rules

Enforced with ESLint (`no-restricted-imports` or `eslint-plugin-boundaries`). A violation fails CI.

1. `features/*` may import `services/*` **ports**, `ui/`, `theme/`, and `utils/`. They must never import adapters, other features, or native modules directly.
2. Adapters are chosen in **one place**, the composition root in `app/`, based on `AppConfig` (variant and environment).
3. `ui/` and `theme/` know nothing about features or services.
4. `navigation/` composes feature stacks. It doesn't reach inside them.
5. The prototype (`reference/`, or `ccs_dashboard-rn` outside this repo) is never imported.

### 4.2 What exists at each milestone

| Milestone | Folders present |
|---|---|
| M0 | `app/`, `navigation/` (2 screens), `services/config`, `services/logging`, `theme/`, `ui/` (`Screen`, `Text`, `EnvBadge`, `ErrorBoundary`; `Icon` arrives with the first icon, along with lucide + react-native-svg) |
| MVP | + `services/auth`, `services/api`, `services/realtime`, `features/bu-summary` |
| Later | + drawer navigator, more features |

Folders are created when a milestone needs them, not ahead of time.

## 5. Environments, config and build variants

### 5.1 Hybrid model: two build variants, runtime tiers in non-prod only

| | **non-prod** | **prod** |
|---|---|---|
| iOS | scheme `CCS-NonProd` (Debug + Release configs) | scheme `CCS` (Release) |
| Android | productFlavor `nonprod` | productFlavor `prod` |
| Bundle ID | `com.att.ccsdashboard.test` | `com.att.ccsdashboard` (decided 2026-09-24) |
| Display name | "CCS Beta" + badged icon | "CCS" |
| Halo.E host | `oidc.stage.elogin.att.com` (non-prod client) | `oidc.idp.elogin.att.com` (prod client) |
| Firebase | non-prod Firebase app | prod Firebase app |
| Devices | iPhone and iPad (universal), all orientations, iPad multitasking | same |
| Minimum OS | iOS 18.0 · Android 10 (minSdk 29) | same |
| Distribution | TestFlight internal / Firebase App Distribution | same channels, prod testers group |
| Environment switcher | ✅ dev / stage / mock | ❌ **not in the binary** |

**Platform priority:** iOS first. Android stays in the codebase and its JS is checked in CI, but Android native setup and distribution are deferred until it's prioritized.

**Minimum OS:** iOS 18.0 covers the same iPhones as iOS 17 (XS/XR and newer), so it excludes only devices that haven't been updated, which is rare on managed phones. Android 10 is the oldest version with reasonable security support and matches what device-management tools support. Both ends of the supported range, the minimum and the current release, are tested. Raising the minimum later is a config change; lowering it costs testing.

**Why a hybrid:** Halo.E has exactly two identity hosts (stage and prod), and each app+environment pair needs its own registered client. Two variants means two sets of Apple and Firebase setup instead of three. Testers switch backend tiers without installing a new build. Prod binaries contain no switching code or non-prod endpoints, which is easier to defend in a security review.

Rejected alternatives:
- **Three flavors (dev / staging / prod):** three of every provisioning, Firebase and CHIP artifact, and a rebuild just to switch environments.
- **A single binary with runtime switching (the myAT&T model):** prod would ship switching code and non-prod configuration.

### 5.2 Config mechanism

- One checked-in, **secret-free** TypeScript file per variant: `src/services/config/variants/<variant>.ts`, type-checked against `BaseConfig`. PKCE public clients have no secrets.
- A tiny local Babel plugin (`babel/build-constants-plugin.js`) inlines `__VARIANT__`, `__APP_VERSION__` and `__BUILD_NUMBER__` as literals at bundle time, from `CCS_VARIANT` and `CCS_BUILD_NUMBER`. An unknown variant fails the build. `services/config` is the **only** reader. No other code reads env vars or build settings.
- Secrets exist only in CI: signing certificates and profiles, keystores, `GoogleService-Info.plist` / `google-services.json`. Nothing secret is committed, so git-crypt (used by myAT&T) isn't needed.

### 5.3 Non-prod environment switcher

- A modal screen reached through a hidden gesture on the ComingSoon/About screen.
- It selects the backend tier and the mock toggle, stores the choice in non-sensitive local storage (MMKV recommended; this is a new dependency and needs approval), and applies it on restart.
- **Kept out of prod** in two ways:
  1. A build-time constant `__VARIANT__` guards the switcher's import, so the minifier removes it from prod bundles.
  2. A CI step fails the prod build if a sentinel string from the switcher module appears in the JS bundle. Dead-code elimination can quietly stop working (one stray top-level import keeps the module), so this check turns an assumption into evidence.

## 6. Data flow and realtime (MVP)

### 6.1 Pipeline

```
LiveSource<BuSummary[]> adapter ──normalize──► validate (schema) ──► throttle/batch (≤1 UI update/s)
      │                                                                   │
      │ status: connecting|live|reconnecting|offline|failed               ▼
      └──────────────────────────────────────────────►  RTK Query cache entry (snapshot + patches)
                                                                          │ memoized selectors
                                                                          ▼
                                                          BU cards (React.memo, one per BU)
```

### 6.2 `LiveSource` port and adapters

| Adapter | Purpose |
|---|---|
| `MockLiveSource` | Replays fixtures captured from the live system (dev tier / mock toggle, and tests) |
| `PollingLiveSource` | REST request repeated on an interval using RTK Query `pollingInterval` |
| `SocketLiveSource` | WebSocket push, exponential backoff with jitter and a retry cap, pushing into the cache through `onCacheEntryAdded` / `updateCachedData` |

Config chooses exactly one. Screens can't tell which one is running, because every adapter writes to the **same RTK Query cache entry**. Choosing the real transport, once the backend decides, means writing one adapter.

### 6.3 Rules

- **Normalize at the edge.** Backend fields (`QUEUE, ANS, ABAN, LOGIN, ONCALL, NR, READY, ACCESS, ACCESS_30`) map to a domain type `BuSummary` inside the adapter. Backend naming inconsistencies (for example `NOTREADY` vs `NOT_READY` across reports) are handled there and nowhere else.
- **Validate critical payloads.** A payload that doesn't match the schema becomes `AppError{kind:'validation'}`, not a render crash.
- **Throttle before the store.** Incoming messages are batched to at most one UI update per second *before* they are dispatched, so Redux subscribers aren't woken on every message.
- **Lifecycle:** going to the background stops the source. Coming back to the foreground does a snapshot refetch, then resumes live updates. Screens subscribe through focus-aware hooks.
- **Freshness is always visible:** "Updated 12s ago". The data is marked stale after 2× the expected interval. Executives must never mistake stale numbers for live ones.
- **No PII by design:** the BU contract excludes `skillMap` and all agent- and skill-level data. The cache is **memory only**; nothing is persisted to disk.

### 6.4 Why the transport is behind a port

Discovery found five different backend data patterns across just nine real-time reports. The main Real-time Monitoring feed pushes a tree of about 2 MB every ~15 s with employee PII in it, which isn't usable on mobile. The mobile BU contract and its transport are a backend decision that hasn't been made yet (`docs/discovery/APP_ANALYSIS_AND_PLAN.md` §3, §6). The port lets MVP UI work go ahead against the mock adapter in the meantime.

## 7. Authentication and security

### 7.1 Auth (MVP)

- **Port:** `AuthProvider` (`signIn`, `refresh`, `signOut`, `restore`). **Adapter:** react-native-app-auth, Authorization Code + PKCE (RFC 8252), configured per variant with Halo.E values.
- The ISAM → Entra ID migration is a **config change** (issuer, client ID, redirect URI, scopes), not new code.
- The redirect uses a custom URL scheme, which Halo.E explicitly supports for native apps. No Universal Links or App Links needed.
- Tokens are stored **only** in Keychain/Keystore (react-native-keychain). They never go into Redux-persist, AsyncStorage, MMKV, logs, or crash reports.
- Refresh is handled centrally: the baseQuery retries once after a 401, then signs the user out.
- The session is restored silently behind the splash screen at launch.
- **CHIP requirement:** request **Public + PKCE** from the first non-prod submission. Client type and PKCE settings carry over to prod at promotion and can't be changed then.
- **Open:** how the WebSocket handshake authenticates. The browser relies on a session cookie; mobile needs a token in a header or subprotocol. This only matters if `SocketLiveSource` is the chosen adapter.

### 7.2 Security controls by milestone

| Control | M0 | MVP |
|---|---|---|
| Redaction in logs and crash reports (no tokens, PII, or KPI values) | ✅ | ✅ |
| Privacy overlay in the app switcher | — (no data) | ✅ |
| Session timeout / biometric lock | — | **Open** (security team) |
| MDM / app-protection SDK (e.g. Intune) | — | **Open. Decide before building `services/auth` and secure storage**, because such SDKs can take over both |
| Jailbreak/root policy, screenshot policy | — | **Open** (security team) |
| Certificate pinning | ❌ | ❌ Not without an ADR: corporate TLS inspection breaks pinning |
| Non-prod code excluded from prod | ✅ (sentinel check) | ✅ |

## 8. UI foundation, brand and observability

### 8.1 Brand and theme

- A **new CCS visual identity**, deliberately not derived from the desktop MUI theme.
- **Semantic tokens only** (`AGENTS.md` §11): color roles, spacing, radius, type scale, elevation. Light and dark palettes use identical keys and follow the system setting.
- **Brand palette and app icon are open design inputs** ([§10](#10-open-items-register)). M0 ships a small neutral palette with one accent token, so the design can be swapped in later without touching components.
- **Typography:** system fonts (SF Pro / Roboto). Dynamic Type support with no licensing or bundling. A brand font can be added later as a token change.
- KPI status colors (good, warn, bad) are always paired with an icon or label and checked for contrast in both modes.

### 8.2 M0 screens

- **Splash:** a native launch screen that hands off with no visual jump to a JS splash, which fades out once bootstrap finishes (load config, start logging; in the MVP, restore the session). `react-native-bootsplash` is recommended because it generates assets for both platforms from one source and handles the hand-off. It's a new dependency and needs approval.
- **ComingSoon:** the CCS mark, "Real-time dashboard coming soon", version and build number, and an environment badge on non-prod. Hidden entry to the environment switcher (non-prod only).

### 8.3 Responsive layout: iPhone, iPad, foldables

- **Lay out by window size, never by device type.** No `Platform.isPad`, device-model checks or locked orientations. iPad Split View, Slide Over and Stage Manager, foldable phones opening and closing, and rotation all arrive as a window-size change, and a layout driven by `useWindowDimensions` handles all of them, including devices that don't exist yet.
- **Width classes** for when layouts need to change (from the MVP onward): *compact* < 600 pt (phones, narrow split views, folded), *medium* 600–839 pt (iPad portrait, unfolded foldables), *expanded* ≥ 840 pt (iPad landscape). They'll be defined as theme tokens and read through one hook, the same way colors are.
- **M0 rule:** content is a single column capped at `layout.maxContentWidth` (640 pt) and centered, so text never stretches edge to edge on a large screen.
- **Orientation:** all orientations on iPad (required for multitasking); portrait and landscape on iPhone. The MVP's BU cards will reflow into a grid at medium and expanded widths.
- **Testing:** the smallest supported iPhone, iPad mini and the largest iPad Pro, in both orientations and in ⅓ and ½ Split View.

### 8.4 Navigation evolution

- **M0:** root native stack with `Splash → ComingSoon`, plus a modal group (environment switcher, about).
- **MVP:** an auth gate inside the root stack (Login or App), then the BU summary screen.
- **Later:** a drawer navigator composing feature stacks, following `AGENTS.md` §7 (at most three navigator levels). Adding it wraps the existing screens; it doesn't restructure them.

### 8.5 Observability

- `services/logging` is the only path to Crashlytics. It redacts by default and follows the rules in `AGENTS.md` §8–9.
- Crashlytics ships in **M0**, so crash reporting is proven before any real data flows.
- dSYMs (iOS) and R8 mappings (Android) are uploaded by CI on every distributed build.
- Performance monitoring is deferred. myAT&T uses Dynatrace; revisit if it's required for internal apps.

## 9. Delivery: CI/CD, versioning, release

### 9.1 Pipelines

CI/CD is built on **RevUp** (AT&T's internal developer platform, `ATT-IDP` org) using a template to be provided ([§10](#10-open-items-register), item 3). The template decides the pipeline's structure, runners and shared steps. The table below lists the **stages CCS needs**, which will be mapped onto that template once it arrives. It isn't a final workflow layout. myAT&T (GitHub Actions + Fastlane, reusable workflows) is a secondary reference for mobile-specific steps such as signing, TestFlight and Firebase distribution. Its app architecture isn't being adopted.

| Stage (indicative) | Trigger | Steps |
|---|---|---|
| `pr.yml` | Every PR | pnpm install (Artifactory mirror) → typecheck → lint (incl. boundary rules) → unit tests → `pnpm audit` → PR size check |
| `build-ios.yml` / `build-android.yml` | Reusable | Fastlane `build_nonprod` / `build_prod`; CI injects signing and Firebase files; uploads dSYMs and mappings; prod runs the sentinel check |
| `distribute.yml` | Merge to `main` → non-prod. Manual dispatch or a release tag → prod | TestFlight (iOS), Firebase App Distribution (Android); release notes from Conventional Commits |
| `security-scan.yml` | **Parked** | Veracode SAST + SCA is **required**. In myAT&T it runs as a scheduled Jenkins job (shared `MyAtt_common` library), not a GitHub Action. The CCS integration route is still being explored ([§10](#10-open-items-register)) |

- **M0 is iOS only** (TestFlight). Android native setup, signing (MAD Sign) and Firebase App Distribution are deferred until Android is prioritized; until then CI still builds the Android JS bundle so it can't quietly break.
- **Corporate network in CI:** the Artifactory npm mirror, proxy and CA-bundle setup are documented once in `docs/setup.md`, including a runbook for Artifactory token expiry, which happened during discovery.

### 9.2 Versioning: calendar versioning

- **Format:** `YYYY.M.PATCH`, e.g. `2026.9.0`, then `2026.9.1` for a re-release in September, then `2026.10.0` for the first October release.
  - The month is **not zero-padded**. `2026.09.0` is invalid semver and some tools reject it.
  - PATCH resets to `0` each new month.
- **Source of truth:** `package.json` `version`. Fastlane syncs it to iOS `CFBundleShortVersionString` and Android `versionName`. All three accept this format.
- **Build number:** the CI run number, always increasing (iOS `CFBundleVersion`, Android `versionCode`). This is what the stores use for ordering. Never set by hand.
- **Tags:** `v2026.9.0+42` on every distributed build.

### 9.3 Release controls

- **Force update and feature flags:** Firebase Remote Config, following `AGENTS.md` §15. Scaffolded in the MVP, not in M0.
- **Over-the-air JS updates:** none. CodePush is deprecated upstream. Every change goes through a normal build. Revisit only if an internally approved OTA service exists.

## 10. Open items register

| # | Item | Blocks | Owner |
|---|---|---|---|
| 1 | Apple Team ID for the build config (bundle IDs decided: `com.att.ccsdashboard` / `.test`; they become permanent once App Store Connect, Firebase or CHIP records exist) | M0 | App Lead (owns the Apple and Firebase accounts) |
| 2 | App icon and brand palette | M0 (a placeholder icon is acceptable for internal TestFlight) | Design |
| 3 | RevUp CI/CD template: pipeline structure, runners (incl. macOS for iOS builds), shared steps, secrets handling | M0 CI | App Lead (template to be provided) |
| 4 | Veracode SAST/SCA integration route (check whether the RevUp template already covers it) | Pre-prod release | App Lead (exploring) |
| 5 | Halo.E CHIP Public + PKCE clients (non-prod, then prod promotion) | MVP auth | Project owner |
| 6 | BU mobile data contract and transport (WebSocket or polling) | MVP data | Backend team |
| 7 | WebSocket auth handshake (only if WebSocket) | MVP data | Backend team |
| 8 | MDM / app-protection SDK requirement | MVP auth and storage design | Security / mobility |
| 9 | Session timeout, jailbreak/root policy, screenshot policy | MVP | Security |
| 10 | KPI status thresholds (e.g. Access %) | MVP status colors | Product / executive users |
| 11 | ~~Platforms~~ **Decided 2026-09-24:** iOS 18.0 / Android 10; universal iPhone + iPad, all orientations, foldable-ready layout (§8.3); iOS first, Android deferred | — | App Lead |
| 12 | SBS Real-time Monitoring data source | Post-MVP | Discovery |
| 13 | Performance monitoring vendor (Dynatrace?) | Post-MVP | App Lead |

## 11. Follow-up changes to AGENTS.md

To apply after this document is approved:

- **§2 Tech stack:** add `react-native-bootsplash` and MMKV once approved; add "no OTA updates"; record system fonts.
- **§3 Repository layout:** add the ports-and-adapters convention for `services/*` and the composition root in `app/`; add the lint boundary rules.
- **§4 Environments:** replace dev/staging/prod flavors with the hybrid model (non-prod + prod variants, runtime tiers in non-prod only, sentinel check).
- **§15 Versioning:** replace semver with CalVer `YYYY.M.PATCH`; source of truth `package.json`, synced by Fastlane.
- **§1 Platforms:** iOS minimum 18.0, Android minSdk 29; iPhone and iPad, all orientations; iOS first, Android deferred. Add the "lay out by window size, never by device type" rule (§8.3) to §11/§12.

## 12. Initial ADRs

To draft in `docs/adr/` using the template in `AGENTS.md`:

1. `001-feature-first-with-edge-ports.md`
2. `002-hybrid-build-variants.md`
3. `003-livesource-transport-port.md`
4. `004-calendar-versioning.md`
5. `005-no-ota-updates.md`
6. `006-system-fonts-and-token-theming.md`
7. `007-cicd-on-revup.md` (once the template is available)
