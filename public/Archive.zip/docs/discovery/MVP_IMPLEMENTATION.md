# CCS Dashboard RN — MVP Implementation

What's actually been built in `ccs_dashboard-rn`, as of this session. This is a status/reference doc for the scaffold itself — see `APP_ANALYSIS_AND_PLAN.md` for the broader analysis, open items, and forward-looking plan.

**Scope:** Real-time Monitoring only (9 reports), targeting `ATT`/`ADVISOR_USER` roles. Every other sidebar category (Voice/Chat/Analytical Reports, Agent Administration) is present in navigation as a non-interactive, real-data-backed placeholder so the app's structure mirrors the full desktop, but only Real-time Monitoring is functional.

**Verified on:** iOS Simulator (iPhone 17 Pro), Xcode 26.5, React Native 0.87.1. Android has not been built or verified.

---

## Stack

- **React Native 0.87.1**, bare CLI (not Expo) — chosen specifically because enterprise MDM/App-Protection SDKs typically need native module linking Expo's managed workflow can't accommodate without ejecting
- **TypeScript**, strict-ish default template config
- **@react-navigation** v7: `native` + `native-stack` + `drawer`, with `react-native-screens`, `react-native-gesture-handler`, `react-native-reanimated` (+ `react-native-worklets` pinned to `0.12.2` — a hard peer requirement of reanimated 4.6.0)
- **@reduxjs/toolkit + react-redux**, RTK Query for data fetching (currently against mocked endpoints via `fakeBaseQuery`)
- **react-native-svg** for custom-built charts (no third-party charting library — donut/bar/line charts are hand-rolled SVG components)
- **@react-native-vector-icons/material-design-icons** — matches the real dashboard's `mdi-*` icon set 1:1
- **react-native-app-auth 8.4.1** + **react-native-keychain 10.0.0** — native OIDC login (AppAuth-iOS/AppAuth-Android) with tokens in the platform Keychain/Keystore; see "Authentication" below
- Bundle ID for real-device builds: `com.xample.test.att` (fixed per explicit instruction — do not change)

## Navigation structure

```
NavigationContainer
└─ Drawer.Navigator (custom drawerContent, swipe-from-edge + tap-hamburger)
   ├─ Home                     — live KPI dashboard
   ├─ Favorites                — empty-state screen (matches real "No favorite reports yet")
   ├─ Recent                   — static mock recent-reports list
   ├─ RealtimeStack            — nested Stack.Navigator (headerShown: false at Drawer level)
   │  ├─ ReportsHome           — list of the 9 real-time reports
   │  ├─ FlatReport            — flat table screen template
   │  ├─ Hierarchy             — client-grouped tree screen template
   │  ├─ AdvisorTree           — dense multi-level tree screen template (self-referencing via navigation.push for drill-down)
   │  └─ LiveChart             — Current Day trend chart screen
   ├─ CategoryPlaceholder      — generic reused screen for Voice/Chat/Analytical/Admin categories
   └─ Support                  — static support links + instructions
```

**Known-fixed gotcha:** the Drawer auto-injects a hamburger button into headers it renders directly, but `RealtimeStack` has its Drawer-level header hidden (so the inner stack can show per-report titles) — meaning the drawer never got a chance to add its button there, and since `ReportsHome` is also that stack's root (no back button), it was a dead end. Fixed with an explicit header button on `ReportsHome` that dispatches `DrawerActions.openDrawer()` (bubbles up automatically from the nested stack).

## Screen templates (the reusable core)

Rather than one screen per report, there are 4 generic templates driven by report metadata — mirroring the real dashboard's own "one engine, many reports" architecture:

1. **`RealtimeListScreen`** (flat table → card list) — used by Active Agents View, Skill Agents View, Skill Chat Agents. Shows 3-4 headline metrics per row, "View details" expands the rest. Title prefers `SITE_NAME`/`SKILL_NAME` over `BUSINESS_UNIT` (which repeats across dozens of rows in real data).
2. **`RealtimeHierarchyScreen`** (client-grouped tree) — used by Active Agents Hierarchy, Vendor Hierarchy. Real flat rows are grouped client-side (`groupTree.ts`) into an `ENTERPRISE` rollup → Business Unit → Org tree, exactly matching how the real dashboard does it (confirmed: these reports return flat rows from the backend, not a server-side tree).
3. **`AdvisorTreeScreen`** (dense multi-level tree) — used by Real-time Monitoring, SBS, ICM. Renders real 32-39 column BU nodes: headline stats + "View details" expands grouped metric sections (Queue & Wait, Call Volume, Agent Status, Service Level, Talk & Handle Time, Access — see `metricGroups.ts`); tapping a row with children pushes a new instance of the same screen for drill-down (breadcrumb title = the tapped BU name).
4. **`CurrentDayChartScreen`** — the one non-list template, a multi-series line chart.

All four support **search-across-all-columns** (`searchUtils.ts` — case-insensitive substring match against every visible field, not just the title), and use **infinite-scroll** (`FlatList` virtualization) instead of the desktop's explicit page-number pagination.

## Real data, not synthetic mocks

Every report's fixture data was captured directly from the live dashboard (see `APP_ANALYSIS_AND_PLAN.md` §3 for full provenance) and lives in `src/mocks/realCaptures/*.json`:

| File | Report(s) | Real row/node count |
|---|---|---|
| `activeAgentsView.json` | Active Agents View | 141 rows (full) |
| `activeAgentsHierarchy.json` | Active Agents Hierarchy | 19 rows (full) |
| `activeAgentsVendorHierarchy.json` | Vendor Hierarchy | 10 rows (full) |
| `skillAgentsView.json` | Skill Agents View | 77 rows (full) |
| `skillChatAgents.json` | Skill Chat Agents | 24 rows (full) |
| `monitoringTree.json` | Real-time Monitoring (+ SBS, approximated) | 68 top-level BUs (full breadth), 2 levels deep (trimmed depth to keep bundle small) |
| `icmTree.json` | ICM Real-time Monitoring | 5 top-level BUs (full), 2 levels deep |
| `rtmSnapshotsEnterprise.json` | Current Day chart | 5 hourly snapshots (thinned from 9) |

Field names use the **real, sometimes-inconsistent** backend naming (e.g. `NOTREADY` on Hierarchy/View vs. `NOT_READY` on Vendor Hierarchy/Skill views — a genuine backend inconsistency, not a typo, normalized at the UI layer).

**SBS Real-time Monitoring is the one exception**: its real data source was never confirmed (see plan doc §3 open item) — it's mocked as a labeled-as-illustrative slice of the Monitoring tree, not real SBS data.

## Live/mock data layer

- `mockWebSocket.ts` simulates `wss://.../ws/enterprise`'s exact real message shapes (`enterprise_data_push`, `enterprise_call_params_push`, `enterprise_chat_data_push`, `enterprise_chat_params_push`) on a 15s interval with jitter, feeding the Home screen's live tiles via `useRealtimeSocket` (connects on foreground, disconnects on background via `AppState`).
- `realtimeSlice.ts` keeps current values *and* a capped 12-entry rolling history per channel, feeding the two trend charts on Home.
- `reportsApi.ts` (RTK Query, `fakeBaseQuery`) serves the flat-report and hierarchy fixtures with a simulated 400ms network delay — structured so swapping in a real `fetchBaseQuery` later is a drop-in change, not a rewrite.

## Charts (all hand-built on react-native-svg, no charting library)

- `DonutChart` — multi-segment ring + center total, used for Agent Status cards
- `MiniBarChart` — plain `View`-based bars (no SVG needed), used for Call/Chat Stats cards
- `TrendLineChart` — multi-series polyline with legend, used for Home trend cards and the Current Day chart

## What's explicitly NOT implemented (by design, for this MVP)

- **Real, completed sign-in** — the native OIDC integration itself is built and confirmed working (see "Authentication" below); what's missing is a registered native client from AT&T's Identity team, which is outside this codebase's control.
- Any other real network calls — report data is still mocked/local
- Android build/verification
- The other 8 sidebar categories beyond Real-time Monitoring (intentional placeholders)
- The VQDN/SKILLNAME side-panel drill-down and per-queue trend chart modal (`GET /api/getVQChartDetails`) discovered on the real advisor tree reports after this scaffold was built — see plan doc §1/§3/§4. Not yet a mobile screen; open product question on priority.
- Push notifications, favoriting (UI exists, not wired to persistence), offline caching
- Automated tests (Jest is scaffolded but empty beyond the default template test)

## Authentication (implemented, confirmed working against the real AT&T login page)

[`react-native-app-auth`](https://github.com/FormidableLabs/react-native-app-auth) 8.4.1 is integrated (a native bridge to AppAuth-iOS/AppAuth-Android, RFC 8252 with PKCE, provider-agnostic - has documented, tested example configs for both generic OIDC and Microsoft/Entra ID today, not gated on any future release).

**What's built:**
- `src/auth/authConfig.ts` — endpoint/client configuration. The authorization endpoint (`https://oidc.idp.elogin.att.com/mga/sps/oauth/oauth20/authorize`) and scopes (`openid profile groups`) are confirmed from the web app's login redirect; the token endpoint (`.../mga/sps/oauth/oauth20/token`) is now also independently confirmed directly from AT&T's own Halo.E developer docs (the revocation endpoint remains inferred from the same path pattern). `clientId` and `redirectUrl` are placeholders pending a new Public+PKCE OIDC RP integration requested via CHIP (`https://chip.cso.att.com`) — see "AT&T's OIDC platform (Halo.E)" below for the full process.
- `src/auth/authService.ts` — `signIn`/`refreshTokens`/`signOut` wrapping `authorize`/`refresh`/`revoke`, with tokens persisted in the platform Keychain/Keystore via `react-native-keychain` (never AsyncStorage).
- `src/features/auth/authSlice.ts` — Redux state machine (`checking` → `signedIn`/`signedOut`/`error`), `restoreSession` thunk that silently refreshes an expired token on app start instead of forcing a fresh login every launch, plus a `enterMockMode` dev-only bypass so the mocked report screens stay testable while the real client is pending.
- `src/screens/LoginScreen.tsx` — "Sign in with AT&T ID" + the mock-mode bypass link.
- `App.tsx` gates `AppNavigator` vs `LoginScreen` on auth state; the drawer has a working Sign Out action.
- **Native wiring, both platforms:**
  - iOS: `Info.plist` `CFBundleURLTypes` for the redirect scheme, an Objective-C bridging header (`AppDelegate+RNAppAuth.h`) and `AppDelegate.swift` updated to conform to `RNAppAuthAuthorizationFlowManager` (required for RN ≥0.77's Swift AppDelegate) and resume the auth session from the redirect callback, `SWIFT_OBJC_BRIDGING_HEADER` build setting added to both Debug/Release configs, `pod install` completed successfully (AppAuth 3.0.0, RNKeychain 10.0.0, react-native-app-auth 8.4.1).
  - Android: `appAuthRedirectScheme` manifest placeholder added to `android/app/build.gradle` (not yet built/verified - see the standing Android gap noted elsewhere in this doc).

**Confirmed working, live**: tapping "Sign in with AT&T ID" on the iOS simulator opens a real native AppAuth browser session that loads AT&T's actual live login page (`oidc.idp.elogin.att.com`), with iOS even offering to autofill a saved password for the signed-in Apple ID's ATTUID. This proves the entire native integration - AppDelegate bridging, URL scheme registration, AppAuth linking, the `authorize()` call itself - works correctly end-to-end, all the way up to AT&T's real identity server. The sign-in was not completed (no credentials entered).

### AT&T's OIDC platform (Halo.E) — what's actually needed, and why the web client can't be reused

AT&T's internal OIDC platform is called **Halo.E** (docs: `halo-developer.cso.att.com`). It defines two RP (Relying Party) client types:
- **Confidential** — can hold a secret; most web apps, including this one (the CCS Dashboard web app's client does its code-for-token exchange server-side, no PKCE observed - confirmed via network capture).
- **Public** — cannot hold a secret; **required for native/mobile apps**, must use Authorization Code Flow **with PKCE**.

Each app+environment gets its own distinct client ID and pre-registered redirect URI(s) - **there's no shared/reusable client between web and mobile, or across environments**. This is registered by submitting a form on the **Client-Halo Integration Portal (CHIP)**: `https://chip.cso.att.com`, requesting:
- Client type: **Public**
- Flow: **Authorization Code Flow with PKCE**
- Redirect URI: a custom URL scheme (e.g. `com.xample.test.att:/oauthredirect`) - **confirmed explicitly supported** by Halo.E's own docs for native apps ("native applications that must use a custom URI scheme, e.g. `myapp://`"). This resolved an earlier open question in this project about whether Universal Links/App Links would be required instead - they are not; only *web* apps are required to use HTTPS FQDN redirects.

Non-prod (dev/test/stage, hosted at `oidc.stage.elogin.att.com`) is requested first via a queued review; production is a separate "promotion" step done afterward, once non-prod is working. **Client type and PKCE usage carry over from non-prod to production and cannot be changed at promotion time** - so it's important this is requested as Public+PKCE from the very first submission.

**What's still blocking a completed login**: the CHIP-issued `clientId` + matching `redirectUrl` for a new Public+PKCE RP integration. Everything else in this codebase is ready; obtaining these is purely a config swap in `authConfig.ts`, not further engineering work. AT&T's identity backend is also expected to migrate from IBM ISAM/TAM to Microsoft Entra ID in a few months - `react-native-app-auth` is provider-agnostic, so that migration should also be a config change (issuer, client ID, redirect URI, scopes), not a rewrite.
