# Project context

Project: CCS Dashboard App

Brainstorming:
The app is supposed to be an extension to an existing web app which is desktop heavy UX. Refer the docs for a high level overview.
Each doc was written in sequence based on how events uncovered: APP_ANALYSIS_AND_PLAN > MVP_IMPLEMENTATION > CCS_MOBILE_ARCHITECTURE_PLAN > draft_plan
/Users/km1597/myworkspace/ccs_dashboard_app (where all the APP_ANALYSIS_AND_PLAN, MVP_IMPLEMENTATION, CCS_MOBILE_ARCHITECTURE_PLAN, draft_plan docs were uncovered)
/Users/km1597/myworkspace/ccs_dashboard-rn (where all the code for the mvp implementation will be) (I do not like the theme that referenced the desktop UI on the discovery phase)

Not everything needs to be ported to mobile app, only the mobile version of the realtime report that already exists. Unclear whether it is an api call or websocket.
Given that the CCaaS platform integrations are already mature, PRT (Primary Routing Tool) which has all the call flow controls, and it is very critical.
Most of the executive leadership monitor these KPIs. To start with, it will be very simple application and then expand as we get the feedback from the user community.

React Native App Setup:
Regardless of what the App is meant for, what should be the ground work required to setup a new react native app these days ?
For example how do you categorize the below for instance: A list not fully complete.
    Navigation,
    Network and services (API's and Websockets) nitro-fetch, RTK Query,
    Design system (on boarding an existing UI-Library for design consistency),
    Environment and debug configuration,
    Application state (Redux Toolkit),
    Observables,
    Typescript,
    Native modules,
    Push notifications,
    Error logging and crash monitoring,
    Modularity,
    Realtime websocket connection management,
    App foreground and background states with respect to realtime data and refreshing,
    OIDC Authentication and seamless token refresh,
    Secure storage,
    App release and versioning,
    patching packages,
    CI/CD pipelines for debug and release builds,
    code push capability,
    
Scaffolding a new react native app by the name: ccsdashboard
Setting up both platforms from the iOS developer account and firebase console
Xcode and Android studio setup
Deployment pipelines for both Android and iOS


Agentic workflow:
    Design,
    Development,
    Testing,
    Deployment,
    Maintenance,
Agent Teams:
    Team Lead
    Designer UI/UX
    Dev team
    QA team
Human in the loop where applicable

NOTES: TODO NEXT

reference repo at /Users/karthikmeda/Downloads/temp_del/repos/apm0013625-myatt-rn to be scourged for patterns and best practices, agent workflow, and architecture decisions, configuration files, and any other relevant information.
