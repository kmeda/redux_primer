# CCS Dashboard Mobile Application — Architecture & Delivery Plan

**Status:** Draft for review
**Prepared for:** Project stakeholders, engineering leads, executive sponsors
**Prepared by:** Karthik Meda, App Lead
**Phase:** Research & Planning

---

## Overview

This is a phased plan to deliver a companion mobile application, beginning with a narrow Minimum Viable Product (MVP): a **Business Unit-level executive summary view** of the same Real-time Monitoring KPIs that senior leadership already relies on today.

**MVP Definition:** A simple mobile application (iOS) displaying a Business Unit-level rollup of the Real-time Monitoring report, limited to the following key KPIs:

| KPI |
|---|
| Queue |
| Answered |
| Abandoned |
| Logged In |
| On Call |
| Not Ready |
| Ready |
| Access |
| Access (30-min) |

The intent is to ship something simple first, then expand scope iteratively based on feedback.

---

## Phase 1: Research (In Progress)

**System**
- Web UI is a dense, desktop-heavy UX.
- A mobile version of the report exists for real-time monitoring. Need to confirm the data contract with the backend team.
- Authentication uses AT&T's corporate identity platform, Halo.E. Need to clarify requirements for mobile authentication, since mobile applications must be registered as a **Public Client**, unlike the web app which is a **Confidential Client**.

**UX**
- A mobile-appropriate design will require its own UX pass — card-based summaries, progressive disclosure/drill-down navigation, and status-driven visual design (color-coded indicators) in place of dense tabular grids.
- Mocked UI designs will be made available for reference.

---

## Phase 2: Design (Proposed)

**Technical Architecture**
- Proposed high-level architecture.

**Recommended Stack**
- **React Native** (single codebase for iOS + Android), chosen over a fully native or web-wrapper approach to balance development velocity with the native capabilities required (secure credential storage, background/foreground lifecycle handling for live data, potential future push notification support).
- Enterprise MDM-compatible distribution approach (not the public app stores), consistent with how other internal AT&T mobile applications are distributed.
- Native authentication library implementing the industry-standard protocol AT&T's Halo.E platform already supports.

---

## Phase 3: Development (Proposed)

**Approach**
Iterative, incremental delivery, matching the MVP scope: build and validate the single BU-level KPI view end-to-end. The phasing that matters here is **MVP → real user feedback → prioritized expansion**.

**Breakdown**
1. **Foundation** — project setup, authentication integration (Halo.E Public client/PKCE), basic navigation
2. **The MVP screen** — the Business Unit-level KPI list/card view, built against the finalized mobile report
3. **Hardening** — performance, offline/network-loss handling, accessibility, security testing
4. **Release preparation** — enterprise distribution setup, CI/CD pipeline, UAT with leadership/supervisor users
5. **Feedback loop** — collecting user feedback post-launch to prioritize the next round of scope (additional KPIs, drill-down depth, additional report categories)

**Testing & QA**
- Unit and component testing throughout development
- Contract testing against the agreed data shapes from Phase 2, so a backend change is caught immediately
- Device/OS coverage across current and prior major iOS/Android versions
- Network condition testing (corporate VPN on/off, degraded connectivity), given the app's dependency on AT&T's internal network
- UAT with supervisors before release, to validate the mobile UX approach

**Deployment & Operations**
- Enterprise MDM distribution
- CI/CD pipeline for repeatable builds across iOS and Android
- Crash/error monitoring from the first release
- A defined process for iterating post-launch based on user feedback

---

## Timeline Approach: Next Steps

1. Finalize MVP scope
2. Initiate the Halo.E CHIP registration request (Project owner) in parallel with design work
3. Convene the backend/platform team discussion on the mobile data contract

---

*This plan reflects my current understanding based on initial research; I may have missed or not yet accounted for existing processes, tools, or constraints already in place, and welcome corrections.*
