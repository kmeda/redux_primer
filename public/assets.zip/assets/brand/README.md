# CCS brand assets

Icon: **Twin gauge**. The outer ring is voice, the inner ring is chat, and the dot means live. Colors: AT&T blue `#0078C8`, dark blue `#005FA3`, live `#7FD3FF`.

| File | Used by |
|---|---|
| `ios/CCSDashboard/Images.xcassets/AppIcon.appiconset/` | Prod app icon (scheme `CCS`). One 1024 px image with Default, Dark and Tinted appearances (iOS 18+). |
| `ios/CCSDashboard/Images.xcassets/AppIcon-Beta.appiconset/` | Non-prod app icon (scheme `CCS-NonProd`, `ASSETCATALOG_COMPILER_APPICON_NAME = AppIcon-Beta`). |
| `ios/CCSDashboard/Images.xcassets/SplashBackground.imageset/` | Full-screen gradient behind the splash logo (square 2732 px, aspect-fill for every device and orientation). |
| `assets/brand/splash-logo.png` | Input for `react-native-bootsplash generate` (twin gauge + "CCS", transparent, 4×). |
| `assets/brand/source/*.svg` | Editable masters for every icon variant and the glyph. |
| `assets/brand/icon-composer-layers/*.svg` | Flat layers for Apple's Icon Composer (iOS 26 Liquid Glass). The system adds the glass, light and shadow. |

App icon PNGs are opaque RGB, because App Store Connect rejects icons with an alpha channel.

## Splash (plan Task 15)

```bash
pnpm react-native-bootsplash generate assets/brand/splash-logo.png \
  --platforms=ios --background=0078C8 --logo-width=148 --assets-output=assets/bootsplash
```

Then, in Xcode, open `BootSplash.storyboard` and add an **Image View** named `SplashBackground` behind the logo:
- Content Mode: **Aspect Fill**
- Constraints: pinned to the superview on all four edges (not the safe area)

The solid `#0078C8` background stays as a fallback.

The wordmark font is Outfit ExtraBold, baked into the PNG. If AT&T Aleck Sans is licensed for this app, re-export the "CCS" in it.
